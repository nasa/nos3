/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef PROTOCOL_PARSER_COMMAND_PROCESSOR_HPP
#define PROTOCOL_PARSER_COMMAND_PROCESSOR_HPP

#include <string>

#include <boost/noncopyable.hpp>

#include <ItcLogger/Logger.hpp>
#include <itc_visibility.hpp>

#include <ItcProtocolParser/types.hpp>
#include <ItcProtocolParser/CommandResponse.hpp>
#include <ItcProtocolParser/UnknownCommandException.hpp>

namespace ProtocolParser
{
    //TOOD: In order to better facilitate chaining of Processors, it may make sense to have th execute_command method take the actual command
    //object and the user should provide a protocol parser. 
    class DLL_PUBLIC CommandProcessor : boost::noncopyable
    {
    public:
		friend std::ostream& operator<< (std::ostream& stream, CommandResponsePtr& response);
		virtual CommandResponsePtr execute_command(const std::string& command, std::istream& data) throw(ProtocolParser::UnknownCommandException);
		virtual ~CommandProcessor();
		
	protected:

        class IFunction
        {
            public:
				virtual CommandResponsePtr execute(std::istream& data) = 0;
				virtual ~IFunction();
        };

        //TODO: In the future it might make sense to just use a boost::function to handle this.
        //Since its a template it needs to be defined and declared here to avoid constant re-definition in client users code
        //
        //DEBUG: This should be implemented in a seperately tempalted class that does not hava type T for non context cases
        template<class T>
        class FunctionProxy : public IFunction
        {
            public:
                typedef CommandResponsePtr (T::*CommandFunction)(std::istream& data);

                FunctionProxy(T* context, CommandFunction function): context(context), function(function)
                {
                    if (context == NULL)
                        throw std::exception();
                }

                CommandResponsePtr execute(std::istream& stream)
                {
                    CommandResponsePtr response;
                    response = (context->*function)(stream);
                    
                    return response;
                }
            private:
                T* context;
                CommandFunction function;
        };
        
        typedef std::map<std::string, IFunction*> CommandMap;

        CommandMap command_map;
    
	private:
        static ItcLogger::Logger* logger;
    };
}

#endif /* PROTOCOL_PARSER_COMMAND_PROCESSOR_HPP */
