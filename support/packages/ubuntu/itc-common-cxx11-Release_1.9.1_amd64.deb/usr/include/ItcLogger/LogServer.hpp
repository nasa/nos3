/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_LOG_SERVER_HPP
#define ITC_LOGGER_LOG_SERVER_HPP

#include <list>
#include <string>
#include <algorithm>

#include <boost/asio.hpp>
#include <itc_thread_support.hpp>

#include <itc_visibility.hpp>

#include <ItcLogger/LogServerListener.hpp>

namespace ItcLogger
{
    /**
       \brief Log server used to monitor log messages from remote targets.
    */
    class DLL_PUBLIC LogServer
    {
    public:
        /**
           \brief Create a new log server.

           The log server will start listening on the provided port.  If desired,
           a boost::asio::io_service may be provided by the user.  If provided,
           the log server will use a user-managed io_service to perform all network
           I/O.  If not provided, the LogServer will create a its own private
           io_service and handler thread.

           \param port      TCP port to listen on
           \param user_ios  User-provided io_service to use.
        */
        LogServer(unsigned short port, boost::asio::io_service *user_ios = NULL);

        /**
           \brief Shuts down the log server.

           If an io_service and handler thread were created, they will be cleaned
           up as well.
        */
        ~LogServer();

        /**
           \brief Add a listener.

           This method is not thread safe.

           \param listener  Listener to add.  May not be NULL.
        */
        void add_listener(LogServerListener *listener);

        /**
           \brief Remove a listener.

           This method is not thread safe.

           \param listener  Listener to remove.  May not be NULL.
        */
        void remove_listener(LogServerListener *listener);

        /**
           \brief Starts execution of the server.

           The log server will not bind to the TCP port until this
           method is called.  This allows users of this class to
           call the \ref add_listener method to prevent the loss of
           any log messages.
        */
        void start();

    private:
        void start_accept();
        void handle_accept(const boost::system::error_code &error,
                           boost::shared_ptr< boost::asio::ip::tcp::socket > socket);
        void start_read(boost::shared_ptr< boost::asio::ip::tcp::socket >);
        void handle_read(const boost::system::error_code &error,
                         boost::shared_ptr< boost::asio::ip::tcp::socket > socket);

        typedef std::list< LogServerListener * > ListenerList;

        bool started;
        ListenerList listeners;
		MUTEX listener_mutex;
        boost::asio::io_service *ios;
        bool owns_ios;
        boost::asio::ip::tcp::acceptor *acceptor;
		THREAD *thr;
        char buf;
        std::string curmsg;
    };
}

#endif /* ITC_LOGGER_LOG_SERVER_HPP */
