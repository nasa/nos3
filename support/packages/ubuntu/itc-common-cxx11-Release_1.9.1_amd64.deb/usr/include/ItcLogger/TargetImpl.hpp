/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_PLUGIN_HPP
#define ITC_LOGGER_PLUGIN_HPP

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/noncopyable.hpp>

#include <itc_visibility.hpp>

#include <ItcLogger/Types.hpp>

namespace ItcLogger
{
    /**
         \brief Log target implementation class.

         Each plugin is expected to contain a single log target implementation.  Instances
         of this class should be created by the plugin library during calls to the exported
         CreateTargetImpl function.

         The constructor of this class may throw InvalidArguments.
    */
    class DLL_PUBLIC TargetImpl : public boost::noncopyable
    {
    public:
        /**
            \brief Public destructor.
        */
        virtual ~TargetImpl();

        /**
            \brief Log method

            When this method is called, the log target implementation is expected to write
            the provided message to the destination.  The log target implementation should
            not reformat the message, aside from normal packaging for a particular
            implementation (e.g., adding a header for a sending over the network).

            This method will only be called from a single thread at a time.

            \param log_level  Level of the log message
            \param msg  Log message

            \throw std::bad_alloc  If the log target implementation attempts to
                                     cache a log message, and there is not enough
                                     memory to cache the message.
        */
        virtual void log(log_level_t log_level, const char *msg) throw(std::bad_alloc) = 0;

        /**
            \brief Called when this log target implementation is added to a logger.

            This method allows log target implementations to know which logger(s) are using
            it to provide a feedback mechanism allowing target implementations to modify
            the log level of a logger.

            Overriding this method is optional.  The default implementation does nothing.

            This method will only be called from a single thread at a time.

            \param l  Logger instance that will send messages to this log target implementation
        */
        virtual void added_to_logger(Logger *l) throw();

        /**
            \brief Called when this log target implementation is removed from a logger.

            This method allows log target implementations to know which logger(s) are using
            it to provide a feedback mechanism allowing target implementations to modify
            the log level of a logger.

            Overriding this method is optional.  The default implementation does nothing.

            This method will only be called from a single thread at a time.

            \param l  Logger instance that will send messages to this log target implementation
        */
        virtual void removed_from_logger(Logger *l) throw();

    protected:
        /**
            \brief Utility function to retrieve a value from a \ref LogArguments structure

            \param args          Set of arguments
            \param arg           Argument to search for
            \param defaultValue  Default value to use, if not mandatory and not present
            \param mandatory     If true and not set, \ref InvalidArguments is throw.  If
                                   false and not set, the default value is returned

            \return Parsed value for the argument

            \throw InvalidArguments  The argument is mandatory and not specified, or
            could not be successfully parsed.
        */
        template< typename T >
        inline T get_option(const LogArguments &args,
                            const char *arg,
                            T defaultValue,
                            bool mandatory = false)
        throw(InvalidArguments)
        {
            LogArguments::const_iterator it = args.find(arg);

            if(it == args.end())
            {
                if(mandatory)
                {
                    throw InvalidArguments();
                }
                else
                {
                    return defaultValue;
                }
            }
            else
            {
                try
                {
                    return boost::lexical_cast< T >(it->second);
                }
                catch(const boost::bad_lexical_cast &)
                {
                    throw InvalidArguments();
                }
            }
        }
    };

    /**
        \brief Template specialization of \ref get_option for boolean types
    */
    template<>
    inline bool TargetImpl::get_option< bool >(const LogArguments &args,
                                               const char *arg,
                                               bool defaultValue,
                                               bool mandatory)
    throw(InvalidArguments)
    {
        LogArguments::const_iterator it = args.find(arg);

        if(it == args.end())
        {
            if(mandatory)
            {
                throw InvalidArguments();
            }
            else
            {
                return defaultValue;
            }
        }
        else
        {
            if(boost::iequals("true", it->second))
            {
                return true;
            }
            else if(boost::iequals("false", it->second))
            {
                return false;
            }
            else
            {
                throw InvalidArguments();
            }
        }
    }

    /**
        \brief Template specialization of \ref get_option for log_level_t types
    */
    template<>
    inline log_level_t TargetImpl::get_option< log_level_t >(const LogArguments &args,
                                                             const char *arg,
                                                             log_level_t defaultValue,
                                                             bool mandatory)
    throw(InvalidArguments)
    {
        LogArguments::const_iterator it = args.find(arg);

        if(it == args.end())
        {
            if(mandatory)
            {
                throw InvalidArguments();
            }
            else
            {
                return defaultValue;
            }
        }
        else
        {
            log_level_t rv = String2Level(it->second.c_str());

            if(rv == LOGGER_INVALID)
            {
                throw InvalidArguments();
            }
            else
            {
                return rv;
            }
        }
    }


    /**
        \brief Factory method for creating log target implementation instances.

        Each logging target plugin must implement this function to instantiate log targets.
        The implementation of this function must be named "CreateTargetImpl" for the
        logging library to load the plugin successfully.  Otherwise, the \ref LibNotValid
        exception will be thrown when attempting to create the target.

        \param args  Arguments to use during creating of the log target implementation
    */
    typedef TargetImpl *(*CreateTargetImplFn)(const LogArguments &args);
}

#endif /* ITC_LOGGER_PLUGIN_HPP */
