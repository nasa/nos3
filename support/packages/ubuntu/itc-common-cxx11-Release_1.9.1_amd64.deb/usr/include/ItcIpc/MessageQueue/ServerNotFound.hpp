/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_IPC_SERVER_NOT_FOUND_HPP
#define ITC_IPC_SERVER_NOT_FOUND_HPP

#include <ItcIpc/MessageQueue/IPCError.hpp>

#include <itc_visibility.hpp>

namespace ItcIpc
{
    namespace MessageQueue
    {
        /**
            \brief Indicates a server was not found for the message queue
        */
        class DLL_PUBLIC ServerNotFound : public IPCError
        {
        public:
            ServerNotFound() :
                IPCError("server message queue not found")
            {}

            virtual ~ServerNotFound() throw()
            {}
        };
    }
}

#endif /* ITC_IPC_SERVER_NOT_FOUND_HPP */
