/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_IPC_MESSAGE_QUEUE_TYPES_HPP
#define ITC_IPC_MESSAGE_QUEUE_TYPES_HPP

#include <stdint.h>
#include <list>
#include <limits>
#include <limits.h>

#include <itc_visibility.hpp>

#include <ItcIpc/Config.hpp>
#include <ItcIpc/MessageQueue/IPCError.hpp>
#include <ItcIpc/MessageQueue/InvalidName.hpp>
#include <ItcIpc/MessageQueue/MessageQueueClosed.hpp>
#include <ItcIpc/MessageQueue/OSError.hpp>
#include <ItcIpc/MessageQueue/ServerAlreadyExists.hpp>
#include <ItcIpc/MessageQueue/ServerNotFound.hpp>

const size_t IPC_NO_MESSAGE = (std::numeric_limits< size_t >::max)();
const unsigned long IPC_NO_TIMEOUT = ULONG_MAX;

namespace ItcIpc
{
    namespace MessageQueue
    {
        typedef uint32_t ClientId;
        typedef std::list<ClientId> ClientIds;
    }
}

#endif /* ITC_IPC_MESSAGE_QUEUE_TYPES_HPP */
