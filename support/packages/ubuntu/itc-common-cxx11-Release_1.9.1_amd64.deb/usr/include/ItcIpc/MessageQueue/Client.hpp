/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_IPC_MESSAGE_QUEUE_CLIENT_HPP
#define ITC_IPC_MESSAGE_QUEUE_CLIENT_HPP

#include <boost/noncopyable.hpp>

#include <ItcIpc/MessageQueue/Types.hpp>

namespace ItcIpc
{
    namespace MessageQueue
    {
        /**
            \brief A client reader/writer for a message queue.

            Reader and writer queues are seperate and allow reading and writing concurrently.

            Each client connected to the server has it's own read/write queues.

            This class is thread-safe.
            
            This class attempts to abstract away the behavior of IPC queues from the OS into a standard interface.
            On both POSIX (sysv message queues) and Windows (named pipes) a path to a file is used. All users must create
            an object with this in mind. Specific implementations of this class can translate such a name into something
            usable by the OS.
        */
        class DLL_PUBLIC Client : public boost::noncopyable
        {
        public:
            /**
                \brief Instantiates a client

                Note that a \ref Server must exist before instantiating a client.

                \param path       Unique name for the message queue
                \param max_bytes  Maximum number of bytes that may be sent (not used, included for backwards compatibility)
                \param read_timeout     Default blocking receive timeout
                \param connect_timeout  Max time (in ms) to wait for a connection to be established
                
                \throw IPCError         When a general IPC error occors
                \throw InvalidName      Provided \ref path is invalid
                \throw ServerNotFound   A \ref Server does not yet exist on the \ref path
                \throw OSError          An OS error occurred
            */
            explicit Client(const char *path,
                            size_t max_bytes,
                            unsigned long read_timeout = IPC_NO_TIMEOUT,
                            unsigned long connect_timeout = 20000)
                throw(IPCError, InvalidName, ServerNotFound, OSError);

            /**
                \brief Closes a client
            */
            ~Client();
            
            /**
                \brief Set the default blocking receive timeout.

                Sets the amount of time a blocking receive will wait for a message to be received.
                If a message isn't received withing the timeout period IPC_NO_MESSAGE is returned
                by the receive method.

                \param timeout The timeout in milliseconds.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            void set_receive_timeout(unsigned long timeout)
                throw(IPCError, OSError);
            
            /**
                \brief Get the default blocking receive timeout.

                \return The timeout in milliseconds.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            unsigned long get_receive_timeout()
                throw(IPCError, OSError);

            /**
                \brief Write data to the message queue

                This method is thread safe.

                \param buf   Pointer to the data to write
                \param size  The number of bytes to write.
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed  The message queue was closed
                \throw OSError             An OS error occurred
             */
            void send(const char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Read data from the message queue.

                This method blocks until a message is received.  If the message is longer
                than the size of the provided buffer, the message is truncated.

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.

                \param buf   The buffer to store the read data in
                \param size  The size of the buffer storing the read data

                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t receive(char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Read data from the message queue.

                This method blocks until a message is received.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.

                \param buf   The buffer to store the read data in

                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t receive(char **buf)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Try to read from the message queue.

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.

                \param buf   The buffer to store the read data in
                \param size  The size of the buffer storing the read data

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t try_receive(char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);

            /**
                \brief Try to read from the message queue.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.

                \param buf   The buffer to store the read data in

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t try_receive(char **buf)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Cancel the next or current receive.

                A call to this method will cancel the next or current blocking receive.
                It is possible to also cancel a try_receive if the call happens before
                the try_receive call.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            void cancel_receive()
                throw(IPCError, OSError);

            /**
                \brief Gets a value indicating if the client is connected to the server.
                
                \return true if client is connected, false otherwise
             */
            bool connected() const
                throw();

            /**
                \brief Closes a client
            */
            void close()
                throw(IPCError, OSError);

        private:
            class ClientImpl;
            ClientImpl *impl;
        };
    }
}

#endif /* ITC_IPC_MESSAGE_QUEUE_CLIENT_HPP */
