/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef __itc_time_support_hpp
#define __itc_time_support_hpp

#ifdef ITC_COMMON_CXX11
#include <chrono>
typedef std::chrono::system_clock::time_point ABSOLUTE_TIME;
typedef std::chrono::system_clock::duration RELATIVE_TIME;

#define ITC_TIME_NOW std::chrono::system_clock::now()
#define ITC_SECONDS(X) std::chrono::seconds(X)
#define ITC_MILLISECONDS(X) std::chrono::milliseconds(X)
#else
#include <boost/date_time/posix_time/posix_time_types.hpp>
typedef boost::posix_time::ptime ABSOLUTE_TIME;
typedef boost::posix_time::time_duration RELATIVE_TIME;

#define ITC_TIME_NOW boost::posix_time::microsec_clock::universal_time()
#define ITC_SECONDS(X) boost::posix_time::seconds(X)
#define ITC_MILLISECONDS(X) boost::posix_time::milliseconds(X)
#endif

#endif

