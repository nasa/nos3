/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

/**
    \file ChildProcess.hpp
*/
#ifndef ITC_PROCESS_CHILD_PROCESS_HPP
#define ITC_PROCESS_CHILD_PROCESS_HPP

#include <stdexcept>
#include <string>
#include <vector>

#include <signal.h>

#include <boost/noncopyable.hpp>

#include <itc_visibility.hpp>

#include <ItcProcess/ChildProcessCallback.hpp>
#include <ItcProcess/Config.hpp>
#include <ItcProcess/CouldNotChangeDirectory.hpp>
#include <ItcProcess/CouldNotRedirect.hpp>
#include <ItcProcess/CouldNotSetLibraryPath.hpp>
#include <ItcProcess/CoultNotSetEnv.hpp>
#include <ItcProcess/ExecutableNotFound.hpp>
#include <ItcProcess/IncompatibleOptions.hpp>
#include <ItcProcess/JobCreationFailure.hpp>
#include <ItcProcess/LaunchFailure.hpp>
#include <ItcProcess/NotRedirected.hpp>


/**
    \brief Redirect STDIN to a pipe to be retrieved using
    \ref ItcProcess::ChildProcess::get_stdin
*/
#define REDIRECT_STDIN  1

/**
    \brief Redirect STDOUT to a pipe to be retrieved using
    \ref ItcProcess::ChildProcess::get_stdout

    Mutually exclusive with \ref REDIRECT_STDOUT_NULL
*/
#define REDIRECT_STDOUT  2

/**
    \brief Redirect STDERR to a pipe to be retrieved using
    \ref ItcProcess::ChildProcess::get_stderr

    Mutually exclusive with \ref REDIRECT_STDERR_NULL
*/
#define REDIRECT_STDERR  4

/**
    \brief Redirect STDOUT to a NULL pipe

    Mutually exclusive with \ref REDIRECT_STDOUT
*/
#define REDIRECT_STDOUT_NULL  8

/**
    \brief Redirect STDERR to a NULL pipe

    Mutually exclusive with \ref REDIRECT_STDERR
*/
#define REDIRECT_STDERR_NULL  16


namespace ItcProcess
{
    class ChildProcessImpl;  //!< Forward declaration of PIMPL class
    struct ChildProcessImplData;  //!< Forward declaration of PIMPL class data structure

    /**
        \brief Launches a child process

        This class launches child processes and calls your callback when they exit.  You
        can also terminate the process once it's been running as well.

        Instances of this class may not be reused to re-launch a process that has
        died.  A new instance must be created each time a process needs to be launched.

        This class is not thread safe.
    */
    class DLL_PUBLIC ChildProcess : private boost::noncopyable
    {
    public:
        /**
            \brief Defines an environment variable as a map from a string name to
            its value.
        */
        typedef std::pair< std::string, std::string > EnvironmentVariable;

        /**
            \brief Basic constructor

            The subprocess will not be launched until the \ref launch_with_callback
            method is called.

            \param path      Path to executable
            \param filename  Filename of the executable
            \param options   Options to use when creating the subprocess
            \param num_args  Number of arguments in the following varargs list
            \param ...       Variatic arguments list

            \throw IncompatibleOptions  Mutually exclusive options were specified
        */
        ChildProcess(const char *path,
                     const char *filename,
                     unsigned int options = 0,
                     unsigned int num_args = 0,
                     ...)
        throw(ItcProcess::IncompatibleOptions);

        /**
            \brief Basic destructor

            If the subprocess is still running, it will be forcefully terminated.
        */
        ~ChildProcess();

        /* do not delete the callback until either it is called or this instance is deleted */
        /* once this call is made any errors will be signalled via the callback */
        /* if the executable is not found, then your callback will be called immediately with return code ChildProcessCallback::not_found_ret */
        /**
            \brief Launched the subprocess

            \param callback  Callback to receive notification when the subprocess exits

            \throw LaunchFailure  A general error occurred while attempting to launch the subprocess.
            \throw CouldNotChangeDirectory  The subprocess could not change its current
            working directory to the path set by \ref set_cwd
            \throw CouldNotRedirect  One or more STDIO pipes could not be redirected
            \throw CouldNotSetLibraryPath  The library path could not be updated
            \throw CouldNotSetEnv  One or more environment variables could not be updated
            \throw ExecutableNotFound  Named executable could not be found
            \throw JobCreationFailure  The OS job could not be created
        */
        void launch_with_callback(ChildProcessCallback *callback) throw(LaunchFailure);

        /**
            \brief Sends a signal to the subprocess

            Support for this method depends on the underlying OS.  In particular,
            Windows does not support signals.

            \param sig  Signal to send

            \throw std::logic_error  The process is not running
         */
        void signal(int sig = SIGTERM) throw(std::logic_error);

        /**
            \brief Forcefully terminates the process

            The callback provided to \ref launch_with_callback will not be notified
            in the event this method is called.  Presumably the caller of this function
            knows why the process should terminate and does not need additional
            notification.

            \throw std::logic_error  The process is not running
         */
        void terminate() throw(std::logic_error);

        /**
            \brief Appends an argument to the command line argument list

            \param arg  Argument to add

            \throw std::logic_error  The process is already running
        */
        void add_arg(const char *arg) throw(std::logic_error);

        /**
            \brief Sets the current working directory of the subprocess

            \param cwd  New current working directory.  May not be NULL

            \throw std::logic_error  The process is already running
        */
        void set_cwd(const char *cwd) throw(std::logic_error);

        /**
            \brief Utility method to retrieve the CWD of the calling process

            \return Current working directory

            \throw std::bad_alloc  An error occurred trying to allocate memory
            to store the CWd
        */
        static std::string get_cwd() throw(std::bad_alloc);

        /**
            \brief Adds a path to search for libraries

            Child process inherits paths from the parent; use this method to
            prepend paths to the search path

            \param path  New path to add

            \throw std::logic_error  The process is already running
        */
        void add_lib_path(const char *path) throw(std::logic_error);

        /**
            \brief Adds an environment variable for the child process

            \param name   Environment variable name
            \param value  Environment variable value

            \throw std::logic_error  The process is already running
        */
        void add_env(const char *name, const char *value) throw(std::logic_error);

        /**
            \brief Returns whether or not the child process is currently executing

            \return true if the child process is executing, false otherwise
         */
        bool is_running() const;

        /**
            \brief Retrieves the redirected STDIN pipe

            \return Redirected STDIN pipe

            \throw NotRedirected  The child process was not created with the
            \ref REDIRECT_STDIN option
        */
        FILE *get_stdin() throw(NotRedirected);

        /**
            \brief Retrieves the redirected STDOUT pipe

            \return Redirected STDOUT pipe

            \throw NotRedirected  The child process was not created with the
            \ref REDIRECT_STDOUT option
        */
        FILE *get_stdout() throw(NotRedirected);

        /**
            \brief Retrieves the redirected STDERR pipe

            \return Redirected STDERR pipe

            \throw NotRedirected  The child process was not created with the
            \ref REDIRECT_STDERR option
        */
        FILE *get_stderr() throw(NotRedirected);

    private:
        friend class ChildProcessImpl;
        friend struct ChildProcessImplData;

        ChildProcessCallback *callback;
        bool running;
        ChildProcessImpl *impl;

        std::string path;
        std::string name;
        std::string cwd;

        std::vector<std::string> args;
        std::vector<std::string> lib_path;
        std::vector<EnvironmentVariable> environment;

        unsigned int options;
        FILE *redirected_stdin;
        FILE *redirected_stdout;
        FILE *redirected_stderr;

        DLL_PRIVATE void callback_terminated(ChildProcessCallback::ExitCode return_code, bool sig);
        DLL_PRIVATE void check_options_and_throw() throw(ItcProcess::IncompatibleOptions);
        DLL_PRIVATE void check_for_running_and_throw() throw(std::logic_error);
        DLL_PRIVATE void check_for_not_running_and_throw() throw(std::logic_error);
        DLL_PRIVATE void add_first_arg();
    };
}

#endif /* ITC_PROCESS_CHILD_PROCESS_HPP */
