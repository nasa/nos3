/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_RECEIVER_DATA_CALLBACK_HPP
#define ITC_CCSDS_AOS_RECEIVER_DATA_CALLBACK_HPP

#include <itc_visibility.hpp>

#include <ItcCcsds/AosPrimaryHeader.hpp>

namespace ItcCcsds
{
    /**
        \brief Interface class to notify interested parties in AOS data.
    */
    class DLL_PUBLIC AosReceiverDataCallback
    {
    public:
        AosReceiverDataCallback()
        {}

        virtual ~AosReceiverDataCallback()
        {}

        /**
            \brief Called when data is found in an AOS frame.

            If the AOS frame contains M_PDUs, this method is called once for each and every
            valid (non-idle) space packet contained in the AOS frame.  When an overflow
            frame is found, the overflowing packet will be recombined with data from the
            next AOS frame in this channel.  This method will be called once the overflowing
            packet has been recombined.  The \ref dataLen parameter will be set to the length
            of the current space packet, in bytes.

            If the AOS frame contains B_PDUs, this method is called once for every AOS
            frame.  The \ref dataLen parameter will be set to the length of valid (non-idle) data,
            int bits, in the B_PDU segment.

            If the implementor of this method should not rely on this data being valid
            outside the context of this method.

            \param header   AOS primary header parsed from the message
            \param data     AOS data
            \param dataLen  AOS data length
        */
        virtual void aos_data(const AosPrimaryHeader *header,
                              const unsigned char *data,
                              const unsigned int dataLen) = 0;
    };
}

#endif /* ITC_CCSDS_AOS_RECEIVER_DATA_CALLBACK_HPP */
