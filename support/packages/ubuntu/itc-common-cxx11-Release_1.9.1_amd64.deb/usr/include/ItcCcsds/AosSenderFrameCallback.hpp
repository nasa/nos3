/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_SENDER_FRAME_CALLBACK_HPP
#define ITC_CCSDS_AOS_SENDER_FRAME_CALLBACK_HPP

#include <itc_visibility.hpp>

#include <ItcCcsds/AosPrimaryHeader.hpp>

namespace ItcCcsds
{
    /**
        \brief Interface class to notify interested parties in completed
        AOS frames
    */
    class DLL_PUBLIC AosSenderFrameCallback
    {
    public:
        AosSenderFrameCallback()
        {}

        virtual ~AosSenderFrameCallback()
        {}

        /**
            \brief Called when an AOS frame has been completed

            After insertion of enough data into an AOS frame, this method is called
            once from the same thread that inserted the data.

            \param data     AOS data
            \param dataLen  AOS data length
        */
        virtual void aos_frame(const unsigned char *data,
                               const unsigned int dataLen) = 0;
    };
}

#endif /* ITC_CCSDS_AOS_SENDER_FRAME_CALLBACK_HPP */
