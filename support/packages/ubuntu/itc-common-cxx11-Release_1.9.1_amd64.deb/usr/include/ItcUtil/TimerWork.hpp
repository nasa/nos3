/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef __TIMER_WORK_HPP
#define __TIMER_WORK_HPP

#include "ItcUtil/types.hpp"
#include <itc_thread_support.hpp>
#include <boost/noncopyable.hpp>

namespace ItcUtil
{
    /* you subclass this to do work in the timer */
    class DLL_PUBLIC TimerWork : public boost::noncopyable
    {
    public:
        TimerWork();

        /* override this to do work */
        virtual void operator()() throw() = 0;

    protected:
        /* WARNING: use timer::delete_work() do not call delete this */
        virtual ~TimerWork();

    private:
        friend class Timer;
        friend class Trampoline;
        friend class TimerTPWork;

        Timer *t;
        MUTEX m;
    };
}
#endif
