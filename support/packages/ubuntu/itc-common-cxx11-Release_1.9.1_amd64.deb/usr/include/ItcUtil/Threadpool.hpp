/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef __threadpool_HPP
#define __threadpool_HPP

#include <boost/noncopyable.hpp>

#include "ItcUtil/config.hpp"
#include <itc_thread_support.hpp>

#ifdef ITC_COMMON_CXX11
#include <functional>
#define BIND_LEGACY_WORKER(X,Y) std::bind(&X::operator(),&Y)
#else
#include <boost/function.hpp>
#include <boost/bind.hpp>
#define BIND_LEGACY_WORKER(X,Y) boost::bind(&X::operator(),&Y)
#endif

#include <list>
#include <map>
#include <string>
#include <queue>

#include <exception>

#include <ItcUtil/ItcAssert.hpp>

/* A threadpool allows work to be done on any one of multiple threads. The work can be
 asynchronous (work performed as fast as it is given to the pool) or it can be synchronized
 on a key. For example, if I have requests coming in from a socket from three nodes, and I
 want to process the requests in order for each of the three nodes, I can pass work off
 to the threadpool keyed on a node identifier. If I get 2 packets for node 1, 3 for node 2,
 and 1 for node 3, then all three nodes can be processed at the same time (assuming I have
 enough threads) but the second packet for a given node will not be processed until the first
 packet for that node is done.

 This threadpool is fair providing the work being done does not keep a hold of the threadpool's
 threads for an exceptionally long time. The threads rotate through available keys after
 work is completed to ensure that no set of keys is able to keep a hold of the threadpool
 */

/* TODO: consider abstracting away typing instead of limiting to const char*, std::string, and int */

/* RULES:
 1) Making a call to work() gives ownership of your threadpool_work object to the library. There is
    no copy.
 2) You cannot remove work before it is performed. Maintain external state if you need your work to
    not be performed after it is inserted.
 3) YOU ARE RESPONSIBLE FOR YOUR OWN SYNCHRONIZATION! If you know that your work is keyed, and so
    only one piece of work will be performed within one keyed domain, then you may not need to
    synchronize on anything within that domain. (this is a performance oriented hint;) )
 4) Calling remove_threads() may block until all possible threads can be removed.
 5) Unkeyed work guarantees no completion order whatsoever. However, starting order is guaranteed.
 6) You are welcome to delete your ThreadPoolWork subclass inside the callback providing you do
    not refer to the instance any further. This is the suggested method to clean up state.
 *********IMPORTANT******* Your work must catch all possible exceptions! If an exception
 is thrown in your thread and passed back to threadpool then in order to prevent std::terminate()
 from being called by passing it back up to boost threads, it will stop there. delete this; :)
 7) If you delete the threadpool, the destructor will block until all work is completed. Once
    in the destructor, you will not be able to add any more work to this thread pool.
 8) Do not delete the threadpool or call remove_threads() from your own work. This is bad!
*/
namespace ItcUtil
{
#ifdef ITC_COMMON_CXX11
typedef std::function<void()> ThreadPoolWork;
#else
typedef boost::function<void()> ThreadPoolWork;
#endif

    class DLL_PUBLIC ThreadPoolInvalidKey : public std::exception
    {
    public:
        explicit ThreadPoolInvalidKey(const std::string &key);
        explicit ThreadPoolInvalidKey(int key);

        virtual ~ThreadPoolInvalidKey() throw();
        virtual const char *what() const throw();

        /* the user knows what type of key they are using, so they should know what type to retrieve */
        const char *cstr_skey() const;
        const int ikey;
        const std::string skey;
    private:
        ThreadPoolInvalidKey &operator=(const ThreadPoolInvalidKey &to_copy);
    };

    class DLL_PUBLIC ThreadPoolClosing : public std::exception
    {
    public:
        virtual const char *what() const throw();
    };

    class DLL_PUBLIC ThreadPool : private boost::noncopyable
    {
    public:
        explicit ThreadPool(int n_threads) throw(std::bad_alloc);
        ~ThreadPool(); /* blocks until all work is completed! */

        int get_num_threads() const;

        bool is_closing() const throw();

        /* add_threads() blocks minimally on threadpool internal mutex but not on work */
        void add_threads(int n_threads) throw(std::bad_alloc, ThreadPoolClosing);

        /* remove_threads() will block until n_threads threads are removed. at least 1 thread must remain
         in the threadpool. the return value specifies the number of threads left */
        int remove_threads(int n_threads);

        /* perform some work in the threadpool */
        /* using an empty string is the same as having no key */
        void work(ThreadPoolWork work, bool sync = false) throw(std::bad_alloc, ThreadPoolClosing);
        void work(ThreadPoolWork work, const char *key, bool sync = false) throw(std::bad_alloc, ThreadPoolClosing);
        void work(ThreadPoolWork work, const std::string &key, bool sync = false) throw(std::bad_alloc, ThreadPoolClosing);
        void work(ThreadPoolWork work, int key, bool sync = false) throw(std::bad_alloc, ThreadPoolClosing);

    private:
        class ThreadPoolWorker : private boost::noncopyable
        {
        public:
            ThreadPoolWorker(ThreadPool &parent);
            ~ThreadPoolWorker();

            void operator()();

            bool is_busy() const
            {
                return busy;
            }

            THREAD *thread;
        private:
            ThreadPool &parent;
            bool busy;
        };

        std::list<ThreadPoolWorker *> join_us; /* list of threads waiting to be cleaned up */

        typedef std::queue<ThreadPoolWork> WorkQueue;
        typedef std::pair<WorkQueue, bool> WorkerPair;
        typedef std::map<const std::string, WorkerPair > WorkerMap;
        WorkerMap worker_map;
        WorkerMap::iterator worker_map_iterator;

        MUTEX m;
        CONDITION_V cond;
        CONDITION_V closing_cond;

        void create_thread() throw(std::bad_alloc);

        int num_threads;
        volatile int going_down;
        volatile bool closing;

        void work_helper(const std::string &key, ThreadPoolWork work, bool sync);

        typedef std::pair<const std::string, ThreadPoolWork> WorkResult_type;
        WorkResult_type get_next_work();
    };
}

#endif
