/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef __itc_thread_support_hpp
#define __itc_thread_support_hpp

#include <itc_time_support.hpp>

#ifdef ITC_COMMON_CXX11
#include <mutex>
#include <thread>
#include <condition_variable>

typedef std::thread             THREAD;
typedef std::mutex              MUTEX;
typedef std::condition_variable CONDITION_V;

typedef std::lock_guard<std::mutex>  LOCK_GUARD;
typedef std::unique_lock<std::mutex> UNIQUE_LOCK;

namespace THIS_THREAD = std::this_thread;
#define THREAD_SLEEP(X) std::this_thread::sleep_for(X)
#define THREAD_SECONDS(X) std::chrono::seconds(X)
#define THREAD_YIELD std::this_thread::yield()
#define CONDITION_V_SECONDS(X) std::chrono::seconds(X)
#define CONDITION_V_MILLISECONDS(X) std::chrono::milliseconds(X)
#define CONDITION_V_WAIT_FOR(obj, lock, Y) obj.wait_for(lock, Y)
#define CONDITION_V_WAIT_ABS(obj, lock ,Y) obj.wait_until(lock, Y)
#define CONDITION_V_WAIT_NOTIMEOUT std::cv_status::no_timeout
#define CONDITION_V_WAIT_TIMEOUT std::cv_status::timeout
#define REF(X) std::ref(X)
#define DEFER_LOCK std::defer_lock
#define DO_LOCK std::lock
#else
#include <boost/chrono/duration.hpp>
#include <boost/thread/locks.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition_variable.hpp>
#include <boost/ref.hpp>
typedef boost::thread               THREAD;
typedef boost::mutex                MUTEX;
typedef boost::condition_variable   CONDITION_V;

typedef boost::lock_guard<boost::mutex>     LOCK_GUARD;
typedef boost::unique_lock<boost::mutex>    UNIQUE_LOCK;

namespace THIS_THREAD = boost::this_thread;
#define THREAD_SLEEP(X) ::boost::this_thread::sleep(X)
#define THREAD_SECONDS(X) ::boost::posix_time::seconds(X)
#define THREAD_YIELD ::boost::thread::yield()
#define CONDITION_V_SECONDS(X) ::boost::posix_time::seconds(X)
#define CONDITION_V_MILLISECONDS(X) ::boost::posix_time::milliseconds(X)
#define CONDITION_V_WAIT_FOR(obj, lock, Y) obj.timed_wait(lock, Y)
#define CONDITION_V_WAIT_ABS(obj, lock, Y) obj.timed_wait(lock, Y)
#define CONDITION_V_WAIT_NOTIMEOUT true
#define CONDITION_V_WAIT_TIMEOUT false
#define REF(X) ::boost::ref(X)
#define DEFER_LOCK ::boost::defer_lock
#define DO_LOCK ::boost::lock
#endif

#endif
