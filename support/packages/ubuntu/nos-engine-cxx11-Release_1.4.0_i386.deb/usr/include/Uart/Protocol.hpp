/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UART_PROTOCOL_HPP
#define NOS_ENGINE_UART_PROTOCOL_HPP

#include <Uart/visibility.hpp>

#include <Utility/Buffer.hpp>

#include <string>
#include <cstdint>

namespace NosEngine
{
    namespace Uart
    {
        /*
         * \brief UART protocol command type
         */
        enum class CommandType
        {
            UART_OPEN,
            UART_CLOSE
        };

        /*
         * \brief UART protocol command
         */
        struct NOS_ENGINE_UART_API_PUBLIC ProtoCommand
        {
            /*
             * \brief Constructor
             *
             * \param type Protocol command type
             * \param port UART port number
             * \param name UART data node name
             */
            ProtoCommand(CommandType type, uint8_t port, const std::string& name);

            /*
             * \brief Deserialize buffer to protocol command
             *
             * \param buffer Raw data buffer
             */
            ProtoCommand(const Utility::Buffer& buffer);

            /*
             * \brief Serialize command into buffer
             *
             * \return Serialized buffer
             */
            Utility::Buffer serialize();

            /*
             * \brief Deserialize buffer to protocol command
             *
             * \param buffer Raw data buffer
             */
            void deserialize(const Utility::Buffer& buffer);

            CommandType type; //!< Protocol command type
            uint8_t port; //!< UART port number
            std::string name; //!< UART data node name
        };
    }
}

#endif

