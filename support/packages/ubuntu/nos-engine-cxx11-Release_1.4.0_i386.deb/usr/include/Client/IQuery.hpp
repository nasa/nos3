/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IQUERY_HPP
#define NOS_ENGINE_CLIENT_IQUERY_HPP

#include <string>
#include <vector>

#include <Common/Query/QueryProtocol.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \brief Provides server management capabilities.
        ///
        class IQuery :
            public virtual Utility::IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the IQuery class.
            ///
            virtual ~IQuery() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Query the server for a list of currently active busses.
            ///
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return list of bus names
            ///
            virtual std::vector<std::string> query_buses(
                const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Query the server for a list of nodes on a particular bus.
            ///
            /// \param bus_name bus of interest
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return list of nodes on the bus
            ///
            virtual std::vector<Common::QueryProtocol::NodeInformation> query_data_nodes(
                const std::string& bus_name,
                const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;
                
            ///
            /// \brief Query the system on a protocol level.
            ///
            /// \param bus_name Name of the bus the query is for
            /// \param query    Packed query. Protocol libraries should assist in creating the buffer
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return Complete message from the server. Users should know how to process this
            ///
            virtual Common::Message query_protocol(
                const std::string& bus_name, Utility::Buffer query,
                const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            // TODO: Revisit
            //virtual void query_interceptors(std::string query_string, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;
            //virtual void modify_data_logging(std::string update_string, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;
        };
    }
}

#endif