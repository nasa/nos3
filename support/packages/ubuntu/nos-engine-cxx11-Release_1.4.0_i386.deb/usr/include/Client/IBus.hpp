/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IBUS_HPP
#define NOS_ENGINE_CLIENT_IBUS_HPP

#include <Utility/Events/IOnDestroy.hpp>

#include <Transport/TransportHub.hpp>

#include <Common/Bus/BusProtocol.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \brief Represents the client side version of a bus on the server.
        ///
        class IBus :
            public virtual Utility::IEngineThreadSafeObject,
            public virtual Utility::Events::IOnDestroy
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the IBus class.
            ///
            virtual ~IBus() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the transport hub used by this instance.
            ///
            /// If the instance owns the hub (ie hub was not provided to the constructor) then use
            /// the hub returned with caution.  When this instance is destroyed the hub it owns
            /// will be destroyed as well.
            ///
            /// \return The tranport hub of this instance.
            ///
            virtual Transport::TransportHub &get_transport_hub() const = 0;

            ///
            /// \brief Get the name of the bus.
            ///
            /// \return the bus name
            ///
            virtual std::string get_name() const = 0;

            ///
            /// \brief Get the connection status of the bus.
            ///
            /// \return True if the bus is connected.
            ///
            virtual bool is_connected() const = 0;

            ///
            /// \brief Get the bus registration flags.
            ///
            /// \return the registration flags
            ///
            virtual Common::BusRegistrationFlags get_registration_flags() const = 0;

            ///
            /// \brief Get a node from the bus.
            ///
            /// This method will not create and register a node on the bus if it does not exist.
            /// The name for the node must be unique at the bus-level (does not have to be globally unique across all busses)
            ///
            /// \param name  unique name for the node
            ///
            virtual DataNode* get_data_node(std::string name) = 0;

            ///
            /// \brief Get a node from the bus. If the node does not exist, it is created.
            ///
            /// This method will create and register a node on the bus if it does not already exist.
            /// The name for the node must be unique at the bus-level (does not have to be globally unique across all busses)
            ///
            /// \param name     unique name for the node
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual DataNode* get_or_create_data_node(std::string name,
                                                      const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Remove an existing data node from the system.
            ///
            /// This method will remove a data node from the system if possible. In the event that the data node is not
            /// known to this Bus object, the operation will simply return.
            ///
            /// \param name     Name of the node to remove
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void remove_data_node(const std::string& name,
                                          const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Get an interceptor from the bus.
            ///
            /// This method will not create an interceptor if it does not exist.
            ///
            /// \param name  name of the interceptor
            ///
            /// \return the interceptor
            ///
            /// \throw runtime_error node not found
            ///
            virtual InterceptorNode* get_interceptor(const std::string& name) const = 0;

            ///
            /// \brief Get an interceptor from the bus, and create one if it doesn't already exist.
            ///
            /// \param name       name of the interceptor
            /// \param target     target node to intercept
            /// \param direction  direction of messages to intercept
            ///
            /// \throw runtime_error Node name is already in use by a non-interceptor
            ///
            virtual InterceptorNode* get_or_create_interceptor(const std::string& name,
                                                               const std::string& target,
                                                               Common::BusProtocol::InterceptorDirection direction,
                                                               const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Remove an existing interceptor from the system.
            ///
            /// This method will remove an interceptor from the system if possible. In the event that the interceptor is not
            /// known to this Bus object, the operation will simply return.
            ///
            /// \param name     Name of the interceptor to remove
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void remove_interceptor(const std::string& name,
                                            const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Enable setting time on the bus.
            ///
            /// This method may only be called once for a given bus.
            ///
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \throw runtime_error if time setting already enabled
            ///
            virtual void enable_set_time(const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Set time on the bus.
            ///
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \throw runtime_error if time setting is not enabled
            ///
            virtual void set_time(NosEngine::Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Add a time tick callback to the bus.
            ///
            /// \param callback The callback
            /// \return The callback ID for use with remove_time_tick_callback()
            ///
            virtual TimeTickCallbackId add_time_tick_callback(TimeTickCallbackFunc callback) = 0;

            ///
            /// \brief Remove a time tick callback from the bus.
            ///
            /// \param callback_id Callback ID from add_time_tick_callback()
            ///
            virtual void remove_time_tick_callback(TimeTickCallbackId callback_id) = 0;

            ///
            /// \brief Get the current bus time (last time sent on the bus).
            ///
            /// \return the simulation time
            ///
            virtual NosEngine::Common::SimTime get_time() const = 0;

            ///
            /// \brief Set a timer for an absolute sim time; callback will be called at or after that time.
            ///
            /// Time should be on a time tick; otherwise, the callback will not be called until
            /// the following time tick.
            ///
            /// Time must be in the future; otherwise, an exception will be thrown.
            ///
            /// \param time absolute time after which to call callback
            ///
            virtual void set_timer_absolute(NosEngine::Common::SimTime time, BusTimerCallback callback) = 0;

            ///
            /// \brief Set a timer for a relative sim time; callback will be when that much time, or more, has elapsed.
            ///
            /// Time should be on a time tick; otherwise, the callback will not be called until
            /// the following time tick.
            ///
            /// Time must be > 0; otherwise, an exception will be thrown.
            ///
            /// \param time time duration after which to call callback
            ///
            virtual void set_timer_relative(NosEngine::Common::SimTime time, BusTimerCallback callback) = 0;

            // TODO: Implement inject_message
            //virtual void inject_message(InjectedMessage to_inject) = 0;

            ///
            /// \brief Send a control message that will be handled by the server protocol for
            /// the bus.
            ///
            /// \param data The data for the control message.
            ///
            /// \return The response from the server.
            ///
            virtual Common::Message send_protocol_control_message(const Utility::Buffer& data) const = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the TimeClient for this Bus.
            ///
            /// \return The TimeClient for this Bus.
            ///
            virtual TimeClient *get_time_client() = 0;

            friend class BusRouter; // For get_time_client()
        };
    }
}

#endif