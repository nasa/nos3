/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_TIME_CLIENT_HPP
#define NOS_ENGINE_CLIENT_TIME_CLIENT_HPP

#include <functional>

#include <Client/types.hpp>
#include <Client/ITimeClient.hpp>
#include <Client/Node.hpp>

namespace NosEngine
{
    namespace Client
    {
        class NOS_ENGINE_CLIENT_API_PUBLIC TimeClient :
            public ITimeClient,
            public Node
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the TimeClient class.
            ///
            /// \copydetails Node::Node()
            ///
            TimeClient(const std::string &name,
                       IBus &bus,
                       Common::NodeID &id,
                       Common::ITransactionManager *manager,
                       const Common::WeakSendOperator &transport);

        private:
            TimeClient(const TimeClient&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the TimeClient class.
            ///
            virtual ~TimeClient();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TimeClient& operator=(const TimeClient&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ITimeClient implementation
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;
            
            virtual Common::SimTime get_time() const;

            virtual void set_time_tick_callback(TimeTickCallbackFunc callback);
            
            // TODO: synchronous wait-for/wait-until (relative, absolute)
            //
            // if no callback is registered, call the default callback (this will check if there are any wait-for type calls being made)
            //
            // change of design from document: creation of time client will not block if sender is not registered 
            // time will be invalid. Calls to wait for tick will block though
            //
            // Question: what to do about rollover?
            
        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called when a time tick is received.
            ///
            /// \param msg The time tick Message that was received.
            ///
            virtual void time_received(Common::Message msg);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            NosEngine::Common::SimTime time;    //!< The last time received.
            TimeTickCallbackFunc user_callback; //!< Time tick user callback.

            friend class Bus;
        };

    }

}

#endif // NOS_ENGINE_CLIENT_TIME_CLIENT_HPP