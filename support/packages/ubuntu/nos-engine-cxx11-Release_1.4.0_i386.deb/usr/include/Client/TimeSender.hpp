/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_TIME_SENDER_HPP
#define NOS_ENGINE_CLIENT_TIME_SENDER_HPP

#include <Client/types.hpp>
#include <Client/ITimeSender.hpp>
#include <Client/Node.hpp>

namespace NosEngine
{
    namespace Client
    {
        class NOS_ENGINE_CLIENT_API_PUBLIC TimeSender :
            public ITimeSender,
            public Node
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the TimeSender class.
            ///
            /// \copydetails Node::Node()
            ///
            TimeSender(const std::string &name,
                       IBus &bus,
                       Common::NodeID &id,
                       Common::ITransactionManager *manager,
                       const Common::WeakSendOperator &transport);

        private:
            TimeSender(const TimeSender&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the TimeSender class.
            ///
            virtual ~TimeSender();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TimeSender& operator=(const TimeSender&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;

            virtual Common::SimTime get_last_sent_time() const;
            
            virtual void send_time(const Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT);
            
        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Build a time message for the specified time.
            ///
            /// \param time The time for the message.
            ///
            /// \return The time message.
            ///
            Common::Message build_message(const Common::SimTime time);

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------
            
            Common::SimTime last_sent_time;  //!< The last time that was sent to clients.

            friend class Bus;
        };
        
    }
}


#endif // NOS_ENGINE_CLIENT_TIME_SENDER_HPP
