/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_INTERCEPTOR_NODE_HPP
#define NOS_ENGINE_CLIENT_INTERCEPTOR_NODE_HPP

#include <string>

#include <Client/types.hpp>
#include <Client/IInterceptorNode.hpp>
#include <Client/Node.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \copydoc IInterceptorNode
        ///
        class NOS_ENGINE_CLIENT_API_PUBLIC InterceptorNode :
            public IInterceptorNode,
            public Node
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate an interceptor node.
            ///
            /// \param name       name of the node
            /// \param bus_name   name of the bus node belongs to
            /// \param id         unique node ID
            /// \param target     name of target node
            /// \param manager    manager for handling node transactions
            /// \param transport  transport to send messages to server
            ///
            InterceptorNode(const std::string &name,
                            IBus &bus,
                            const Common::NodeID &id,
                            const std::string& target,
                            Common::ITransactionManager *manager,
                            const Common::WeakSendOperator &transport);

        private:
            InterceptorNode(const InterceptorNode&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the InterceptorNode class.
            ///
            virtual ~InterceptorNode();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            InterceptorNode& operator=(const InterceptorNode&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IInterceptorNode implementation
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;

            virtual std::string get_target_name() const;

            virtual void set_interceptor_function(InterceptorFunction function);
            
            virtual InterceptorFunction get_interceptor_function();

            virtual void send_pass_response(const Common::Message& original) const;

            virtual void send_block_response(const Common::Message& original) const;

            virtual void send_modified_response(const Common::Message& original, size_t length, char *modified_data);

            virtual void send_mimic_response(const Common::Message& original, size_t length, char *mimic_data);

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            virtual void message_received(Common::Message);

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            const std::string target_node; //!< name of target node

        private:
            InterceptorFunction function;

            friend class Bus; //TODO: Re-evaluate this design
        };           
    }
}


#endif
