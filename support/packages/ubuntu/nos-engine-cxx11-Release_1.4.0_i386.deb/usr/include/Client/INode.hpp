/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_INODE_HPP
#define NOS_ENGINE_CLIENT_INODE_HPP

#include <Utility/Queue.hpp>

#include <Common/INode.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \brief The node class is a base class for multiple types of nodes.
        ///
        /// The node class provides the common capabilities needed for communicating
        /// with the server.
        ///
        class INode :
            public virtual Common::INode,
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

        public:
            ///
            /// \brief Destructor for an instance of the INode class.
            ///
            virtual ~INode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the parent Bus.
            ///
            /// \return Parent Bus.
            ///
            virtual IBus &get_bus() = 0;

            ///
            /// \brief Get the Node name.
            ///
            /// \return The name of this Node.
            ///
            virtual std::string get_name() const = 0;

            ///
            /// \brief Get the Node id.
            ///
            /// \return The id of this Node.
            ///
            virtual Common::NodeID get_id() const = 0;

            ///
            /// \brief Set the message received callback.
            ///
            /// The user-specified function will be called each time the Node receives a
            /// message.
            ///
            /// \param callback Function to call when messages are received. Pass nullptr to
            ///                 disable the callback.
            ///
            virtual void set_message_received_callback(MessageReceivedFunction callback) = 0;

            ///
            /// \brief Get the message received callback.
            ///
            /// \return The message received callback.
            ///
            virtual MessageReceivedFunction get_message_received_callback() = 0;

            ///
            /// \brief Perform a non-confirmed send of data to another node.
            ///
            /// This send operation makes a best-effort attempt to deliver data. Messages are
            /// not guaranteed to arrive in the order they were originally sent in.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            ///
            virtual void send_non_confirmed_data(const std::string& destination, size_t length, const char* data) const = 0;

            ///
            /// \brief Send a confirmed data message to another node.
            ///
            /// This send operation attempts to deliver a message and waits for confirmation.
            /// The method will block until the message delivery has been confirmed.
            ///
            /// \param destination  name of destination node
            /// \param length       length of data
            /// \param data         pointer to data
            /// \param timeout      timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void send_confirmed_data(std::string destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Send a confirmed message to another node.
            ///
            /// This send operation attempts to deliver a message and waits for confirmation.
            /// The method will block until the message delivery has been confirmed.
            ///
            /// \param message  message to send
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void send_confirmed_message(Common::Message message, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Perform a confirmed-send of data to another node.
            ///
            /// This send operation attempts to deliver a message and waits for confirmation.
            /// This method will not block, and instead will call the confirmation callback when delivery has been confirmed.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param confirmation  callback function
            ///
            /// \return the transaction ID for the operation (useful if re-using callback for multiple operations)
            ///
            virtual Common::TransactionID send_confirmed_data(std::string destination, size_t length, const char* data, ConfirmationFunction confirmation) const = 0;

            ///
            /// \brief Send data to and wait for a response from the destination node.
            ///
            /// This send operation will deliver a message to another node and wait for a response.
            /// This method will block until the response has been received.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param timeout       timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return response from other node
            ///
            virtual Common::Message send_request(const std::string& destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Send data to another node and get the response.
            ///
            /// This send operation will deliver a message to another node and wait for a response.
            /// This method will block until the response has been received.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param reply         callback function
            ///
            /// \return the transaction ID for the operation (useful if re-using callback for multiple operations)
            ///
            virtual Common::TransactionID send_request(const std::string& destination, size_t length, const char* data, ReplyReceivedFunction reply) const = 0;

            ///
            /// \brief Reply to a request message from another node.
            ///
            /// \param to_send   response message
            ///
            virtual void send_reply(Common::Message to_send) const = 0;

            ///
            /// \brief Receive a message (blocking).
            ///
            /// This method waits for the Node to receive a message, and returns it to the
            /// caller.
            ///
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return The received message.
            ///
            virtual Common::Message receive_message(const size_t &timeout = RECEIVE_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Get the last time received.
            ///
            /// \return The received time.
            ///
            virtual Common::SimTime get_time() const = 0;
        };
    }
}

#endif