/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_ITIME_SENDER_HPP
#define NOS_ENGINE_CLIENT_ITIME_SENDER_HPP

#include <Client/types.hpp>
#include <Client/INode.hpp>

namespace NosEngine
{
    namespace Client
    {
        class ITimeSender :
            public virtual INode
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the TimeSender class.
            ///
            virtual ~ITimeSender() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the last time that was sent.
            ///
            /// \return The last sent time.
            ///
            virtual Common::SimTime get_last_sent_time() const = 0;
            
            ///
            /// \brief Send (broadcast) the specified time to TimeClient(s).
            ///
            /// TimeClient(s) which receive the message and block for a period of time will also
            /// cause this call to block (because this is a confirmed broadcast).
            /// If a timeout is specified, and the TimeClient(s) block for too long this call
            /// will timeout.
            ///
            /// \param time     The time to send.
            /// \param timeout  The duration to wait for a response from the server.
            ///
            virtual void send_time(const Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;
        };
        
    }
}


#endif // NOS_ENGINE_CLIENT_TIME_SENDER_HPP
