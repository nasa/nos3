/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_ERROR_DETAILS_HPP
#define NOS_ENGINE_UTILITY_ERROR_ERROR_DETAILS_HPP

#include <cstdarg>
#include <string>

#include <Utility/Types.hpp>
#include <Utility/Error/Detail/IErrorDetails.hpp>
#include <Utility/Error/Detail/ErrorTrace.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Detail
            {
                /// 
                /// \brief Represents error details for an error.
                /// 
                class NOS_ENGINE_UTILITY_API_PUBLIC ErrorDetails : virtual public IErrorDetails
                {
                public:
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    ErrorDetails();

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    /// \param message An error message.
                    /// 
                    ErrorDetails(const std::string &message);

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    /// \param fmt A printf style format string.
                    /// \param ap va_list for printf style format string.
                    /// 
                    ErrorDetails(const char *fmt, std::va_list &ap);

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    /// \param error_code An error code.
                    /// 
                    ErrorDetails(const ErrorCode &error_code);

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    /// \param error_code An error code.
                    /// \param message An error message.
                    /// 
                    ErrorDetails(const ErrorCode &error_code, const std::string &message);

                    /// 
                    /// \brief Construct an instance of the ErrorDetails class.
                    /// 
                    /// \param error_code An error code.
                    /// \param fmt A printf style format string.
                    /// \param ap va_list for printf style format string.
                    /// 
                    ErrorDetails(const ErrorCode &error_code, const char *fmt, std::va_list &ap);

                    /// 
                    /// \brief Destructor for an instance of the ErrorDetails class.
                    /// 
                    virtual ~ErrorDetails();

                    // ============================================================================
                    // Operators
                    // ----------------------------------------------------------------------------

                    // ----------------------------------------------------------------------------
                    // IErrorDetails implementation
                    // ----------------------------------------------------------------------------

                    virtual bool operator==(const IErrorDetails &other) const;

                    virtual bool operator!=(const IErrorDetails &other) const;

                    virtual operator bool() const;

                    // ============================================================================
                    // Public API
                    // ----------------------------------------------------------------------------

                    // ----------------------------------------------------------------------------
                    // IErrorDetails implementation
                    // ----------------------------------------------------------------------------

                    virtual const ErrorCode &get_error_code() const;

                    virtual const std::string &get_message() const;

                    virtual const std::string get_trace(const bool &multiline = false) const;

                    virtual void trace_append(const std::string &file, const std::string &function, const uint32_t &line);

                    // ============================================================================
                    // Data members
                    // ----------------------------------------------------------------------------

                    std::string message;    //!< Error message describing this error
                    ErrorCode error_code;   //!< Error code of this error
                protected:
                    ErrorTrace error_trace; //!< NOS generated partial backtrace
                };
            }
        }
    }
}

#endif