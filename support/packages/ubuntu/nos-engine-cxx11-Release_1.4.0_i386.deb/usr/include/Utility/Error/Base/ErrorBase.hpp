/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_ERROR_BASE_HPP
#define NOS_ENGINE_UTILITY_ERROR_ERROR_BASE_HPP

#include <Utility/Types.hpp>
#include <Utility/Error/Base/IErrorBase.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Base
            {
                /// 
                /// \brief Represents the base class for all error classes.
                /// 
                /// All error classes need to derive directly from this class.
                /// This class uses the curiously recurring template pattern (CRTP).
                /// 
                /// \param ERROR_C CRTP class.
                /// \param BASE_C Error class which ErrorBase will derive from.
                /// \param IMPL_IFACE_C Error implementation interface class.
                /// 
                template<class ERROR_C, class BASE_C = void, class IMPL_IFACE_C = Implementation::IErrorImpl>
                class ErrorBase : public BASE_C
                {
                protected:
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Construct an instance of the ErrorBase class.
                    /// 
                    /// \param impl The underlying error implemenation instance.
                    /// 
                    ErrorBase(IMPL_IFACE_C *impl);

                    /// 
                    /// \brief Copy constructor.
                    /// 
                    ErrorBase(const ErrorBase &other);

                    /// 
                    /// \brief Move constructor.
                    /// 
                    ErrorBase(ErrorBase &&other);

                public:
                    /// 
                    /// \brief Destructor for an instance of the ErrorBase class.
                    /// 
                    virtual ~ErrorBase();

                    // ============================================================================
                    // Operators
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Assignment operator.
                    /// 
                    ErrorBase &operator=(const ErrorBase &other);

                    /// 
                    /// \brief Move operator.
                    /// 
                    ErrorBase &operator=(ErrorBase &&other);

                    // ============================================================================
                    // Public API
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Create an error from the error implentation instance.
                    /// 
                    /// \return An error.
                    /// 
                    static ERROR_C from_impl(const IMPL_IFACE_C *const impl);

                    // ----------------------------------------------------------------------------
                    // IErrorBase implementation
                    // ----------------------------------------------------------------------------

                    virtual const IErrorType &get_type() const;

                    virtual IMPL_IFACE_C &get_impl() const;
                };
            }
        }
    }
}

#include <Utility/Error/Base/ErrorBase.ipp>

#endif