/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_IERROR_IMPL_HPP
#define NOS_ENGINE_UTILITY_ERROR_IERROR_IMPL_HPP

#include <string>

#include <Utility/Types.hpp>
#include <Utility/Error/Base/ErrorType.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Implementation
            {
                /// 
                /// \brief Interface for error implementation class.
                /// 
                class NOS_ENGINE_UTILITY_API_PUBLIC IErrorImpl
                {
                public:
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Destructor for an instance of the IErrorImpl class.
                    /// 
                    virtual ~IErrorImpl() = 0;

                    // ============================================================================
                    // Operators
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Equality operator.
                    /// 
                    /// \return True if this is equal to other.
                    /// 
                    virtual bool operator==(const IErrorImpl &other) const = 0;

                    /// 
                    /// \brief In-equality operator.
                    /// 
                    /// \return True if this is not equal to other.
                    /// 
                    virtual bool operator!=(const IErrorImpl &other) const = 0;

                    /// 
                    /// \brief Boolean operator returns value indicating if this represents and error.
                    /// 
                    /// \return True if this represents an error.
                    /// 
                    virtual operator bool() const = 0;

                    // ============================================================================
                    // Public API
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Get the type of the error.
                    /// 
                    /// \return The error type.
                    /// 
                    virtual const Base::IErrorType &get_type() const = 0;

                    /// 
                    /// \brief Get error details.
                    /// 
                    /// \return The error details instance.
                    /// 
                    virtual const Detail::IErrorDetails &get_details() const = 0;

                    /// 
                    /// \brief Get the error code from the error details.
                    /// 
                    /// \return The error code.
                    /// 
                    virtual const ErrorCode &get_error_code() const = 0;

                    /// 
                    /// \brief Get the error message from the error details.
                    /// 
                    /// \return The error message.
                    /// 
                    virtual const std::string &get_message() const = 0;

                    /// 
                    /// \brief Get NOS generated partial backtrace string.
                    /// 
                    /// \param multiline True to generate a multiline backtrace (defaults to single line).
                    /// 
                    /// \return The partial backtrace.
                    /// 
                    virtual const std::string get_trace(const bool &multiline) const = 0;

                    /// 
                    /// \brief Get the error message combine with the backtrace.
                    /// 
                    /// \param multiline True to generate a multiline backtrace (defaults to single line).
                    /// 
                    /// \return The error message and backtrace.
                    /// 
                    virtual std::string get_message_and_trace(const bool &multiline = false) const = 0;

                    /// 
                    /// \brief Append an entry into the backtrace for this error.
                    /// 
                    /// \param file Source file name.
                    /// \param function Name of function or class method in the source file.
                    /// \param line Source file line number.
                    /// 
                    virtual void trace_append(const std::string &file, const std::string &function, const uint32_t &line) = 0;

                    /// 
                    /// \brief Throw an error that correctly represents this error implementation.
                    /// 
                    virtual void throw_error() const = 0;

                    /// 
                    /// \brief Creates a clone of this error implementation.
                    /// 
                    /// \return The clone.
                    /// 
                    virtual IErrorImpl *clone() const = 0;
                };
            }
        }
    }
}

#endif