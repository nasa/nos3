/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_NULL_ARGUMENT_ERROR_HPP
#define NOS_ENGINE_UTILITY_ERROR_NULL_ARGUMENT_ERROR_HPP

#include <Utility/Error/InvalidArgument.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            class NOS_ENGINE_UTILITY_API_PUBLIC NullArgumentError : public Base::ErrorBase<NullArgumentError, InvalidArgument>
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Construct an instance of the NullArgumentError class.
                /// 
                NullArgumentError();

                /// 
                /// \brief Construct an instance of the NullArgumentError class.
                /// 
                /// \param name The name of the argument.
                /// 
                NullArgumentError(const std::string &name);

                /// 
                /// \brief Construct an instance of the NullArgumentError class.
                /// 
                /// \param name The name of the argument.
                /// \param details Additional error details.
                /// 
                NullArgumentError(const std::string &name, const std::string &details);

                // ================================================================================
                // Data members
                // --------------------------------------------------------------------------------

                static const std::string MESSAGE; //!< base error message
            };
        }
    }
}

#endif