/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_TYPES_HPP
#define NOS_ENGINE_UTILITY_TYPES_HPP

#include <cstdlib>
#include <cstdint>
#include <functional>
#include <chrono>
#include <vector>
#include <list>
#include <map>
#include <deque>

#include <Utility/Visibility.hpp>
#include <Utility/Fwd.hpp>

#include <Utility/IEngineObject.hpp>
#include <Utility/IEngineThreadSafeObject.hpp>

#if defined(__GNUC__)
#define NE_FORMAT_GUARD(A,B) __attribute__((__format__ (printf,A,B)))
#else
#define NE_FORMAT_GUARD(A,B)
#endif

namespace NosEngine {
namespace Utility {
typedef size_t CallbackId;

typedef std::function<void(void)> Work;
typedef std::function<void(const bool)> CancelableWork;

typedef size_t TimerId;
typedef CancelableWork TimerQueueCallback;
typedef std::chrono::steady_clock TimerQueueClock;
typedef TimerQueueClock::time_point TimerQueueTimepoint;
typedef TimerQueueClock::duration TimerQueueDuration;

typedef int64_t ErrorCode;
typedef std::function<void(const Utility::Error::Error &)> OnErrorCallback;

typedef size_t Timeout;
typedef std::chrono::system_clock TimeoutClock;
}}

#endif

