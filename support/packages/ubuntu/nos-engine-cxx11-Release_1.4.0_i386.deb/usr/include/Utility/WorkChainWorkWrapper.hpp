/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_WORK_CHAIN_WORK_WRAPPER_HPP
#define NOS_ENGINE_UTILITY_WORK_CHAIN_WORK_WRAPPER_HPP

#include <Utility/Types.hpp>
#include <Utility/IWorkChainWorkWrapper.hpp>
#include <Utility/Error/InvalidArgument.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \copydoc IWorkChainWorkWrapper
        ///
        class NOS_ENGINE_UTILITY_API_PUBLIC WorkChainWorkWrapper :
            public IWorkChainWorkWrapper
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void()>)> work,
                std::function<void()> callback);

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            template<typename T1>
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void(T1)>)> work,
                std::function<void(T1)> callback);

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            template<typename T1, typename T2>
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void(T1, T2)>)> work,
                std::function<void(T1, T2)> callback);

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            template<typename T1, typename T2, typename T3>
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void(T1, T2, T3)>)> work,
                std::function<void(T1, T2, T3)> callback);

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            template<typename T1, typename T2, typename T3, typename T4>
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void(T1, T2, T3, T4)>)> work,
                std::function<void(T1, T2, T3, T4)> callback);

            /// 
            /// \brief Construct an instance of the WorkChainWorkWrapper class.
            /// 
            /// \param work_chain The work chain which this work will be posted to.
            /// \param work The work to wrap.
            /// \param callback The work callback to wrap.
            /// 
            template<typename T1, typename T2, typename T3, typename T4, typename T5>
            WorkChainWorkWrapper(
                IWorkChain &work_chain,
                std::function<void(const bool, std::function<void(T1, T2, T3, T4, T5)>)> work,
                std::function<void(T1, T2, T3, T4, T5)> callback);

        private:
            WorkChainWorkWrapper(const WorkChainWorkWrapper &); //!< Disable the copy constructor.

            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            WorkChainWorkWrapper &operator=(const WorkChainWorkWrapper &); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IWorkChainWorkWrapper implementation
            // ------------------------------------------------------------------------------------

            virtual void post();

        protected:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            CancelableWork work_wrapper;    //!< The wrapped work item.
            IWorkChain *work_chain;         //!< The work chain that the work will be posted to.
        };
    }
}

#include <Utility/WorkChainWorkWrapper.ipp>

#endif // NOS_ENGINE_UTILITY_WORK_CHAIN_WORK_WRAPPER_HPP