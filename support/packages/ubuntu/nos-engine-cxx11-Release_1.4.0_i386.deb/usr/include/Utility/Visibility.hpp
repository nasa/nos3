/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#undef NOS_ENGINE_UTILITY_API_PUBLIC
#undef NOS_ENGINE_UTILITY_API_PRIVATE

#if defined(__BUILDING_NOS_ENGINE_UTILITY__)
#  if defined(WIN32) || defined(_WIN32) || defined(__WIN32) || defined(__WIN32__)
#    pragma deprecated ("__BUILDING_NOS_ENGINE_UTILITY__")
#  else
#    warning DEPRECATED: __BUILDING_NOS_ENGINE_UTILITY__ is now deprecated. Please use BUILDING__NOS_ENGINE_UTILITY__ instead.
#  endif
#endif

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) || defined(__WIN32__)
#  if defined(__BUILDING_NOS_ENGINE_UTILITY__) || defined(BUILDING__NOS_ENGINE_UTILITY__)
#    ifndef BUILDING__NOS_ENGINE_UTILITY__STATIC
#      ifdef __GNUC__
#        define NOS_ENGINE_UTILITY_API_PUBLIC __attribute__((dllexport))
#      else
#        define NOS_ENGINE_UTILITY_API_PUBLIC __declspec(dllexport)
#      endif
#    else
#        define NOS_ENGINE_UTILITY_API_PUBLIC
#    endif
#  else
#    ifndef BUILDING__NOS_ENGINE_UTILITY__STATIC
#      ifdef __GNUC__
#        define NOS_ENGINE_UTILITY_API_PUBLIC __attribute__((dllimport))
#      else
#        define NOS_ENGINE_UTILITY_API_PUBLIC __declspec(dllimport)
#      endif
#    else
#        define NOS_ENGINE_UTILITY_API_PUBLIC
#    endif
#  endif

#  define NOS_ENGINE_UTILITY_API_PRIVATE
#  define ITC_NO_RETURN __declspec(noreturn)
#elif defined(__GNUC__)
#    define ITC_NO_RETURN __attribute__((noreturn))

#    if __GNUC__ >= 4
#      define NOS_ENGINE_UTILITY_API_PUBLIC __attribute__((visibility("default")))
#      define NOS_ENGINE_UTILITY_API_PRIVATE __attribute__((visibility("hidden")))
#    else
#      define NOS_ENGINE_UTILITY_API_PUBLIC
#      define NOS_ENGINE_UTILITY_API_PRIVATE
#    endif
#else
  #error check me out
#endif
