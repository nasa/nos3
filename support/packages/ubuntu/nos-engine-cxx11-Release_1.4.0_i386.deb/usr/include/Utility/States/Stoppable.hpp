/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_STATES_STOPPABLE_HPP
#define NOS_ENGINE_UTILITY_STATES_STOPPABLE_HPP

#include <mutex>
#include <condition_variable>

#include <Utility/Types.hpp>
#include <Utility/States/IStoppable.hpp>
#include <Utility/Events/OnStopping.hpp>
#include <Utility/Events/OnStopped.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace States
        {
            ///
            /// \copydoc IStoppable
            ///
            class NOS_ENGINE_UTILITY_API_PUBLIC Stoppable :
                public virtual IStoppable,
                public Events::OnStopping<Stoppable>,
                public Events::OnStopped<Stoppable>
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the Stoppable class.
                /// 
                virtual ~Stoppable() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                // --------------------------------------------------------------------------------
                // IStoppable implementation
                // --------------------------------------------------------------------------------

                virtual void stop();

                virtual bool is_stopping() const;

                virtual bool is_stopped() const;

            protected:
                // ================================================================================
                // Internal API
                // --------------------------------------------------------------------------------

                ///
                /// \copydoc stop()
                /// 
                /// \see stop()
                /// 
                /// \param lock A lock that has acquired a lock of get_stoppable_mutex().
                ///
                virtual void stop(std::unique_lock<std::mutex> &lock);

                ///
                /// \brief Get the mutex to use for stop related operations.
                /// 
                /// \return The mutex.
                ///
                virtual std::mutex &get_stoppable_mutex() const;

                ///
                /// \brief Get the condition variable to use for stop related operations.
                /// 
                /// \return The condition variable.
                ///
                virtual std::condition_variable &get_stoppable_cv() const;

                ///
                /// \brief See is_stopping()
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                ///
                virtual bool is_stopping_no_lock() const = 0;

                ///
                /// \brief Set the value that indicates if this object is stopping.
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                /// 
                /// \param stopping The new value.
                ///
                virtual void set_stopping_no_lock(const bool &stopping) = 0;

                ///
                /// \brief See is_stopped()
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                ///
                virtual bool is_stopped_no_lock() const = 0;

                ///
                /// \brief Set the value that indicates if this object is stopped.
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                /// 
                /// \param stopped The new value.
                ///
                virtual void set_stopped_no_lock(const bool &stopped) = 0;

                ///
                /// \copydoc stop()
                /// 
                /// \see stop(std::unique_lock<std::mutex> &)
                /// 
                /// \param lock A lock that has acquired a lock of get_stoppable_mutex().
                ///
                virtual void process_stop(std::unique_lock<std::mutex> &lock) = 0;
            };
        }
    }
}

#endif // NOS_ENGINE_UTILITY_STATES_STOPPABLE_HPP