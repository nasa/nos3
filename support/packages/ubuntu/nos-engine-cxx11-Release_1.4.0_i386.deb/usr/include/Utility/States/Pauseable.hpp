/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_STATES_PAUSEABLE_HPP
#define NOS_ENGINE_UTILITY_STATES_PAUSEABLE_HPP

#include <mutex>
#include <condition_variable>

#include <Utility/Types.hpp>
#include <Utility/States/IPauseable.hpp>
#include <Utility/Events/OnPauseChanged.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace States
        {
            ///
            /// \copydoc IPauseable
            ///
            class NOS_ENGINE_UTILITY_API_PUBLIC Pauseable :
                public virtual IPauseable,
                public Events::OnPauseChanged<Pauseable>
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the Pauseable class.
                /// 
                virtual ~Pauseable() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                // --------------------------------------------------------------------------------
                // IPauseable implementation
                // --------------------------------------------------------------------------------

                virtual void pause();

                virtual void unpause();

                virtual bool is_paused() const;

            protected:
                // ================================================================================
                // Internal API
                // --------------------------------------------------------------------------------

                ///
                /// \brief Pause/Unpause the object.
                /// 
                /// \see pause()
                /// \see unpause()
                /// 
                /// \param lock A lock that has acquired a lock of get_pauseable_mutex().
                /// \param pause The desired pause state (true paused; false unpaused).
                ///
                virtual void pause(std::unique_lock<std::mutex> &lock, const bool &pause);

                ///
                /// \brief Get the mutex to use for pause/unpause related operations.
                /// 
                /// \return The mutex.
                ///
                virtual std::mutex &get_pauseable_mutex() const;

                ///
                /// \brief See is_paused()
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                ///
                virtual const bool &is_paused_no_lock() const = 0;

                ///
                /// \brief Set the value that indicates if this object is currently paused.
                ///
                /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
                /// 
                /// \param paused The new value, true if currently paused.
                ///
                virtual void set_paused_no_lock(const bool &paused) = 0;

                ///
                /// \brief Pause/Unpause the object.
                /// 
                /// \see pause(std::unique_lock<std::mutex> &, const bool &)
                /// 
                /// \param lock A lock that has acquired a lock of get_pauseable_mutex().
                /// \param pause The desired pause state (true paused; false unpaused).
                ///
                virtual void process_pause(std::unique_lock<std::mutex> &lock, const bool &pause) = 0;
            };
        }
    }
}

#endif // NOS_ENGINE_UTILITY_STATES_PAUSEABLE_HPP