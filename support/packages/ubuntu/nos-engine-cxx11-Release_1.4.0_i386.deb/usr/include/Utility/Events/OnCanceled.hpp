/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_EVENTS_ON_CANCELED_HPP
#define NOS_ENGINE_UTILITY_EVENTS_ON_CANCELED_HPP

#include <Utility/Events/IOnCanceled.hpp>
#include <Utility/CallbackList.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Events
        {
            /// 
            /// \copydoc IOnCanceled
            /// 
            template<class C>
            class OnCanceled : public virtual IOnCanceled
            {
            public:
                // ================================================================================
                // Types
                // --------------------------------------------------------------------------------

                typedef CallbackList<C> OnCanceledCallbackList;

                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the OnCanceled class.
                /// 
                virtual ~OnCanceled() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                // --------------------------------------------------------------------------------
                // IOnCanceled implementation
                // --------------------------------------------------------------------------------

                virtual CallbackId add_on_canceled_callback(OnCanceledCallback callback, const bool &removable = true);

                virtual void remove_on_canceled_callback(const CallbackId &id);

                // ================================================================================
                // Data members
                // --------------------------------------------------------------------------------

                OnCanceledCallbackList on_canceled; //!< List of on canceled callbacks.
            };
        }
    }
}

#include <Utility/Events/OnCanceled.ipp>

#endif // NOS_ENGINE_UTILITY_EVENTS_ON_CANCELED_HPP