/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_ENDIAN_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_ENDIAN_HPP

#include <cstdint>

#include <Utility/Types.hpp>

namespace NosEngine {
namespace Utility {
namespace Endian {

/// 
/// \brief Represents types of endianess
/// 
enum class Endian
{
    ENDIAN_INVALID, //!< indicates invalid value
    ENDIAN_BIG,     //!< big endian
    ENDIAN_LITTLE,  //!< little endian
    ENDIAN_COUNT,   //!< Indicates enum count
};

/// 
/// \brief Represents available types of endian conversion
/// 
enum class EndianConversion
{
    ENDIAN_CONVERSION_INVALID,    //!< indicates invalid value
    ENDIAN_CONVERSION_NONE,       //!< no conversion
    ENDIAN_CONVERSION_BIG_LITTLE, //!< convert big endian to little endian
    ENDIAN_CONVERSION_LITTLE_BIG, //!< convert little endian to big endian
    ENDIAN_CONVERSION_COUNT,      //!< Indicates enum count
};

/// 
/// \brief Represents types that can be serialized
/// 
enum class SerializeType
{
    SERIALIZE_TYPE_INVALID,  //!< indicates invalid value
    SERIALIZE_TYPE_CHAR,     //!< character
    SERIALIZE_TYPE_INT8,     //!< 8-bit integer
    SERIALIZE_TYPE_INT16,    //!< 16-bit integer
    SERIALIZE_TYPE_INT32,    //!< 32-bit integer
    SERIALIZE_TYPE_INT64,    //!< 64-bit integer
    SERIALIZE_TYPE_FLOAT,    //!< float
    SERIALIZE_TYPE_DOUBLE,   //!< double
    SERIALIZE_TYPE_STRING,   //!< string
    SERIALIZE_TYPE_BINARY,   //!< raw data
    SERIALIZE_TYPE_COUNT,    //!< Indicates enum count
};

extern const NOS_ENGINE_UTILITY_API_PUBLIC uint8_t ENDIAN_TEST_BYTES[4];
extern const NOS_ENGINE_UTILITY_API_PUBLIC uint32_t ENDIAN_TEST_VALUE_BIG;
extern const NOS_ENGINE_UTILITY_API_PUBLIC uint32_t ENDIAN_TEST_VALUE_LITTLE;

///
/// \brief Test the system to discover the endianess
///
/// \return the endian type
///
Endian NOS_ENGINE_UTILITY_API_PUBLIC get_native_endian();

///
/// \brief Examine endian test data to discover the endianess
///
/// \param test_bytes A copy of the predefined ENDIAN_TEST_BYTES as received from a remote system,
/// and thus possibly byte swapped.
///
/// \return the endian type
///
Endian NOS_ENGINE_UTILITY_API_PUBLIC get_endian(const uint8_t test_bytes[4]);

///
/// \brief Get the type of endian conversion needed
///
/// \param src_endian   endian of the source
/// \param dest_endian  endian of the destination
///
/// \return the endian conversion to use
///
EndianConversion NOS_ENGINE_UTILITY_API_PUBLIC get_endian_conversion(Endian src_endian, Endian dest_endian);

}}}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_ENDIAN_HPP