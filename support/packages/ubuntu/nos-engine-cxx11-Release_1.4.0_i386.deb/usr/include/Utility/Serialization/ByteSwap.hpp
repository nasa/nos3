/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_BYTE_SWAP_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_BYTE_SWAP_HPP

#include <cstdint>

#include <Utility/Types.hpp>

namespace NosEngine {
namespace Utility {
namespace ByteSwap {

///
/// \brief Reverse byte-order of unsigned 16-bit field
///
/// \param val 16-bit value
///
/// \return byte-swapped version of val
///
uint16_t NOS_ENGINE_UTILITY_API_PUBLIC byte_swap_uint16(uint16_t val);

///
/// \brief Reverse byte-order of unsigned 32-bit field
///
/// \param val 32-bit value
///
/// \return byte-swapped version of val
///
uint32_t NOS_ENGINE_UTILITY_API_PUBLIC byte_swap_uint32(uint32_t val);

///
/// \brief Reverse byte-order of unsigned 64-bit field
///
/// \param val 64-bit value
///
/// \return byte-swapped version of val
///
uint64_t NOS_ENGINE_UTILITY_API_PUBLIC byte_swap_uint64(uint64_t val);

}}}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_BYTE_SWAP_HPP