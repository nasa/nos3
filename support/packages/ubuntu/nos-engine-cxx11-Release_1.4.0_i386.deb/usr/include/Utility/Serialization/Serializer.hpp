/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_SERIALIZER_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_SERIALIZER_HPP

#include <string>
#include <vector>

#include <Utility/Types.hpp>
#include <Utility/Serialization/ISerializer.hpp>
#include <Utility/Serialization/Endian.hpp>
#include <Utility/Serialization/BufferUtils.hpp>
#include <Utility/Serialization/ByteSwap.hpp>

namespace NosEngine {
namespace Utility {

// ################################################################################################
// Serialize functions
// ------------------------------------------------------------------------------------------------

namespace Serialize {

///
/// \brief Serialize an 8-bit integer into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument  buf is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_int8(Buffer *buf, Endian::EndianConversion conv, int8_t val);

///
/// \brief Serialize an 16-bit integer into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument  buf is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_int16(Buffer *buf, Endian::EndianConversion conv, int16_t val);

///
/// \brief Serialize an 32-bit integer into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument  buf is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_int32(Buffer *buf, Endian::EndianConversion conv, int32_t val);

///
/// \brief Serialize an 64-bit integer into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument  buf is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_int64(Buffer *buf, Endian::EndianConversion conv, int64_t val);

///
/// \brief Serialize a float into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument      buf is null
/// \throw FormatStringFailed   failed to format the float into a string
/// \throw BufferOverflow       there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_float(Buffer *buf, Endian::EndianConversion conv, float val);

///
/// \brief Serialize a double into a buffer
///
/// \param buf   destination buffer
/// \param conv  type of endian conversion to use
/// \param val   value to serialize
///
/// \throw InvalidArgument      buf is null
/// \throw FormatStringFailed   failed to format the double into a string
/// \throw BufferOverflow       there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_double(Buffer *buf, Endian::EndianConversion conv, double val);

///
/// \brief Serialize a string into a buffer
///
/// \param buf       destination buffer
/// \param conv      type of endian conversion to use
/// \param val       value to serialize
///
/// \throw InvalidArgument  string length exceeds the maximum permitted, buf is null, or val is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_string(Buffer *buf, Endian::EndianConversion conv, const char * const val);

///
/// \brief Serialize a string into a buffer
///
/// \param buf       destination buffer
/// \param conv      type of endian conversion to use
/// \param val       value to serialize
///
/// \throw InvalidArgument  string length exceeds the maximum permitted or buf is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_string(Buffer *buf, Endian::EndianConversion conv, const std::string &val);

///
/// \brief Serialize raw data into a buffer
///
/// \param buf       destination buffer
/// \param conv      type of endian conversion to use
/// \param val       value to serialize
/// \param val_size  length of the data
///
/// \throw InvalidArgument  data length exceeds the maximum permitted, buf is null, or val is null
/// \throw BufferOverflow   there is not enough space left in the buffer
///
void NOS_ENGINE_UTILITY_API_PUBLIC serialize_binary(Buffer *buf, Endian::EndianConversion conv, const void * const val, size_t val_size);

}

// ################################################################################################
// Serialize class
// ------------------------------------------------------------------------------------------------

///
/// \copydoc ISerializer
///
class NOS_ENGINE_UTILITY_API_PUBLIC Serializer : public ISerializer {
public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Instantiate a serializer.
    ///
    /// The serializer does not take ownership of the buffer; its lifetime must be appropriately handled by the caller.
    ///
    /// \param buf          the target buffer
    /// \param src_endian   endianess of the source (one generating data)
    /// \param dest_endian  endianess of the destination (one receiving data)
    /// 
    /// \throw InvalidArgument  buf is null, src_endian is invalid, or dest_endian is invalid
    ///
    Serializer(Buffer *buf, Endian::Endian src_endian, Endian::Endian dest_endian);

private:
    Serializer();                   //!< Disable the default constructor.
    Serializer(const Serializer &); //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the Serializer class.
    /// 
    virtual ~Serializer();

private:
    // ====================================================================================
    // Operators
    // ------------------------------------------------------------------------------------

    Serializer& operator=(const Serializer&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // ISerializer implementation
    // --------------------------------------------------------------------------------------------

    virtual void serialize_char(char val);

    virtual void serialize_int8(int8_t val);

    virtual void serialize_int16(int16_t val);

    virtual void serialize_int32(int32_t val);

    virtual void serialize_int64(int64_t val);

    virtual void serialize_float(float val);

    virtual void serialize_double(double val);

    virtual void serialize_string(const char * const val);

    virtual void serialize_string(const std::string &val);

    virtual void serialize_binary(const void * const val, size_t val_size);

    virtual Buffer *get_buffer();

    virtual void reset();
protected:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- user data ----
    Buffer *buf;
    Endian::Endian src_endian;
    Endian::Endian dest_endian;

    // ---- config data ----
    Endian::EndianConversion conv;
};

}}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_SERIALIZER_HPP