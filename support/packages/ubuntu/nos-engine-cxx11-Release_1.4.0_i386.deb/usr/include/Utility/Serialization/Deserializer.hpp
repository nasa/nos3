/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_DESERIALIZER_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_DESERIALIZER_HPP

#include <string>
#include <vector>

#include <Utility/Types.hpp>
#include <Utility/Serialization/IDeserializer.hpp>
#include <Utility/Serialization/Endian.hpp>
#include <Utility/Serialization/BufferUtils.hpp>
#include <Utility/Serialization/ByteSwap.hpp>

namespace NosEngine {
namespace Utility {

// ################################################################################################
// Deserialize functions
// ------------------------------------------------------------------------------------------------

namespace Serialize {

///
/// \brief de-serialize an 8-bit integer from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize an 8-bit integer
///
/// \return 8-bit integer value
///
int8_t NOS_ENGINE_UTILITY_API_PUBLIC deserialize_int8(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief de-serialize an 16-bit integer from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 16-bit integer
///
/// \return 16-bit integer value
///
int16_t NOS_ENGINE_UTILITY_API_PUBLIC deserialize_int16(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief de-serialize an 32-bit integer from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 32-bit integer
///
/// \return 32-bit integer value
///
int32_t NOS_ENGINE_UTILITY_API_PUBLIC deserialize_int32(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief de-serialize an 64-bit integer from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize a 64-bit integer
///
/// \return 64-bit integer value
///
int64_t NOS_ENGINE_UTILITY_API_PUBLIC deserialize_int64(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief de-serialize a float from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null or the length (of the float) stored in the buffer is zero
/// \throw BufferOverflow   the length of the float is larger than the maximum temporary buffer size
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the float
/// \throw SystemError      string conversion to float failed
///
/// \return float value
///
float NOS_ENGINE_UTILITY_API_PUBLIC deserialize_float(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief de-serialize a double from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null or the length (of the double) stored in the buffer is zero
/// \throw BufferOverflow   the length of the double is larger than the maximum temporary buffer size
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the double
/// \throw SystemError      string conversion to double failed
///
/// \return double value
///
double NOS_ENGINE_UTILITY_API_PUBLIC deserialize_double(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief De-serialize a string from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer to deserialize the string
///
/// \return string value
///
std::string NOS_ENGINE_UTILITY_API_PUBLIC deserialize_string(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

///
/// \brief De-serialize raw data from a buffer
///
/// \param buf     source buffer
/// \param offset  offset into buffer
/// \param conv    type of endian conversion to use
///
/// \throw InvalidArgument  buf is null
/// \throw BufferUnderflow  there is not enough data in the buffer
///
/// \return data value in Buffer
///
NOS_ENGINE_UTILITY_API_PUBLIC Buffer deserialize_binary(const Buffer * const buf, size_t &offset, Endian::EndianConversion conv);

}

// ################################################################################################
// Deserialize class
// ------------------------------------------------------------------------------------------------

///
/// \copydoc IDeserializer
///
class NOS_ENGINE_UTILITY_API_PUBLIC Deserializer : public IDeserializer {
public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Instantiate a de-serializer.
    ///
    /// The de-serializer does not take ownership of the buffer; its lifetime must be appropriately handled by the caller.
    ///
    /// \param buf          the target buffer
    /// \param src_endian   endianess of the source (one generating data)
    /// \param dest_endian  endianess of the destination (one receiving data)
    /// 
    /// \throw InvalidArgument  buf is null, src_endian is invalid, or dest_endian is invalid
    ///
    Deserializer(const Buffer * const buf, Endian::Endian src_endian, Endian::Endian dest_endian);

    ///
    /// \brief Instantiate a de-serializer.
    ///
    /// The de-serializer does not take ownership of the buffer; its lifetime must be appropriately handled by the caller.
    ///
    /// \param buf             the target buffer
    /// \param initial_offset  offset into the buffer to perform deserialization 
    /// \param src_endian      endianess of the source (one generating data)
    /// \param dest_endian     endianess of the destination (one receiving data)
    /// 
    /// \throw InvalidArgument  buf is null, src_endian is invalid, or dest_endian is invalid
    /// \throw BufferOverflow   initial_offset is larger than the buffer length
    ///
	Deserializer(const Buffer * const buf, size_t initial_offset, Endian::Endian src_endian, Endian::Endian dest_endian);

private:
    Deserializer();                     //!< Disable the default constructor.
    Deserializer(const Deserializer &); //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the Deserializer class.
    /// 
    virtual ~Deserializer();

private:
    // ====================================================================================
    // Operators
    // ------------------------------------------------------------------------------------

    Deserializer& operator=(const Deserializer&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IDeserializer implementation
    // --------------------------------------------------------------------------------------------

    virtual char deserialize_char();

    virtual int8_t deserialize_int8();

    virtual int16_t deserialize_int16();

    virtual int32_t deserialize_int32();

    virtual int64_t deserialize_int64();

    virtual float deserialize_float();

    virtual double deserialize_double();

    virtual std::string deserialize_string();

    virtual Buffer deserialize_binary();

    virtual const Buffer *get_buffer() const;

    virtual size_t get_offset() const;

	virtual void set_offset(const size_t new_offset);

    virtual void reset();

private:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    void initialize_check() const;

protected:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- user data ----
    const Buffer * const buf;
    Endian::Endian src_endian;
    Endian::Endian dest_endian;

    // ---- config data ----
    Endian::EndianConversion conv;

    // ---- state data ----
    size_t offset;
};

}}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_DESERIALIZER_HPP
