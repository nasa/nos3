/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_QUEUE_HPP
#define NOS_ENGINE_UTILITY_QUEUE_HPP

#include <list>
#include <mutex>
#include <condition_variable>

#include <Utility/Types.hpp>
#include <Utility/IQueue.hpp>
#include <Utility/Error/Shutdown.hpp>
#include <Utility/Error/CollectionEmpty.hpp>

namespace NosEngine {
namespace Utility {

///
/// \copydoc IQueue
///
template <class T>
class Queue : public IQueue<T> {
public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct an instance of the Queue class.
    /// 
    Queue<T>();

    /// 
    /// \brief Destructor for an instance of the Queue class.
    /// 
    virtual ~Queue<T>();

private:
    Queue<T>(const Queue<T> &); //!< Disable the copy constructor.

    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    Queue<T>& operator=(const Queue<T> &); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IQueue implementation
    // --------------------------------------------------------------------------------------------

    virtual void push(T t);

    virtual void push_front(T t);

    virtual T pop();

    virtual T pop_nowait();

    virtual size_t length();

    virtual void clear();

    virtual void shutdown();

protected:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IQueue (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

private:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- queue ----
    std::list<T> queue;

    // ---- thread syncronization ----
    mutable std::condition_variable queue_cond;
    mutable std::mutex mutex;

    // ---- status ----
    bool shutdown_flag;
};

// Include template class implementation
#include <Utility/Queue.ipp>

}}

#endif

