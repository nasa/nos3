/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_DATA_LOGGER_HPP
#define NOS_ENGINE_SERVER_DATA_LOGGER_HPP

#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <map>

#include <Utility/Buffer.hpp>

#include <Common/Message.hpp>

#include <Server/Types.hpp>
#include <Server/IDataLogger.hpp>
#include <Server/PluginTypes.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc IDataLogger
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC DataLogger :
            public IDataLogger
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::map<std::string, MessageInterpreterFunction> InterpreterMap;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the DataLogger class.
            /// 
            DataLogger();

        private:
            DataLogger(const DataLogger&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the DataLogger class.
            /// 
            virtual ~DataLogger();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            DataLogger& operator=(const DataLogger&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IDataLogger implementation
            // ------------------------------------------------------------------------------------

            virtual void add_target(IDataLoggerTarget* to_add);

            virtual void remove_target(const IDataLoggerTarget* to_remove);

            virtual void remove_all_targets();
            
            virtual bool has_targets();

            virtual void log_message(Common::Message &message);
            
            virtual void log_message(Common::Message &&message);

            virtual void register_protocol_interpreter(const std::string& protocol, MessageInterpreterFunction interpreter);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            void worker_thread();

        protected:
            // ------------------------------------------------------------------------------------
            // IDataLogger (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;
            std::mutex targets_mutex;

            // ---- buffering ----
            Utility::Buffer buffer;

            // ---- collections ----
            std::vector<IDataLoggerTarget*> targets;
            std::queue<Common::Message> message_queue;
            InterpreterMap protocols;

            // ---- threading ----
            std::thread logging_thread;
            bool logging_thread_started;
        };
    }
}

#endif
