/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_MESSAGE_CONNECTION_HPP
#define NOS_ENGINE_COMMON_MESSAGE_CONNECTION_HPP

#include <Utility/Serialization/Endian.hpp>
#include <Utility/Error/Error.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Transport/Connection.hpp>

#include <Common/types.hpp>
#include <Common/IMessageConnection.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc IMessageConnection
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC MessageConnection :
            public IMessageConnection,
            public Utility::States::Stoppable,
            public std::enable_shared_from_this<IMessageConnection>
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the MessageConnection class.
            ///
            /// This is the syncronous (blocking) version, which WILL wait until handshakes are
            /// completed before returning.
            ///
            /// When the connection is for the server side, endian and transport ID handshakes
            /// will be initiated.
            /// When the connection is for the client side, endian and transport ID will be
            /// received from the server during handshake.
            ///
            /// \param id                       The unique id of the transport (/only/ used by server side).
            /// \param connection               Transport connection to use.
            /// \param is_server                Indicates if this is for the server side of the connection.
            ///
            MessageConnection(
                TransportID id,
                Transport::Connection *connection,
                bool is_server);

            /// 
            /// \brief Construct an instance of the MessageConnection class.
            ///
            /// This is the asyncronous (non-blocking) version, which WILL NOT wait until handshakes are
            /// completed before returning.
            ///
            /// When the connection is for the server side, endian and transport ID handshakes
            /// will be initiated.
            /// When the connection is for the client side, endian and transport ID will be
            /// received from the server during handshake.
            ///
            /// \param id                       The unique id of the transport (only used by server side).
            /// \param connection               Transport connection to use.
            /// \param is_server                Indicates if this is for the server side of the connection.
            /// \param handshake_callback       Callback to execute when handshakes are completed.
            ///
            MessageConnection(
                TransportID id,
                Transport::Connection *connection,
                bool is_server,
                MessageConnectionHandshakeCompleteCallback handshake_callback);

        private:
            MessageConnection();                            //!< Disable the default constructor.
            MessageConnection(const MessageConnection&);    //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the MessageConnection class.
            /// 
            virtual ~MessageConnection();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            MessageConnection& operator=(const MessageConnection&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // std::enable_shared_from_this implementation
            // ------------------------------------------------------------------------------------

            virtual std::shared_ptr<IMessageConnection> get_shared_ptr();

            // ------------------------------------------------------------------------------------
            // IMessageConnection implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_connected();

            virtual TransportID get_id() const;

            virtual TransportID get_logical_id() const;

            virtual Transport::Connection *get_connection() const;

            virtual const std::string &get_local_uri() const;

            virtual const std::string &get_remote_uri() const;

            virtual void send_message_blocking(Message message);

            virtual void send_message_async(Message message, Transport::SendCallback callback);

            virtual Message receive_message_blocking();

            virtual void receive_message_async(ReceiveMessageCallback callback);

            // --------------------------------------------------------------------------------
            // IOnDisconnected implementation
            // --------------------------------------------------------------------------------

            virtual Utility::CallbackId add_on_disconnected_callback(OnDisconnectedCallback callback, const bool &removable = true);

            virtual void remove_on_disconnected_callback(const Utility::CallbackId &id);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called by constructors to perform initialization.
            ///
            /// \param handshake_callback       Callback to execute when handshakes are completed.
            ///
            void init(MessageConnectionHandshakeCompleteCallback handshake_callback);

            ///
            /// \brief Asyncronously perform endian and transport ID handshakes.
            ///
            /// \param handshake_callback Callback to execute when handshakes are completed.
            ///
            void do_handshakes(MessageConnectionHandshakeCompleteCallback callback);

            ///
            /// \brief Asyncronously perform endian handshake.
            ///
            /// \param handshake_callback Callback to execute when handshakes are completed.
            ///
            void do_endian_handshake(MessageConnectionHandshakeCompleteCallback callback);

            ///
            /// \brief Asyncronously perform transport ID handshake.
            ///
            /// \param handshake_callback Callback to execute when handshakes are completed.
            ///
            void do_transport_id_handshake(MessageConnectionHandshakeCompleteCallback callback);

            ///
            /// \brief Execute the handshake completed callback.
            ///
            /// \param handshake_callback   Callback to execute when handshakes are completed.
            /// \param error                Error that occurred during handshakes (or "success" error).
            ///
            void exec_callback(MessageConnectionHandshakeCompleteCallback callback, const Utility::Error::Error &error);

            ///
            /// \copydoc is_connected()
            ///
            /// \param lock A lock that has aquired get_mutex().
            ///
            bool is_connected(std::unique_lock<std::mutex> &lock);

        protected:
            // ------------------------------------------------------------------------------------
            // IMessageConnection (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- configuration ----
            Transport::Connection *connection;                              //!< The underlying connection instance to use.
            bool is_server;                                                 //!< Value indicating if this is for the server side.
            TransportID id;                                                 //!< The transport ID (only set once).

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- status ----
            bool connected;                                                 //!< Value indicating if the connection is still established.
            bool stopping;                                                  //!< Value indicating if this is stopping.
            bool stopped;                                                   //!< Value indicating if this is stopped.

            // ---- connection details ----
            std::string local_uri;                                          //!< The URI for this end of the connection.
            std::string remote_uri;                                         //!< The URI for the other end of the connection.
            Utility::Endian::Endian local_endian;                           //!< The endian of the machine at this end of the connection.
            Utility::Endian::Endian remote_endian;                          //!< The endian of the machine at the other end of the connection.
            Utility::Endian::EndianConversion endian_receive_conv;          //!< The type of endian conversion that is needed, if any.
        };
    }
}

#endif

