/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_COMMON_QUERY_PROTOCOL_HPP
#define NOS_ENGINE_COMMON_QUERY_PROTOCOL_HPP

#include <string>
#include <vector>

#include <Utility/Buffer.hpp>

#include <Common/types.hpp>
#include <Common/Protocol.hpp>

namespace NosEngine
{
    namespace Common
    {
		namespace QueryProtocol
		{
			//Bus Target

            ///
            /// \brief Available commands for query operations
            ///
			enum class QueryCommand : uint8_t
			{
				QUERY_COMMAND_INVALID,  //!< Indicates invalid value
				GetBusList,             //!< Command to retrieve list of busses
				GetNodeList,            //!< Command to retrieve list of nodes
                ProtocolQuery,          //!< Command to retrieve information from a bus implementing a protocol
				QUERY_COMMAND_END       //!< Indicates end of enum
			};

            extern const size_t NOS_ENGINE_COMMON_API_PUBLIC ProtocolDataStart;
            extern const size_t NOS_ENGINE_COMMON_API_PUBLIC ParamDataStart;

            ///
            /// \brief Represents node information returned from a query
            ///
			struct NOS_ENGINE_COMMON_API_PUBLIC NodeInformation
			{
				std::string name;   //!< node name
			};

            ///
            /// \brief Compare two NodeInformation objects for equality
            ///
            /// This compares for equality of the values, not of the object addresses.
            ///
            /// \return true if fields are equal; false otherwise
            ///
			bool NOS_ENGINE_COMMON_API_PUBLIC operator==(const NodeInformation&, const NodeInformation&);

            ///
            /// \brief The not-equals version of the comparison operation.
            ///
			bool NOS_ENGINE_COMMON_API_PUBLIC operator!=(const NodeInformation&, const NodeInformation&);

            ///
            /// \brief Unpack the command field from a buffer.
            ///
            /// \param buffer  the source buffer
            ///
            /// \return the query command
            ///
			QueryCommand NOS_ENGINE_COMMON_API_PUBLIC get_command(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a query command into a buffer.
            ///
            /// \param buffer   destination buffer
            /// \param command  command to pack into buffer
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_command(Utility::Buffer& buffer, QueryCommand command);

            ///
            /// \brief Unpack the bus list from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return vector of strings representing bus names
            ///
			std::vector<std::string> NOS_ENGINE_COMMON_API_PUBLIC get_bus_list(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a list of bus names into a buffer
            ///
            /// \param buffer    destination buffer
            /// \param bus_list  list of bus names to pack into buffer
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_bus_list(Utility::Buffer& buffer, const std::vector<std::string> bus_list);

            ///
            /// \brief Unpack list of node information from a buffer
            ///
            /// \param buffer  source buffer
            ///
            /// \return list of node information
            ///
			std::vector<NodeInformation> NOS_ENGINE_COMMON_API_PUBLIC get_node_information(const Utility::Buffer& buffer);

            ///
            /// \brief Pack a list of node information into a buffer
            ///
            /// \param buffer  destination buffer
            /// \param nodes   list of node information
            ///
			void NOS_ENGINE_COMMON_API_PUBLIC set_node_information(Utility::Buffer& buffer, std::vector<NodeInformation> nodes);
		}

    }
}




#endif
