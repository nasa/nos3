/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_TRANSACTION_MANAGER_HPP
#define NOS_ENGINE_COMMON_TRANSACTION_MANAGER_HPP

#include <unordered_map>

#include <Utility/Queue.hpp>
#include <Utility/IWorkHub.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Common/types.hpp>
#include <Common/ITransactionManager.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc ITransactionManager
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC TransactionManager :
            public ITransactionManager,
            public Utility::States::Stoppable
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::unordered_map<TransactionID, ITransaction*> TransactionCollection;
            typedef std::list<ITransaction*> DeletionQueue;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the TransactionManager class.
            ///
            /// \param work_hub WorkHub to use for processing of transactions.
            ///
			TransactionManager(NosEngine::Utility::IWorkHub &work_hub);

        private:
            TransactionManager(const TransactionManager&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the TransactionManager class.
            ///
            virtual ~TransactionManager();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            TransactionManager& operator=(const TransactionManager&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ITransactionManager implementation
            // ------------------------------------------------------------------------------------

            virtual bool add_transaction(const TransactionID &id, ITransaction *to_add);

            virtual ITransaction* get_transaction(const TransactionID &id) const;

            virtual ITransaction* remove_transaction(const TransactionID &id);

            virtual bool remove_transaction(ITransaction *transaction);
            
            virtual bool remove_and_delete_transaction(const TransactionID &id);

            virtual bool remove_and_delete_transaction(ITransaction *to_delete);

            virtual void for_each(ForEachTransactionFunction for_each_func);

            virtual void process_transaction(Message to_process);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called by process_transaction() to update counter for tracking the number
            /// of in-progress transactions.
            ///
            /// \return true if transaction processing is enabled.
            ///
            bool transaction_worker_started();

            ///
            /// \brief Called when an in-progress transaction finishes.
            ///
            void transaction_worker_finished();

            ///
            /// \copydoc remove_transaction(const TransactionID &)
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            ITransaction* remove_transaction_no_lock(const TransactionID &idk);

            ///
            /// \copydoc remove_transaction(ITransaction *)
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            bool remove_transaction_no_lock(ITransaction *transaction);

            ///
            /// \brief Delete the transaction.
            ///
            bool delete_transaction(ITransaction *to_delete);

            ///
            /// \copydoc delete_transaction(ITransaction *)
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            bool delete_transaction(ITransaction *to_delete, std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Process the transaction with the specified id.
            ///
            /// \param id The id of the transaction to find and process.
            ///
            void do_processing(const TransactionID &id) NOS_NOEXCEPT;

        protected:
            // ------------------------------------------------------------------------------------
            // ITransactionManager (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- configuration ----
            NosEngine::Utility::IWorkHub &work_hub;

            // ---- collections ----
            TransactionCollection transactions;
            DeletionQueue deletion_queue;

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            std::mutex processor_mutex;
            mutable std::condition_variable cond;
            std::condition_variable for_each_done_cv;
            std::condition_variable worker_finished_cv;

            // ---- status ----
            bool stopping;
            bool stopped;
            bool stop_processing;
            bool delay_deletion;

            // ---- counters ----
            uint64_t for_each_count;
            uint64_t unfinished_workers;
        };
    }
}

#endif
