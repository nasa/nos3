/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_ITRANSACTION_MANAGER_HPP
#define NOS_ENGINE_COMMON_ITRANSACTION_MANAGER_HPP

#include <Utility/States/IStoppable.hpp>

#include <Common/types.hpp>
#include <Common/ITransaction.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Handles the lifetime, storage, and processing of transactions.
        ///
        /// A transaction manager stores transactions and maps them to a Transaction ID.
        ///
        class ITransactionManager :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::function<void(ITransaction*)> ForEachTransactionFunction;

            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ITransactionManager class.
            /// 
            virtual ~ITransactionManager() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief add a transaction to the manager.
            ///
            /// \param id      unique transaction ID
            /// \param to_add  the new transaction
            ///
            /// \return true if successfully added; false if not
            ///
            virtual bool add_transaction(const TransactionID &id, ITransaction *to_add) = 0;

            ///
            /// \brief Retrieve a transaction by ID.
            ///
            /// This method returns a pointer to the transaction and leaves it in the manager.
            ///
            /// \param id  the transaction id
            ///
            /// \return transaction pointer if found; NULL if not found
            ///
            virtual ITransaction* get_transaction(const TransactionID &id) const = 0;

            ///
            /// \brief Remove a transaction by ID from the manager.
            ///
            /// This method returns a pointer to the transaction and removes it from the manager.
            ///
            /// \param id  the transaction id
            ///
            /// \return transaction pointer if found; NULL if not found
            ///
            virtual ITransaction* remove_transaction(const TransactionID &id) = 0;

            ///
            /// \brief Remove a transaction from the manager.
            ///
            /// \param transaction  the transaction to remove
            ///
            virtual bool remove_transaction(ITransaction *transaction) = 0;
                
            ///
            /// \brief Remove a transaction from the manager and then deletes it.
            ///
            /// \param transaction  the transaction to remove and delete
            ///
            virtual bool remove_and_delete_transaction(const TransactionID &id) = 0;

            ///
            /// \brief Remove a transaction from the manager and then deletes it.
            ///
            /// \param transaction  the transaction to remove and delete
            ///
            virtual bool remove_and_delete_transaction(ITransaction *to_delete) = 0;

            ///
            /// \brief Iterate through a snapshot of the current transactions and call the provided
            /// function for each transaction.
            ///
            /// Transaction added after the snapshot is taken will not be included.
            ///
            /// \param for_each_func function to call for each transaction
            ///
            virtual void for_each(ForEachTransactionFunction for_each_func) = 0;

            ///
            /// \brief Queue the transaction for the specified message up for processing.
            ///
            /// \param to_process The message to associated with the transaction to find and
            /// queue for processing.
            ///
            virtual void process_transaction(Message to_process) = 0;
        };
    }
}

#endif
