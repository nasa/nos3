/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_INODE_HPP
#define NOS_ENGINE_COMMON_INODE_HPP

#include <Utility/States/IStoppable.hpp>

#include <Common/types.hpp>
#include <Common/Bus/BusProtocol.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Interface for a node.
        ///
        class INode :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the INode class.
            /// 
            virtual ~INode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the node type.
            ///
            /// \return The node type of this node.
            ///
            virtual BusProtocol::NodeType get_type() const = 0;

            ///
            /// \brief Get the name of the node.
            ///
            /// \return The node's name.
            ///
            virtual std::string get_name() const = 0;

            ///
            /// \brief Get the id of the node.
            ///
            /// \return The node's id.
            ///
            virtual NodeID get_id() const = 0;
        };
    }
}

#endif