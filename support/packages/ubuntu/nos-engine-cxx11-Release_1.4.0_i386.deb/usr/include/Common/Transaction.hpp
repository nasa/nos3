/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_TRANSACTION_HPP
#define NOS_ENGINE_COMMON_TRANSACTION_HPP

#include <Common/types.hpp>
#include <Common/ITransaction.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc ITransaction
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC Transaction :
            public ITransaction
        {
        protected:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::function<bool(const TransactionState &)> StateCheckerFunc;

            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Constructs and instance of the Transaction class.
            ///
            Transaction();

        private:
            Transaction(const Transaction &); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the Transaction class.
            /// 
            virtual ~Transaction();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Transaction& operator=(const Transaction &); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ITransaction implementation
            // ------------------------------------------------------------------------------------

            virtual void node_removed(INode* node);

            virtual void set_message(Message &to_process);
            
            virtual void set_message(Message &&to_process);

            virtual TransactionWorkResult process_message();

            virtual bool is_done() const;

            virtual TransactionState get_state() const;

            virtual bool wait(const Utility::Timeout &timeout = 0);

            virtual bool wait_for_inactive(const Utility::Timeout &timeout = 0);

            virtual bool wait_for_state(const TransactionState &state, const Utility::Timeout &timeout = 0);

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Performs the actual processing of the message.
            ///
            /// This method must be implemented in a derived class for each type of operation; the
            /// implementation should contain all the logic needed for processing a transaction.
            ///
            /// When processing of the transaction has completed, return Completed or CompletedAndRemoved.
            /// A return value of Completed indicates that the transaction should be deleted and removed
            /// from the manager.
            /// A return value of CompletedAndRemoved indicates that the transaction should only be deleted
            /// because the tranaction removed itself from the manager already.
            ///
            /// If the transaction still has more work to do, return InProgress.
            /// A return value of InProgress indicates that the transaction should not be deleted or removed
            /// from the manager.
            ///
            /// \param lock A lock that has aquired a lock on this classes mutex.
            ///
            /// \return InProgress if the operation is not finished, Completed if done and should be removed/deleted,
            /// or CompletedAndRemoved if done and should only be deleted (already removed)
            ///
            virtual TransactionWorkResult work(std::unique_lock<std::mutex> &lock) = 0;

            ///
            /// \copydoc ITransaction::is_done()
            ///
            virtual bool is_done_no_lock() const;

            ///
            /// \brief \copybrief ITransaction::is_done()
            ///
            /// \param state The state to check to determine if the transaction is done.
            ///
            virtual bool is_done(const TransactionState &state) const;

            ///
            /// \brief \copybrief ITransaction::is_inactive()
            ///
            /// \param state The state to check to determine if the transaction is inactive.
            ///
            virtual bool is_inactive(const TransactionState &state) const;

            ///
            /// \copydoc ITransaction::wait(const Utility::Timeout &)
            ///
            virtual bool wait(std::unique_lock<std::mutex> &lock, const Utility::Timeout &timeout = 0);

            ///
            /// \copydoc ITransaction::wait_for_inactive()
            ///
            virtual bool wait_for_inactive(std::unique_lock<std::mutex> &lock, const Utility::Timeout &timeout = 0);

            ///
            /// \copydoc ITransaction::get_state()
            ///
            virtual TransactionState get_state_no_lock() const;

            ///
            /// \copydoc ITransaction::set_state(const TransactionState &)
            ///
            virtual void set_state(const TransactionState &state, std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Wait for the transaction to transition to a desired state.
            /// 
            /// \param state The desired state.
            /// \param lock A lock that has aquired a lock on this classes mutex.
            /// \param timeout An amount of time (in milliseconds) to wait (0 to wait forever).
            ///
            /// \return A value indicating if the transaction transitioned to the desired state.
            ///
            virtual bool wait_for_state(const TransactionState &state, std::unique_lock<std::mutex> &lock, const Utility::Timeout &timeout = 0);

            ///
            /// \brief Wait for the transaction to transition to a desired state.
            /// 
            /// \param state_checker A function to call that returns true if the state is the desired value.
            /// \param lock A lock that has aquired a lock on this classes mutex.
            /// \param timeout An amount of time (in milliseconds) to wait (0 to wait forever).
            ///
            /// \return A value indicating if the transaction transitioned to the desired state.
            ///
            virtual bool wait_for_state(StateCheckerFunc state_checker, std::unique_lock<std::mutex> &lock, const Utility::Timeout &timeout = 0);

            // ------------------------------------------------------------------------------------
            // ITransaction implementation
            // ------------------------------------------------------------------------------------

            virtual void set_state(const TransactionState &state);

            // ------------------------------------------------------------------------------------
            // ITransaction (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;
            
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            mutable std::mutex mutex;
            mutable std::condition_variable cond;
            Message to_process;

        private:
            TransactionWorkResult work_status;
            TransactionState state;

            friend class TransactionManager;
        };           
    }
}

#endif