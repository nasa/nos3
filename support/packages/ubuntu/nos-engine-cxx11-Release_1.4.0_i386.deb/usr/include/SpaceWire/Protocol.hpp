/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_PROTOCOL_HPP
#define NOS_ENGINE_SPACEWIRE_PROTOCOL_HPP

#include <SpaceWire/visibility.hpp>
#include <Common/types.hpp>
#include <Common/BufferOverlay.hpp>
#include <SpaceWire/types.hpp>
#include <string>

namespace NosEngine
{
    namespace SpaceWire
    {
        // Routing switch address ranges
        const Address ADDRESS_MIN = 0;
        const Address ADDRESS_MAX = 254;
        const Address CONFIGURATION_PORT_ADDRESS = 0;   // Internal configuration port
        const Address PHYSICAL_PORT_ADDRESS_MIN = 1;    // Physical output port range start
        const Address PHYSICAL_PORT_ADDRESS_MAX = 31;   // Physical output port range end
        const Address LOGICAL_ADDRESS_MIN = 32;         // Logical address range start
        const Address LOGICAL_ADDRESS_MAX = 254;        // Logical address range end

        const NOS_ENGINE_SPACEWIRE_API_PUBLIC extern size_t SPACEWIRE_CARGO_START;

        enum class PacketAddressingType : uint8_t
        {
            Invalid,                //!< Indicates invalid packet addressing
            Path,                   //!< Path Addressing: sequence of router output ports
            Logical,                //!< Logical Addressing: logical address of a destination node
            PACKET_ADDRESSING_END   //!< Indicates end of enum
        };

        enum class EndOfPacketMarker : uint8_t
        {
            Invalid,                //!< Indicates invalid EOP marker
            EOP,                    //!< End of Packet: used as normal EOP marker
            EEP,                    //!< Error End of Packet: indicates an error occurred and the packet may be invalid
            EOP_MARKER_END          //!< Indicates end of enum
        };

        /**
            \brief Unpack the PacketAddressingType from the Buffer.

            \param overlay the Overlay of the Buffer

            \return the PacketAddressingType
        */
        PacketAddressingType NOS_ENGINE_SPACEWIRE_API_PUBLIC get_addressing_type(const Common::ReadOnlyBufferOverlay& overlay);

        /**
            \brief Pack the PacketAddressingType into the Buffer.

            \param overlay the Overlay of the Buffer
            \param subtype the PacketAddressingType
        */
        void NOS_ENGINE_SPACEWIRE_API_PUBLIC set_addressing_type(Common::BufferOverlay& overlay, const PacketAddressingType& addressing_type);

        /**
            \brief Unpack the EndOfPacketMarker from the Buffer.

            \param overlay the Overlay of the Buffer

            \return the EndOfPacketMarker
        */
        EndOfPacketMarker NOS_ENGINE_SPACEWIRE_API_PUBLIC get_eop_marker(const Common::ReadOnlyBufferOverlay& eop_overlay);

        /**
            \brief Pack the EndOfPacketMarker into the Buffer.

            \param overlay the Overlay of the Buffer
            \param subtype the EndOfPacketMarker
        */
        void NOS_ENGINE_SPACEWIRE_API_PUBLIC set_eop_marker(Common::BufferOverlay& overlay, const EndOfPacketMarker& marker);

        /**
            \brief Unpack the Cargo data from the Buffer.

            \param overlay the Overlay of the Buffer
            \param cargo the Cargo data retrieved from the Buffer (or nullptr if there is no cargo data)

            \return the Size of the Cargo retrieved from the Buffer
        */
        size_t NOS_ENGINE_SPACEWIRE_API_PUBLIC get_cargo(const Common::ReadOnlyBufferOverlay& overlay, char** cargo);

        /**
            \brief Pack the Cargo data into the Buffer.

            \param overlay the Overlay of the Buffer
            \param cargo the Cargo data to put in the Buffer
            \param size the size of the Cargo data
        */
        void NOS_ENGINE_SPACEWIRE_API_PUBLIC set_cargo(Common::BufferOverlay& overlay, const char* cargo, size_t size);
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_PROTOCOL_HPP */
