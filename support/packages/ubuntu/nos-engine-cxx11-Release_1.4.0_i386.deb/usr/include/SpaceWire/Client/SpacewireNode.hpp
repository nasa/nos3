/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRENODE_HPP
#define NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRENODE_HPP

#include <Client/DataNode.hpp>
#include <SpaceWire/visibility.hpp>
#include <SpaceWire/Protocol.hpp>
#include <SpaceWire/PathAddress.hpp>
#include <SpaceWire/Client/types.hpp>
#include <Utility/Buffer.hpp>
#include <functional>

namespace NosEngine
{
    namespace SpaceWire
    {
        namespace Client
        {
            typedef std::function<void(const size_t& length, const char* cargo, const EndOfPacketMarker& eop_marker)> PacketReceivedCallback;
            typedef std::function<void()> ConfirmationCallback;

            class NOS_ENGINE_SPACEWIRE_API_PUBLIC SpacewireNode
            {
            public:
                ~SpacewireNode();

                /**
                    \brief Set the callback for when packets are received.
                */
                void set_packet_received_callback(PacketReceivedCallback callback);

                /**
                    \brief Send a packet to another node in the network.

                    This will make a best-effort attempt to deliver the packet to the destination; no confirmation of receipt.

                    \param destination  the path addressing (sequence of router output ports) to guide the packet to the destination node
                    \param length       length of data
                    \param cargo        pointer to cargo (packet data)

                    \throw runtime_error if the destination is invalid
                */
                void send_packet(const PathAddress& destination, const size_t& length, const char* cargo) const;

                /**
                    \brief Send a packet to another node in the network.

                    This will make a best-effort attempt to deliver the packet to the destination; no confirmation of receipt.

                    \param destination  a single router output port to the destination node or the logical address of the destination node
                    \param length       length of data
                    \param cargo        pointer to cargo (packet data)

                    \throw runtime_error if the destination is invalid
                */
                void send_packet(const Address& destination, const size_t& length, const char* cargo) const;

                /**
                    \brief Send data to another node in the network with confirmation.

                    The method will return immediately and call the confirmation callback when confirmation is received.

                    \param destination   the path addressing (sequence of router output ports) to guide the packet to the destination node
                    \param length        length of data
                    \param cargo         pointer to cargo (packet data)
                    \param confirmation  confirmation callback

                    \throw runtime_error if the destination is invalid
                */
                void send_packet(const PathAddress& destination, const size_t& length, const char* cargo, ConfirmationCallback confirm_callback) const;

                /**
                    \brief Send data to another node in the network with confirmation.

                    The method will return immediately and call the confirmation callback when confirmation is received.

                    \param destination   a single router output port to the destination node or the logical address of the destination node
                    \param length        length of data
                    \param cargo         pointer to cargo (packet data)
                    \param confirmation  confirmation callback

                    \throw runtime_error if the destination is invalid
                */
                void send_packet(const Address& destination, const size_t& length, const char* cargo, ConfirmationCallback confirm_callback) const;

                //TODO: Should sends for requests/replies be supported?

                const std::string router_name;  //!< the name of the router the node is connected to
                const Address router_port;      //!< the address of the output port of the router which the node is connected to
            protected:
                /**
                    \brief Instantiate a SpacewireNode.

                    \param node         the base layer data node used by this node to send packets over a NOS bus
                    \param router_name  the name of the router the node is connected to
                    \param router_port  the address of the output port of the router which the node is connected to
                */
                SpacewireNode(NosEngine::Client::DataNode *node, const std::string& router_name, const Address& node_address);

                PacketReceivedCallback packet_received_callback;
            private:
                SpacewireNode(const SpacewireNode&);
                SpacewireNode& operator=(const SpacewireNode&);

                Utility::Buffer create_packet_buffer(const PathAddress& destination, const size_t& length, const char* cargo) const;
                void message_received(Common::Message &message);

                friend class SpacewireNetwork; //TODO: Re-evaluate this design
                NosEngine::Client::DataNode *node; // Non owning pointer
            };
        }
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_CLIENT_SPACEWIRENODE_HPP */
