/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_UTILS_HPP
#define NOS_ENGINE_SPACEWIRE_UTILS_HPP

#include <SpaceWire/visibility.hpp>
#include <Common/types.hpp>
#include <SpaceWire/types.hpp>
#include <string>

namespace NosEngine
{
    namespace SpaceWire
    {
        namespace Utils
        {
            /**
                \brief Determine if the Address is for a router configuration port

                \param address the Address to check

                \return a value indicating if the Address is for a router configuration port
            */
            bool NOS_ENGINE_SPACEWIRE_API_PUBLIC is_configuration_address(const Address& address);

            /**
                \brief Determine if the Address is for a router output port (physical address)

                \param address the Address to check

                \return a value indicating if the Address is for a router output port (physical address)
            */
            bool NOS_ENGINE_SPACEWIRE_API_PUBLIC is_physical_address(const Address& address);

            /**
                \brief Determine if the Address is for a logical address of a source/destination node

                \param address the Address to check

                \return a value indicating if the Address is for a logical address of a source/destination node
            */
            bool NOS_ENGINE_SPACEWIRE_API_PUBLIC is_logical_address(const Address& address);

            /**
                \brief Convert the Address to a string

                \param address the Address to convert

                \return the string conversion of the Address
            */
            std::string NOS_ENGINE_SPACEWIRE_API_PUBLIC address_to_string(Address address);

            /**
                \brief Convert the char to an Address

                \param address the char to convert

                \return the Address conversion of the char
            */
            Address NOS_ENGINE_SPACEWIRE_API_PUBLIC char_to_address(char address);

            /**
                \brief Get the spacewire node name for a node connected to a port on a spacewire router.

                \param router_name  the name of the router the node is connected to
                \param router_port  the address of the output port of the router which the node is connected to

                \return the name of the node

                \throw runtime_error if the port is invalid
            */
            std::string NOS_ENGINE_SPACEWIRE_API_PUBLIC get_node_name(const std::string& router_name, const Address& router_port);

            /**
                \brief Extract the spacewire router name from the specified node name.

                \param node_name  the name of the spacewire node

                \return the router name extracted from the node name

                \throw runtime_error if the node name is invalid
            */
            std::string NOS_ENGINE_SPACEWIRE_API_PUBLIC get_router_name(const std::string& node_name);

            /**
                \brief Extract the spacewire router port address from the specified node name.

                \param node_name  the name of the spacewire node

                \return the router port extracted from the node name

                \throw runtime_error if the node name is invalid or the port is not a physical port
            */
            Address NOS_ENGINE_SPACEWIRE_API_PUBLIC get_router_port(const std::string& node_name);
        }
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_UTILS_HPP */
