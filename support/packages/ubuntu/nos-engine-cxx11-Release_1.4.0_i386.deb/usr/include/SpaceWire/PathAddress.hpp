/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPACEWIRE_PATH_ADDRESS_HPP
#define NOS_ENGINE_SPACEWIRE_PATH_ADDRESS_HPP

#include <SpaceWire/visibility.hpp>
#include <SpaceWire/types.hpp>
#include <vector>
#include <string>

namespace NosEngine
{
    namespace SpaceWire
    {
        class NOS_ENGINE_SPACEWIRE_API_PUBLIC PathAddress : public std::vector<Address>
        {
        public:
            /**
                \brief Instantiate a PathAddress object.

                A path address is a sequence of router output ports used to guide a packet to a destination node.
            */
            PathAddress();
            
            /**
                \brief Instantiate a PathAddress object.

                A path address is a sequence of router output ports used to guide a packet to a destination node.

                \param value the first router output port in the path address
            */
            PathAddress(const Address& value);

            /**
                \brief Instantiate a PathAddress object.

                A path address is a sequence of router output ports used to guide a packet to a destination node.
                Note that the string is expected to contain one address for each character within the string.

                \param path_address  a string containing addresses
            */
            PathAddress(const std::string& path_address);

            /**
                \brief Copy constructor.
            */
            PathAddress(const PathAddress& other);

            /**
                \brief Move constructor.
            */
            PathAddress(const PathAddress&& other);

            ~PathAddress();

            /**
                \brief Append functor.

                \param value an address to append to the path
            */
            PathAddress& operator()(const Address& value);

            /**
                \brief Assignment operator.
            */
            PathAddress& operator=(const PathAddress& other);

            /**
                \brief Assignment operator.

                Note that the string is expected to contain one address for each character within the string.

                \param other a string containing addresses
            */
            PathAddress& operator=(const std::string& other);

            /**
                \brief Append operator.

                \param value an address to append to the path
            */
            PathAddress& operator+=(const Address& value);

            /**
                \brief Append operator.

                Note that the string is expected to contain one address for each character within the string.

                \param value a string containing addresses to append to the path
            */
            PathAddress& operator+=(const std::string& value);

            /**
                \brief Equality operator.

                Note that the string is expected to contain one address for each character within the string.

                \param path_address  a string containing addresses
            */
            bool operator==(const std::string& other);

            /**
                \brief Get a string containing addresses in the path.

                The string will contain one address for each character within the string.

                \return string containing addresses in the path
            */
            std::string str() const;

            /**
                \brief Validates that the path contains valid addresses for path addressing.

                \throw runtime_error if the path is invalid
            */
            void validate() const;
        };
    }
}

#endif /* NOS_ENGINE_SPACEWIRE_PATH_ADDRESS_HPP */
