/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_CONNECTION_HPP
#define NOS_ENGINE_TRANSPORT_CONNECTION_HPP

#include <string>
#include <functional>
#include <memory>
#include <vector>

#include <Utility/Buffer.hpp>
#include <Utility/IWorkHub.hpp>
#include <Utility/WorkChain.hpp>
#include <Utility/Events/OnDestroy.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Transport/Types.hpp>
#include <Transport/Globals.hpp>
#include <Transport/IConnection.hpp>
#include <Transport/Events/OnDisconnected.hpp>
#include <Transport/Result.hpp>
#include <Transport/URIPair.hpp>

namespace NosEngine {
namespace Transport {
    
///
/// \copydoc IConnection
///
class NOS_ENGINE_TRANSPORT_API_PUBLIC Connection :
    public IConnection,
    public Utility::Events::OnDestroy,
    public Transport::Events::OnDisconnected<Connection>,
    public Utility::States::Stoppable {
public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct and instance of the Connection class.
    /// 
    /// \param scheme       The expected scheme for validating the provided URI.
    /// \param local        The URI for this end of the connection.
    /// \param remote       The URI for the other end of the connection.
    /// \param work_hub     The work hub to use for performing asyncronous work.
    /// \param connected    A value indicating if the connection is currently established.
    /// 
    Connection(const std::string &scheme,
               const URI &local,
               const URI &remote,
               Utility::IWorkHub &work_hub,
               bool connected = true);

private:
    Connection();                   //!< Disable the default constructor.
    Connection(const Connection &); //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the Connection class.
    ///
    /// \note Derived classes are responsible for calling stop() on destruction.
    /// 
    virtual ~Connection();

private:
    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    Connection& operator=(const Connection&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IConnection implementation
    // --------------------------------------------------------------------------------------------

    virtual const URI &get_local_uri() const;

    virtual const URI &get_remote_uri() const;

    virtual bool is_connected();

    virtual void send_blocking(Utility::Buffer *buffer);

    virtual void send_async(Utility::Buffer *buffer, SendCallback callback);

    virtual Utility::Buffer *receive_blocking();

    virtual void receive_async(ReceiveCallback callback);

private:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Execute the callback stored in Connection::send_result with the result stored in
    /// Connection::send_result.
    ///
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void exec_send_callback(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Execute the callback.
    ///
    /// If an error occurred during the send operation the error will be stored in
    /// Connection::send_result and passed to the callback.
    ///
    /// \param callback The callback to execute.
    ///
    void exec_send_callback(const SendCallback &callback);

    ///
    /// \brief Execute the callback stored in Connection::receive_result with the result stored in
    /// Connection::receive_result.
    ///
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void exec_recv_callback(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Execute the callback.
    ///
    /// If an error occurred during the receive operation the error will be stored in
    /// Connection::receive_result and passed to the callback.
    ///
    /// \param callback The callback to execute.
    /// \param buffer   The buffer containing data received (nullptr when error).
    ///
    void exec_recv_callback(const ReceiveCallback &callback, Utility::Buffer *buffer);

protected:
    // --------------------------------------------------------------------------------------------
    // IConnection implementation
    // --------------------------------------------------------------------------------------------

    virtual void set_connected(const bool &connected);

    virtual void set_connected(const bool &connected, std::unique_lock<std::mutex> &lock);

    virtual bool is_connected(std::unique_lock<std::mutex> &lock);

    virtual void post_send_result();

    virtual void post_recv_result(const Utility::Work completed_callback = nullptr);

    // --------------------------------------------------------------------------------------------
    // IConnection (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

    // --------------------------------------------------------------------------------------------
    // Stoppable implementation
    // --------------------------------------------------------------------------------------------

    virtual bool is_stopping_no_lock() const;

    virtual void set_stopping_no_lock(const bool &stopping);

    virtual bool is_stopped_no_lock() const;

    virtual void set_stopped_no_lock(const bool &stopped);

    virtual void process_stop(std::unique_lock<std::mutex> &lock);

    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- configuration ----
    URIPair uri_pair;                           //!< The local/remote URIs for the Connection

    // ---- threading ----
    Utility::IWorkHub &work_hub;                //!< The hub which the Connection is using to perform async work.
    NosEngine::Utility::WorkChain *send_chain;  //!< Work chain the Connection is using to perform async send work serially.
    NosEngine::Utility::WorkChain *recv_chain;  //!< Work chain the Connection is using to perform async receive work serially.

    // ---- thread syncronization ----
    mutable std::mutex mutex;
    mutable std::condition_variable cond;

    // ---- send/receive operation result ----
    SendResultPtr send_result;                  //!< For storing send opertion results.
    ReceiveResultPtr receive_result;            //!< For storing receive opertion results.

    // ---- status ----
    bool connected;                             //!< Indicates if the Connection is currently established.
    bool stopping;                              //!< Indicates if the Connection is stopping.
    bool stopped;                               //!< Indicates if the Connection is stopped.
};

}}

#endif

