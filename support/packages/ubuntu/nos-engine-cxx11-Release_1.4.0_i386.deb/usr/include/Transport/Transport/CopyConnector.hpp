/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_COPY_CONNECTOR_HPP
#define NOS_ENGINE_TRANSPORT_COPY_CONNECTOR_HPP

#include <mutex>

#include <Utility/IWorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Connector.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a client which makes connection requests to a server for
        /// the copy (in process) transport.
        ///
        /// \see CopyAcceptor
        /// \see CopyConnection
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC CopyConnector :
            public Connector
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct and instance of the CopyConnector class.
            /// 
            /// \param uri      The URI which the Connector will connect to.
            /// \param work_hub The work hub to use for performing asyncronous work.
            /// 
            CopyConnector(const URI &uri, Utility::IWorkHub &work_hub);

        private:
            CopyConnector();                        //!< Disable the default constructor.
            CopyConnector(const CopyConnector&);    //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the CopyConnector class.
            /// 
            virtual ~CopyConnector();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            CopyConnector& operator=(const CopyConnector&); //!< Disable the copy assignment operator.

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // Connector overrides
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual void process_connector_stop(std::unique_lock<std::mutex> &lock);

	        virtual void process_connect(const size_t attempt_timeout, std::unique_lock<std::mutex> &lock);

            friend class CopyTransportManager;
        };
    }
}

#endif

