/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_TRANSPORT_TYPES_HPP
#define NOS_ENGINE_TRANSPORT_TYPES_HPP

#include <memory>

#include <Utility/Types.hpp>

#include <Transport/Visibility.hpp>
#include <Transport/Fwd.hpp>

namespace NosEngine
{
    namespace Transport
    {
        typedef std::vector<std::string> URIParameters;

        // ========================================================================================
        // Acceptor related
        // ----------------------------------------------------------------------------------------

        typedef std::function<void(Connection *connection, const Utility::Error::Error &error)> ListenCallback;
        typedef Result<Connection*, ListenCallback> ListenResult;
        typedef std::unique_ptr<ListenResult> ListenResultPtr;
        typedef std::vector<Acceptor *> AcceptorVector;

        // ========================================================================================
        // Connector related
        // ----------------------------------------------------------------------------------------

        typedef std::function<void(Connection *connection, const Utility::Error::Error &error)> ConnectCallback;
        typedef Result<Connection*, ConnectCallback> ConnectResult;
        typedef std::unique_ptr<ConnectResult> ConnectResultPtr;
        typedef std::vector<Connector *> ConnectorVector;

        // ========================================================================================
        // Connection related
        // ----------------------------------------------------------------------------------------

        typedef std::function<void(const Utility::Error::Error &error)> SendCallback;
        typedef std::function<void(Utility::Buffer *buffer, const Utility::Error::Error &error)> ReceiveCallback;
        typedef std::function<void(Connection *connection)> DisconnectedCallback;
        typedef Result<bool, SendCallback> SendResult;
        typedef std::unique_ptr<SendResult> SendResultPtr;
        typedef Result<Utility::Buffer*, ReceiveCallback> ReceiveResult;
        typedef std::unique_ptr<ReceiveResult> ReceiveResultPtr;
        typedef std::vector<Connection *> ConnectionVector;
    }
}

#endif

