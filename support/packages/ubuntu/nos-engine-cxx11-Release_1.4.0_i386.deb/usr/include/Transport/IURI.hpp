/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_IURI_HPP
#define NOS_ENGINE_TRANSPORT_IURI_HPP

#include <Transport/Types.hpp>
#include <Transport/Error.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a Uniform Resource Identifier (URI) for server (listening) or
        /// client (connecting) operations.
        ///
        /// URI format: <schema>://<param0>:<param1>:...:<paramX>
        ///
        class IURI :
            public virtual Utility::IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IURI class.
            /// 
            virtual ~IURI() {}

            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Conversion operator for std::string.
            ///
            /// \return The string representation of this URI.
            /// 
            virtual operator std::string() const = 0;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Get the string representation of this URI.
            ///
            /// \return The string representation.
            /// 
            virtual const std::string &to_string() const = 0;

            /// 
            /// \brief Get the scheme of the URI.
            /// 
            /// \return The scheme.
            /// 
            virtual const std::string &get_scheme() const = 0;

            /// 
            /// \brief Array operator for getting URI parameters.
            ///
            /// \return THe parameter for the index.
            /// 
            virtual const std::string &operator[] (const URIParameters::size_type &index) const = 0;

            /// 
            /// \brief Get all URI parameters.
            /// 
            /// \return The URI parameters.
            /// 
            virtual const URIParameters &get_parameters() const = 0;

            /// 
            /// \brief Get the URI parameter value converted to a desired type.
            ///
            /// \note Since this must be templated it's implemented in IURI, because templated
            /// methods can't be virtual.
            /// 
            /// \return The URI parameter value.
            /// 
            template<typename T>
            T get_parameter(const URIParameters::size_type &index) const;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Get the URI parameter value converted to a boolean.
            /// 
            /// \return The URI parameter value.
            /// 
            virtual bool get_bool_parameter(const URIParameters::size_type &index) const = 0;
        };
    }
}

#include <Transport/IURI.ipp>

#endif