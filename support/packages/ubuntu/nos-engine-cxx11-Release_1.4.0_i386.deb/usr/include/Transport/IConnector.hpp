/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_ICONNECTOR_HPP
#define NOS_ENGINE_TRANSPORT_ICONNECTOR_HPP

#include <Utility/Events/IOnDestroy.hpp>
#include <Utility/States/IStoppable.hpp>

#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a client which makes connection requests to a server.
        ///
        /// \see IAcceptor
        /// \see IConnection
        ///
        class IConnector :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::Events::IOnDestroy,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IConnector class.
            ///
            /// \note Derived classes are responsible for calling stop() on destruction.
            /// 
            virtual ~IConnector() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the URI which the Connector is connecting to.
            ///
            /// \return The URI.
            ///
            virtual const URI &get_uri() = 0;

            ///
            /// \brief Syncronously (blocking) perform a connect request.
            ///
            /// \param retries          The maximum number of retry attempts.
            /// \param retry_delay      The amount of time (in milliseconds) to wait between retry
            ///                         attempts.
            /// \param attempt_timeout  The amount of time to give each connection attempt before
            ///                         timing out the attempt.
            ///
            /// \return The Connection instance representing the successfully established
            /// connection to the server.
            ///
            virtual Connection *connect_blocking(
                const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
                const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
                const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS) = 0;

            ///
            /// \brief Ayncronously (non-blocking) perform a connect request.
            ///
            /// \param callback         The callback to execute when a connection is successfully
            ///                         established with the server (or an error occurs).
            /// \param retries          The maximum number of retry attempts.
            /// \param retry_delay      The amount of time (in milliseconds) to wait between retry
            ///                         attempts.
            /// \param attempt_timeout  The amount of time to give each connection attempt before
            ///                         timing out the attempt.
            ///
            virtual void connect_async(
                ConnectCallback callback,
                const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
                const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
                const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Stop the Connector implementation.
            ///
            /// \param lock A lock that has acquired a lock of get_stoppable_mutex().
            ///
            virtual void process_connector_stop(std::unique_lock<std::mutex> &lock) = 0;

            ///
            /// \brief Perform a connect operation.
            ///
            /// \param lock A lock that has acquired a lock of get_mutex().
            ///
            virtual void process_connect(const size_t attempt_timeout, std::unique_lock<std::mutex> &lock) = 0;
        };
    }
}

#endif