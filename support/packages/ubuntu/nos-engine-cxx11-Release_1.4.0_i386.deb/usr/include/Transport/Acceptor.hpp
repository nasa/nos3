/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_ACCEPTOR_HPP
#define NOS_ENGINE_TRANSPORT_ACCEPTOR_HPP

#include <string>
#include <deque>
#include <functional>

#include <Utility/IWorkHub.hpp>
#include <Utility/WorkChain.hpp>
#include <Utility/Events/OnDestroy.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Transport/Types.hpp>
#include <Transport/IAcceptor.hpp>
#include <Transport/Result.hpp>
#include <Transport/URI.hpp>

namespace NosEngine {
namespace Transport {

///
/// \copydoc IAcceptor
///
class NOS_ENGINE_TRANSPORT_API_PUBLIC Acceptor :
    public IAcceptor,
    public Utility::Events::OnDestroy,
    public Utility::States::Stoppable {
protected:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct and instance of the Acceptor class.
    /// 
    /// \param scheme   The expected scheme for validating the provided URI.
    /// \param uri      The URI which the Acceptor will listen on.
    /// \param work_hub The work hub to use for performing asyncronous work.
    /// 
    Acceptor(const std::string &scheme, const URI &uri, Utility::IWorkHub &work_hub);

private:
    Acceptor();                 //!< Disable the default constructor.
    Acceptor(const Acceptor &); //!< Disable the copy constructor.

public:
    /// 
    /// \brief Destructor for an instance of the Acceptor class.
    ///
    /// \note Derived classes are responsible for calling stop() on destruction.
    /// 
    virtual ~Acceptor();

private:
    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    Acceptor& operator=(const Acceptor&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IAcceptor implementation
    // --------------------------------------------------------------------------------------------

    virtual const URI &get_uri();

    virtual Connection *listen_blocking();

    virtual void listen_async(ListenCallback callback);

private:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Execute the callback stored in Acceptor::listen_result with the result stored in
    /// Acceptor::listen_result.
    ///
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void exec_callback(std::unique_lock<std::mutex> &lock);

    ///
    /// \brief Execute the callback.
    ///
    /// If an error occurred during the listen operation the error will be stored in
    /// Acceptor::listen_result and passed to the callback.
    ///
    /// \param callback     The callback to execute.
    /// \param connection   The connection for the current listen operation (nullptr when error).
    ///
    void exec_callback(const ListenCallback &callback, Connection *connection);

protected:
    // --------------------------------------------------------------------------------------------
    // IAcceptor implementation
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Post a work item to Acceptor::work_hub which executes the current listen
    /// callback stored in Acceptor::listen_result with the result stored in
    /// Acceptor::listen_result.
    ///
    virtual void post_result();

    // --------------------------------------------------------------------------------------------
    // IAcceptor (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

    // --------------------------------------------------------------------------------------------
    // Stoppable implementation
    // --------------------------------------------------------------------------------------------

    virtual bool is_stopping_no_lock() const;

    virtual void set_stopping_no_lock(const bool &stopping);

    virtual bool is_stopped_no_lock() const;

    virtual void set_stopped_no_lock(const bool &stopped);

    virtual void process_stop(std::unique_lock<std::mutex> &lock);

    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- configuration ----
    URI uri;                                        //!< The URI which the Acceptor is listening on.

    // ---- threading ----
    Utility::IWorkHub &work_hub;                    //!< The hub which the Acceptor is using to perform async work.
    NosEngine::Utility::WorkChain *listen_chain;    //!< Work chain the Acceptor is using to perform async work serially.

    // ---- thread syncronization ----
    mutable std::mutex mutex;
    mutable std::condition_variable cond;

    // ---- listen operation result ----
	ListenResultPtr listen_result;                  //!< For storing listen opertion results.

    // ---- status ----
    bool stopping;                                  //!< Indicates if the Acceptor is stopping.
    bool stopped;                                   //!< Indicates if the Acceptor is stopped.
};

}}

#endif