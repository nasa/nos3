/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_RESULT_HPP
#define NOS_ENGINE_TRANSPORT_RESULT_HPP

#include <iostream>

#include <Utility/Error/Error.hpp>

#include <Transport/Types.hpp>
#include <Transport/Error/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        template<typename VALUE_T, typename CALLBACK_T>
        class Result
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the Result class.
            /// 
            Result();
            
            /// 
            /// \brief Construct an instance of the Result class.
            /// 
            /// \param result Default result value.
            /// 
			Result(VALUE_T default_value);
            
            /// 
            /// \brief Destructor for an instance of the Result class.
            /// 
            ~Result();

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Set the result value.
            /// 
            /// \param result The result value.
            /// 
			void set(VALUE_T value);
            
            /// 
            /// \brief Get the result value.
            /// 
            /// \return The result value.
            /// 
			VALUE_T get() const;
			
            /// 
            /// \brief Set the callback which will receive the result.
            /// 
            /// \param callback The callback.
            /// 
			void set_callback(const CALLBACK_T &callback);
			
            /// 
            /// \brief Get the callback which will receive the result.
            /// 
            /// \return The callback.
            /// 
			CALLBACK_T get_callback();
            
            /// 
            /// \brief Set the last error that occurred.
            /// 
            /// \param error The last error that occurred.
            /// 
            void set_last_error(const Utility::Error::Error &error);
            
            /// 
            /// \brief Get the last error that occurred.
            /// 
            /// \return The last error that occurred.
            /// 
            const Utility::Error::Error &get_last_error() const;
            
            /// 
            /// \brief Clear the last error that occurred.
            /// 
            void clear_last_error();
            
            /// 
            /// \brief Reset the value to default and clear the last error.
            /// 
            void clear();

            /// 
            /// \brief Boolean operator overload.
            /// 
            /// \return A value indicating if the result is valid and no error occurred.
            /// 
            operator bool() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            static const Utility::Error::Error success; //!< global success for optimization of clearing errors

			VALUE_T default_value;                      //!< default result value
			VALUE_T value;                              //!< current result value
			CALLBACK_T callback;                        //!< callback that will receive the result
            const Utility::Error::Error *last_error;    //!< pointer to the last error that occurred
            Utility::Error::Error error;                //!< the last error that occurred
        };
    }
}

#include <Transport/Result.ipp>

#endif