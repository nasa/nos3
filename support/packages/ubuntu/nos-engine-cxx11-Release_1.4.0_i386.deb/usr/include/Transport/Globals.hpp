/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_GLOBALS_HPP
#define NOS_ENGINE_TRANSPORT_GLOBALS_HPP

#include <Utility/Globals.hpp>

#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        // ========================================================================================
        // Logging
        // ----------------------------------------------------------------------------------------

        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string NOS_ENGINE_TRANSPORT_LOGGER_NAME;
        extern NOS_ENGINE_TRANSPORT_API_PUBLIC Utility::Logger transport_logger;

        // ========================================================================================
        // Connector
        // ----------------------------------------------------------------------------------------

        extern const size_t NOS_ENGINE_TRANSPORT_API_PUBLIC CONNECT_INFINITE_RETRIES;
        extern const size_t NOS_ENGINE_TRANSPORT_API_PUBLIC DEFAULT_CONNECT_RETRY_COUNT;
        extern const size_t NOS_ENGINE_TRANSPORT_API_PUBLIC DEFAULT_CONNECT_RETRY_DELAY_MS;
        extern const size_t NOS_ENGINE_TRANSPORT_API_PUBLIC DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS;

        // ========================================================================================
        // TransportHub
        // ----------------------------------------------------------------------------------------

        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t TRANSPORT_HUB_DEFAULT_SERVICE_THREADS;

        // ========================================================================================
        // Copy transport
        // ----------------------------------------------------------------------------------------

        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string COPY_URI_SCHEME;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t COPY_URI_NUM_PARAMS;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t COPY_URI_ID_PARAM;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t COPY_URI_PORT_PARAM;

        // ========================================================================================
        // IPC transport
        // ----------------------------------------------------------------------------------------

        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string IPC_URI_SCHEME;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t IPC_URI_NUM_PARAMS;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t IPC_URI_NAME_PARAM;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t IPC_URI_PORT_PARAM;

        // ========================================================================================
        // TCP transport
        // ----------------------------------------------------------------------------------------

        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC std::string TCP_URI_SCHEME;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t TCP_URI_NUM_PARAMS;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t TCP_URI_ADDRESS_PARAM;
        extern const NOS_ENGINE_TRANSPORT_API_PUBLIC size_t TCP_URI_PORT_PARAM;
    }
}

#endif