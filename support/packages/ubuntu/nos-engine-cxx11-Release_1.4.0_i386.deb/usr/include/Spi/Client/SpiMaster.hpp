/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPI_MASTER_HPP
#define NOS_ENGINE_SPI_MASTER_HPP

#include <Spi/visibility.hpp>
#include <Spi/Client/SpiDevice.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Spi
    {
        /*
         * \brief Client side SPI master device
         *
         * The NOS SPI implementation provides a familiar SPI API but differs at the hardware protocol
         * level for performance. The entire transaction is handled in a single transport round trip.
         * The slave device returns the actual number of bytes read/written, providing a mechanism to
         * model transaction errors.
         */
        class NOS_ENGINE_SPI_API_PUBLIC SpiMaster : public SpiDevice
        {
        public:
            /*
             * \brief Create SPI master device on the named bus
             *
             * \param connection NOS connection string
             * \param bus SPI bus name
             * \param num_service_threads The number of service threads that should be created
             */
            SpiMaster(
                const std::string& connection,
                const std::string& bus = "spi",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create SPI master device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param connection NOS connection string
             * \param bus SPI bus name
             */
            SpiMaster(
                Transport::TransportHub &transport_hub,
                const std::string& connection,
                const std::string& bus = "spi");

            /*
             * \brief Destructor
             */
            virtual ~SpiMaster();

            /*
             * \brief Select slave device to begin transaction
             *
             * \param cs Slave device chip select
             */
            void select_chip(uint8_t cs);

            /*
             * \brief Unselect current slave device to end transaction
             */
            void unselect_chip();

            /*
             * \brief SPI master read
             *
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return True if transaction successful
             */
            bool spi_read(uint8_t* rbuf, size_t rlen) const;

            /*
             * \brief SPI master write
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return True if transaction successful
             */
            bool spi_write(const uint8_t *wbuf, size_t wlen) const;

            /*
             * \brief SPI master transaction (write/read operation)
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return True if transaction successful
             */
            bool spi_transaction(const uint8_t *wbuf, size_t wlen, uint8_t* rbuf, size_t rlen) const;
        };
    }
}

#endif

