/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPI_SLAVE_HPP
#define NOS_ENGINE_SPI_SLAVE_HPP

#include <Spi/visibility.hpp>
#include <Spi/Client/SpiDevice.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Common
    {
        class Message;
    }

    namespace Spi
    {
        /*
         * \brief Abstract client side SPI slave device
         *
         * The NOS SPI implementation differs at the hardware protocol level for performance reasons.
         * The slave device receives the entire transaction at once, returning the number of bytes
         * read/written to indicate transaction success/failure.
         *
         * These implementation details should be transparent to the end user.
         */
        class NOS_ENGINE_SPI_API_PUBLIC SpiSlave : public SpiDevice
        {
        public:
            /*
             * \brief Create SPI slave device on the named bus
             *
             * The registered chip select value is an arbitrary integer assigned to the slave device
             * used by the SPI master to select the appropriate transaction slave device.
             *
             * \param cs SPI chip select value
             * \param connection NOS connection string
             * \param bus SPI bus name
             * \param num_service_threads The number of service threads that should be created
             */
            SpiSlave(
                int cs,
                const std::string& connection,
                const std::string& bus = "spi",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create SPI slave device on the named bus
             *
             * The registered chip select value is an arbitrary integer assigned to the slave device
             * used by the SPI master to select the appropriate transaction slave device.
             *
             * \param transport_hub Existing transport hub to use
             * \param cs SPI chip select value
             * \param connection NOS connection string
             * \param bus SPI bus name
             */
            SpiSlave(
                Transport::TransportHub &transport_hub,
                int cs,
                const std::string& connection,
                const std::string& bus = "spi");

            /*
             * \brief Destructor
             */
            virtual ~SpiSlave();

            /*
             * \brief SPI master read
             *
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Number of bytes read
             */
            virtual size_t spi_read(uint8_t* rbuf, size_t rlen) = 0;

            /*
             * \brief SPI master write
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return Number of bytes written
             */
            virtual size_t spi_write(const uint8_t *wbuf, size_t wlen) = 0;

        private:
            void init();

            /*
             * \brief On new message callback
             *
             * \param message New received message
             */
            void on_message(const Common::Message& message);
        };
    }
}

#endif

