/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_UTIL_GENERIC_POOL_HPP
#define ITC_UTIL_GENERIC_POOL_HPP

//Here the MSVC warning 4100 is being deliberately disabled. This is due to the fact that GenericPoolAllocator does not use the obj parameter in
//the test method.  Due to the fact that the class is a template, the implementation must be defined here.
#ifdef WIN32
#pragma warning(push)
#pragma warning(disable : 4100)
#elif defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#endif
#include <list>

#include <itc_time_support.hpp>
#include <itc_thread_support.hpp>
#include <boost/noncopyable.hpp>
#include <boost/optional.hpp>

#ifdef ITC_COMMON_CXX11
#include <functional>
#define BIND_REAPER(X) std::bind(X,this)
#else
#include <boost/function.hpp>
#include <boost/bind.hpp>
#define BIND_REAPER(X) boost::bind(X,this)
#endif

namespace ItcUtil
{
    /**
     * Template class used to allocate, deallocate, and test pooled objects.
     */
    template< class T >
    class GenericPoolAllocator
    {
    public:
        /**
         * \brief Destructor to clean up the allocator.  This method should
         * NOT deallocate any previously-allocated objects.  This
         * method may not throw an exception.
         */
        virtual ~GenericPoolAllocator() throw()
        {}

        /**
         * \brief  Allocate a new object.  If this method throws an exception,
         * the exception will be propagated to whomever called the pool's
         * get() method.
         *
         * \summary The returned object is NOT checked for validity by the test()
         * method before being returned to the pool.get() method to prevent
         * infinite loops in the pool.  This method must ensure that the
         * returned object is valid, or else throw an exception.
         *
         * \return Newly-allocated object.
         */
        virtual T allocate() = 0;

        /**
         * \brief Deallocate an existing object.  This method may not throw
         * an exception.
         */
        virtual void deallocate(T obj) throw() = 0;

        /**
         * \brief Tests an object for validity before re-using the object from the
         * pool.  This method may not throw an exception.
         *
         * \return 0 if the object is valid
         * \return 1 if the object is invalid and should be deallocated
         */
        virtual int test(T obj) throw()
        {
            return 0;
        }
    };

    /**
     * \brief Generic object pool implementation.
     *
     * \summary
     * Objects in the pool are allocated on demand up to a specified maximum.
     * Once the maximum number of objects is met, future calls to retrieve an
     * object from the pool will block until another thread releases an object.
     *
     * The pool may be initialized with a number of objects.  If configured,
     * all the items will be allocated in the constructor.  Note that object
     * allocation may throw an exception, so if this parameter is used, be
     * prepared to handle exceptions when initializing the pool.  This feature
     * is turned OFF by default.
     *
     * If an object in the pool is not used within a certain timeout period,
     * it can be automatically deallocated and removed from the pool.  This
     * functionality can be used to dynamically increase and decrease the
     * number of items in the pool according to system load.  The timeout period
     * and how often the background thread checks for timed out resources can
     * be specified in the constructor.  Each is turned OFF by default.
     *
     * When the pool is closed, all objects in the pool will be deallocated.
     * Any objects that are not currently in the pool will be leaked!  Therefore,
     * the recommended usage for this class is to create one pool instance per
     * object type at program startup and destroy it at program termination.
     */
    template< class T >
    class GenericPool : private boost::noncopyable
    {
    public:
        typedef GenericPoolAllocator< T > Allocator;

        /**
         * \brief Instantiates a pool.
         *
         * \param alloc Pointer to a GenericPoolAllocator instance
         *              responsible for allocating, deallocating, and
         *              testing objects in the pool.  May not be NULL.
         * \param max Maximum number of objects in the pool.  This
         *            number sets the upper limit of items both in use
         *            and pooled.  Must be greater than 0.
         * \param initial Initial number of items to allocate.  If greater
         *                than 0, this parameter determines the number of
         *                objects to allocate in the constructor.  Defaults
         *                to 0.  Must be greater than or equal to 0.  Must be
         *                less than or equal to the maximum number of objects.
         * \param timeout If an object sits in the pool for this many seconds,
         *                it is automatically deallocated and removed from
         *                the pool.  If this parameter is less than or equal
         *                to 0, timeouts will not be enforced.
         * \param reaperPeriod Period, in seconds, that the background reaper
         *                     thread will wait between consecutive checks for
         *                     timed out objects.  This parameter defaults to
         *                     60 seconds.  Must be greater than 0.
         */
        explicit GenericPool(Allocator *alloc, const int max, const int initial = 0, const int timeout =
                                 -1, const int reaperPeriod = 60) :
            initial(initial), max(max), timeout(timeout), reaperPeriod(reaperPeriod), alloc(alloc),
            mutex(), condition(), avail(), out(0), reaperThread(), closing(false)
        {
            assert(alloc);
            assert(max > 0);
            assert(initial >= 0);
            assert(initial <= max);
            assert(reaperPeriod > 0);

            // create initial objects
            ABSOLUTE_TIME objTimeout;

            if(timeout > 0)
                objTimeout = ITC_TIME_NOW + ITC_SECONDS(timeout);

            for(int i = 0; i < initial; ++i)
            {
                T obj = alloc->allocate();
                avail.push_back(ObjectTimeout(obj, objTimeout));
            }

            // start reaper thread if timeout is specified
            if(timeout > 0)
            {
                reaperThread = THREAD(BIND_REAPER(&GenericPool::reaper));
            }
        }

        /**
         * \brief Closes the pool.  During this method, the following actions occur:
         *   1 - Reaper thread is stopped
         *   2 - Objects in the pool are deallocated
         *
         * \summary This method can only deallocate objects that are currently in the
         * pool.  If other threads happen to be holding pooled objects when
         * the pool is closed, the pooled objects will be leaked!
         */
        ~GenericPool() throw()
        {
            closing = true;
            // stop reaper thread
            //reaperThread.interrupt();
            if(reaperThread.joinable())
                reaperThread.join();

            // deallocate all objects in pool; this assumes all resources
            // have been returned
            {
                LOCK_GUARD lock(mutex);

                for(typename AvailableList::iterator it = avail.begin(); it != avail.end(); ++it)
                {
                    alloc->deallocate(it->first);
                }

                avail.clear();
            } // unlock mutex

            alloc = NULL;
        }

        /**
         * \brief Retrieves an item from the pool.
         * \summary Retrieves an item from the pool.  If an item is available in the
         * pool, it is tested and, if successful, returned.  If no valid
         * objects are in the pool, one of two things will happen:
         *   1 - if the number of objects in use is less than the maximum
         *       object count, a new object is allocated and returned
         *   2 - if the number of objects in use is greater than or equal
         *       to the maximum, this method will block until an object
         *       is returned to the pool in another thread
         */
        T get()
        {
            UNIQUE_LOCK lock(mutex);   // lock mutex
            boost::optional< T > obj = getNextAvail();

            if(!obj)   // no objects in pool
            {
                if(out >= max)   // maximum exceeded
                {
                    // wait for item to be released in release() call
                    do
                    {
                        condition.wait(lock);
                        obj = getNextAvail();
                    }
                    while(!obj);
                }
                else // no max, or max not yet exceeded
                {
                    // create a new item
                    obj.reset(alloc->allocate());
                }
            }

            ++out; // increment counter while holding mutex
            return *obj;
        }

        /**
         * \brief Releases an object back to the pool.  If any threads are
         * waiting for an object, they will be signaled.
         */
        void release(T obj)
        {
            ABSOLUTE_TIME objTimeout(ITC_TIME_NOW + ITC_SECONDS(timeout));

            LOCK_GUARD lock(mutex);   // lock mutex
            avail.push_back(ObjectTimeout(obj, objTimeout));     // add back to pool
            --out; // decrement out counter while holding mutex
            condition.notify_one(); // notify any listeners
        }

        const int initial;
        const int max;
        const int timeout;
        const int reaperPeriod;

    private:
        typedef std::pair< T, ABSOLUTE_TIME > ObjectTimeout;
        typedef std::list< ObjectTimeout > AvailableList;

        Allocator *alloc;
        MUTEX mutex;
        CONDITION_V condition;
        AvailableList avail;
        int out;
        THREAD reaperThread;
        bool closing;

        boost::optional< T > getNextAvail()
        {
            while(!avail.empty())
            {
                T obj = avail.front().first;
                avail.pop_front();

                if(alloc->test(obj))
                {
                    alloc->deallocate(obj);    // failed test; free resources
                }
                else
                {
                    return boost::optional< T >(obj);
                }
            }

            return boost::optional< T >();
        }

        void reaper()
        {
            while(1)
            {
                THREAD_SLEEP(ITC_SECONDS(reaperPeriod));

                if(closing)
                    return;
                // lock mutex
                {
                    LOCK_GUARD lock(mutex);
                    ABSOLUTE_TIME curTime(ITC_TIME_NOW);

                    for(typename AvailableList::iterator it = avail.begin(); it != avail.end();)
                    {
                        if(curTime > it->second)
                        {
                            // objects' inactivity timeout has expired; deallocate
                            // and remove from the avail list
                            alloc->deallocate(it->first);
                            it = avail.erase(it);
                        }
                        else
                        {
                            ++it;
                        }
                    }
                } // unlock mutex
            }
        }
    };
}

#ifdef WIN32
#pragma warning(pop)
#elif defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

#endif /* ITC_UTIL_GENERIC_POOL_HPP_HPP */
