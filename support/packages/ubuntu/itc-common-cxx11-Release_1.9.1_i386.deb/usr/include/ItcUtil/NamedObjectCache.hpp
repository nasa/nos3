/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NAMED_OBJECT_CACHE_HPP
#define NAMED_OBJECT_CACHE_HPP

#include <map>
#include <string>

#include <boost/noncopyable.hpp>
#include <ItcUtil/ItcAssert.hpp>
#include <itc_thread_support.hpp>

namespace ItcUtil
{
    /**
       \brief Named object cache implementation.
    */
    template< class T >
    class NamedObjectCache : private boost::noncopyable
    {
    public:
        /**
         \brief Template class used to allocate and deallocate cached objects.
        */
        class NamedObjectCacheAllocator
        {
        public:
            /**
               \brief Destructor to clean up the allocator.

               This method should NOT deallocate any previously-allocated objects.  This
               method may not throw an exception.
            */
            virtual ~NamedObjectCacheAllocator() throw()
            {}

            /**
               \brief Allocate a new object.

               If this method throws an exception, the exception will be propagated to
               whomever called the \ref NamedObjectCache::get() method.

               Note that the implementation of the allocate() method must not call
               any method within the NamedObjectCache, or else a deadlock will occur.

               \param name  Unique object name

               \return Newly-allocated object
            */
            virtual T *allocate(const char *name) = 0;

            /**
               \brief Deallocate an existing object.

               Note that the implementation of the deallocate() method must not call
               any method within the NamedObjectCache, or else a deadlock will occur.

               \param obj  Object to deallocate
            */
            virtual void deallocate(T *obj) throw() = 0;
        };

        typedef NamedObjectCacheAllocator Allocator;
        typedef std::map< std::string, T * > T_map;

        /**
           \brief Instantiates a new object cache.

           \param alloc  Reference to a NamedObjectCacheAllocator instance responsible for
                         allocating, deallocating, and testing objects in the cache.
         */
        NamedObjectCache(Allocator &alloc) :
            alloc(alloc),
            objects(),
            mutex()
        {}

        /**
           \brief Closes the cache.

           During shutdown, all objects in the cache are deallocated.  Users of the object
           cache must ensure objects are not used once the cache is shutdown.

           This method is not thread-safe.  Users must be sure that no other threads are
           accessing cached objects during shutdown.
        */
        ~NamedObjectCache() throw()
        {
            // deallocate all objects in cache; no need to lock mutex as nobody should be
            // using the cache anymore
            for(typename T_map::iterator it = objects.begin(); it != objects.end(); ++it)
            {
                alloc.deallocate(it->second);
            }

            objects.clear();
        }

        /**
           \brief Retrieves an object from the cache by name.

           If an item is available from the cache, it is returned.  If the named item is not yet
           in the cache, it is allocated, inserted into the cache, and returned.

           Callers of this method must not deallocate the returned pointer.

           This method is thread-safe and may be called synchronously from multiple threads
           at the same time.

           \param name    Unique name of the object to retrieve from the cache
           \param create  If true, and the object does not already exist in the cache, a new
                            object will be created using the allocator.  If false, and the
                            object does not already exist in the cache, NULL will be returned

           \return Cached object, or NULL if create=false and the object does not already exist
        */
        T *get(const char *name, bool create = true)
        {
            // get read lock
            LOCK_GUARD lock(mutex);

            // find object; if available, return it
            typename T_map::iterator it = objects.find(name);

            if(it != objects.end())
            {
                return it->second;
            }

            // still not in cache; allocate it if create=true
            if(create)
            {
                T *obj = alloc.allocate(name);
                std::pair< typename T_map::iterator, bool > rv = objects.insert(typename T_map::value_type(name, obj));
                itc_assert0(rv.second, "Unable to insert object");
                return obj;
            }
            else
            {
                return NULL;
            }
        }

        /**
           \brief Removes and object from the cache.

           Once an object is removed from the cache, it must not be used again.  Any existing
           pointers to the object should be considered invalid.

           If the named object is not in the cache, this method is effectively a no-op.

           \param name  Name of the object to remove from the cache
         */
        void release(const char *name)
        {
            // acquire write lock
            LOCK_GUARD lock(mutex);

            // lookup, remove, and deallocate the object
            typename T_map::iterator it = objects.find(name);

            if(it != objects.end())
            {
                alloc.deallocate(it->second);
                objects.erase(it);
            }
        }

    private:
        Allocator &alloc;
        T_map objects;
        MUTEX mutex;
    };
}

#endif
