/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_IPC_MESSAGE_QUEUE_SERVER_HPP
#define ITC_IPC_MESSAGE_QUEUE_SERVER_HPP

#include <boost/noncopyable.hpp>

#include <itc_functional_support.hpp>

#include <ItcIpc/MessageQueue/Types.hpp>

namespace ItcIpc
{
    namespace MessageQueue
    {
        typedef ITC_FUNCTION<void(ClientId client_id)> ClientConnectedToServerCallback;
        typedef ITC_FUNCTION<void(ClientId client_id)> ClientDisconnectedFromServerCallback;

        /**
            \brief A server reader/writer for a message queue.

            Reader and writer queues are seperate and allow reading and writing concurrently.

            Each client connected to the server has it's own read/write queues.

            This class is thread-safe.

            This class attempts to abstract away the behavior of IPC queues from the OS into a standard interface.
            On both POSIX (sysv message queues) and Windows (named pipes) a path to a file is used. All users must create
            an object with this in mind. Specific implementations of this class can translate such a name into something
            usable by the OS.
        */
        class DLL_PUBLIC Server : public boost::noncopyable
        {
        public:
            /**
                \brief Instantiates a server

                Only one server is allowed per message queue.

                \param path       Unique name for the message queue
                \param max_bytes  Maximum number of bytes that may be sent (not used, included for backwards compatibility)

                \throw IPCError             When a general IPC error occors
                \throw InvalidName          Provided \ref path is invalid
                \throw ServerAlreadyExists  A \ref Server does not yet exist on the \ref path
                \throw OSError              An OS error occurred
             */
            Server(const char *path, size_t max_bytes)
                throw(IPCError, InvalidName, ServerAlreadyExists, OSError);
            
            /**
                \brief Instantiates a server

                Only one server is allowed per message queue.

                \param path                     Unique name for the message queue
                \param connected_callback       Callback to execute when a client connects
                \param disconnected_callback    Callback to execute when a client disconnects
                \param read_timeout             Default blocking receive timeout
                
                \throw IPCError             When a general IPC error occors
                \throw InvalidName          Provided \ref path is invalid
                \throw ServerAlreadyExists  A \ref Server does not yet exist on the \ref path
                \throw OSError              An OS error occurred
             */
            Server(const char *path,
                   ClientConnectedToServerCallback connected_callback,
                   ClientDisconnectedFromServerCallback disconnected_callback = ITC_NULL_FUNCTION,
                   unsigned long read_timeout = IPC_NO_TIMEOUT)
                throw(IPCError, InvalidName, ServerAlreadyExists, OSError);

            /**
                \brief Closes a server
            */
            ~Server();
            
            /**
                \brief Get a list of IDs for the clients currently connected to the server.
                
                \return The list of client IDs.
                
                \throw IPCError When a general IPC error occors
            */
            ClientIds get_client_ids()
                throw(IPCError);
            
            /**
                \brief Set the callback to execute when a client connects.
                
                \param callback The connection callback.
                
                \throw IPCError When a general IPC error occors
            */
            void set_client_connected_callback(ClientConnectedToServerCallback callback)
                throw(IPCError);
            
            /**
                \brief Set the callback to execute when a client disconnects.
                
                \param callback The disconnection callback.
                
                \throw IPCError When a general IPC error occors
            */
            void set_client_disconnected_callback(ClientDisconnectedFromServerCallback callback)
                throw(IPCError);

            /**
                \brief Set the default blocking receive timeout.

                Sets the amount of time a blocking receive will wait for a message to be received.
                If a message isn't received withing the timeout period IPC_NO_MESSAGE is returned
                by the receive method.

                \param timeout The timeout in milliseconds.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            void set_receive_timeout(unsigned long timeout)
                throw(IPCError, OSError);

            /**
                \brief Get the default blocking receive timeout.

                \return The timeout in milliseconds.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            unsigned long get_receive_timeout()
                throw(IPCError, OSError);
            
            /**
                \brief Write data to a message queue for the specified client

                This method is thread safe.

                \param client_id    The ID of the client to send the data to
                \param buf          Pointer to the data to write
                \param size         The number of bytes to write.
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            void send_to(const ClientId client_id, const char *const buf, const size_t size)
                throw(IPCError, MessageQueueClosed, OSError);

            /**
                \brief Read from one of the client queues.

                This method blocks until a message is received.  If the message is longer
                than the size of the provided buffer, the message is truncated.

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.

                \param buf   The buffer to store the read data in
                \param size  The size of the buffer storing the read data
                
                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t receive(char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Read from one of the client queues.

                This method blocks until a message is received.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.

                \param buf  The buffer to store the read data in
                
                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t receive(char **buf)
                throw(IPCError, MessageQueueClosed, OSError);

            /**
                \brief Try to read from the queue.

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.

                If the message is longer than the size of the provided buffer,
                the message is truncated.

                \param buf   The buffer to store the read data in
                \param size  The size of the buffer storing the read data

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t try_receive(char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Try to read from the queue.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.

                \param buf   The buffer to store the read data in

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed
                \throw OSError              An OS error occurred
             */
            size_t try_receive(char **buf)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Read from the specified client queue

                This method blocks until a message is received.  If the message is longer
                than the size of the provided buffer, the message is truncated.

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.
                
                \param client_id    The ID of the client to receive the data from
                \param buf          The buffer to store the read data in
                \param size         The size of the buffer storing the read data
                
                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed or client not connected
                \throw OSError              An OS error occurred
             */
            size_t receive_from(const ClientId client_id, char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Read from the specified client queue

                This method blocks until a message is received.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                There are two situations where this method can return before a message is
                received.
                1) A messages isn't available before the receive timeout is reached.
                2) The cancel_receive method is called by another thread.
                In both cases IPC_NO_MESSAGE is returned.
                
                \param client_id    The ID of the client to receive the data from
                \param buf          The buffer to store the read data in
                
                \return The number of bytes read (IPC_NO_MESSAGE if timeout hit or canceled).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed or client not connected
                \throw OSError              An OS error occurred
             */
            size_t receive_from(const ClientId client_id, char **buf)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Try to read from the specified client queue.

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.

                If the message is longer than the size of the provided buffer,
                the message is truncated.
                
                \param client_id    The ID of the client to receive the data from
                \param buf          The buffer to store the read data in
                \param size         The size of the buffer storing the read data

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed or client not connected
                \throw OSError              An OS error occurred
             */
            size_t try_receive_from(const ClientId client_id, char *buf, size_t size)
                throw(IPCError, MessageQueueClosed, OSError);
            
            /**
                \brief Try to read from the specified client queue.

                The caller of this method is responsible for freeing the memory
                allocated for buf (via delete[]).

                This method will attempt to read a message; if none are available,
                this method will return IPC_NO_MESSAGE immediately.
                
                \param client_id    The ID of the client to receive the data from
                \param buf          The buffer to store the read data in

                \return The number of bytes read (IPC_NO_MESSAGE if no messages are available).
                
                \throw IPCError             When a general IPC error occors
                \throw MessageQueueClosed   The message queue was closed or client not connected
                \throw OSError              An OS error occurred
             */
            size_t try_receive_from(const ClientId client_id, char **buf)
                throw(IPCError, MessageQueueClosed, OSError);

            /**
                \brief Cancel the next or current receive.

                A call to this method will cancel the next or current blocking receive.
                It is possible to also cancel a try_receive if the call happens before
                the try_receive call.
                
                \throw IPCError When a general IPC error occors
                \throw OSError  An OS error occurred
            */
            void cancel_receive()
                throw(IPCError, OSError);
            
            /**
                \brief Get a value indicating if one or more clients are connected to the server.

                \return true if clients are connected, false otherwise
             */
            bool connected() const
                throw();

            /**
                \brief Closes all client connections to the server.
            */
            void close()
                throw(IPCError, OSError);
            
            /**
                \brief Closes a client connection to the server.

                \param client_id    The ID of the client
            */
            void close(const ClientId client_id)
                throw(IPCError, OSError);

        private:
            class ServerImpl;
            ServerImpl *impl;
        };
    }
}

#endif /* ITC_IPC_MESSAGE_QUEUE_SERVER_HPP */
