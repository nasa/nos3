/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_LOGGER_MEMORY_TARGET_IMPL_HPP
#define ITC_LOGGER_MEMORY_TARGET_IMPL_HPP

#include <string>
#include <vector>

#include <ItcLogger/TargetImpl.hpp>

namespace ItcLogger
{
    /**
        \brief Logger target that keeps all log messages in memory

        This class was designed primarily for writing unit tests that need to
        check for specific logging output.  As such, it is expected that users
        of this class do not call the \ref log method (the logging library
        will take care of that for you), and instead only access the
        \ref msgs public member to access all logged messages.

        This target takes no parameters.
    */
    class MemoryTargetImpl : public TargetImpl
    {
    public:

        /**
            \brief Container for a log message
        */
        struct LogMessage
        {
            log_level_t level;  //!< Log level
            std::string msg;    //!< Log message
        };

        /**
            \brief Creates a memory target

            \param args  Not used, included for compatibility

            \throw InvalidArguments  Not throw, included for compatiblity
        */
        MemoryTargetImpl(const LogArguments &args) throw(InvalidArguments);

        /**
            \brief Closes a memory target

            All in-memory log entries are freed.
        */
        virtual ~MemoryTargetImpl();

        /**
            \brief Log a message

            \param log_level  Log level
            \param msg        Log message

            \throw bad_alloc  Creation of a \ref LogMessage failed
         */
        virtual void log(log_level_t log_level, const char *msg) throw(std::bad_alloc);

        std::vector< LogMessage > msgs;  //!< Set of all received log messages
    };
}

#endif /* ITC_LOGGER_MEMORY_TARGET_IMPL_HPP */
