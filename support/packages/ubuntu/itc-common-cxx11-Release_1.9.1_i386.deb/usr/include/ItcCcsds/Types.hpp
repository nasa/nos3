/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_TYPES_HPP
#define ITC_CCSDS_TYPES_HPP

#include <stdint.h>

namespace ItcCcsds
{
    /**
        \brief Definition of an "AOS Transfer Frame Data Field" that uses
        "Multiplexing Protocol Data Unit (M_PDU)".
    */
    struct AosMPDUHeader
    {
        uint16_t reserved           : 5;   //!< Reserved
        uint16_t firstHeaderPointer : 11;  //!< Offset to first Space Packet header
    };

    /**
        \brief Definition of an "AOS Transfer Frame Data Field" that uses
        "Bitstream Protocol Data Unit (B_PDU)".
    */
    struct AosBPDUHeader
    {
        uint16_t reserved    : 2;   //!< Reserved
        uint16_t dataPointer : 14;  //!< Data offset
    };

    /**
        \brief Definition of an "Operation Control Field" in an
        "AOS Transfer Frame Trailer".
    */
    struct AosOperationControlFieldTrailer
    {
        uint32_t type : 1;   //!< CLCW type
        uint32_t clcw : 31;  //!< CLCW data
    };

    /**
        \brief Definition of a "Frame Error Control Field" in an
        "AOS Transfer Frame Trailer".
    */
    struct AosFrameErrorControlFieldTrailer
    {
        uint16_t crc;  //!< CRC16 checksum
    };

    /**
        \brief Definition of M_PDU "First Data Pointer" header value when no packet is
        present.  AOS specification states that it is "all ones".
    */
#define M_PDU_NO_PACKET_START_FIRST_HEADER_POINTER  0x7ff

    /**
        \brief Definition of M_PDU "First Data Pointer" header value when only idle data is
        present.  AOS specification states that it is "all ones minus one".
    */
#define M_PDU_IDLE_FIRST_HEADER_POINTER     0x7fe

    /**
        \brief Definition of the B_PDU "Bitstream Data Pointer" header value when no
        idle data is present.  AOS specification states that it is "all ones".
    */
#define B_PDU_ALL_DATA_VALID   0x3fff

    /**
        \brief Definition of the B_PDU "Bitstream Data Pointer" header value when all
        data is idle data.  AOS specification states that it is "all ones minus one"
    */
#define B_PDU_NO_DATA_VALID    0x3ffe

    /**
        \brief Enumeration of all transfer frame types.
    */
    enum TransferFrameType
    {
        FRAME_TYPE_M_PDU,   //!< Indicates that the AOS data frame contains M_PDU structures
        FRAME_TYPE_B_PDU    //!< Indicates that the AOS data frame contains B_PDU structures
    };

    /**
        \brief Enumeration of all possible transfer frame trailers.
    */
    enum TransferFrameTrailerType
    {
        NO_TRANSFER_FRAME_TRAILER,       //!< Indicates no trailers are expected
        OPERATIONAL_CONTROL_FIELD_ONLY,  //!< Indicates the "Operational Control Field" is present
        FRAME_ERROR_CONTROL_FIELD_ONLY,  //!< Indicates the "Frame Error Control Field" is present
        BOTH_TRANSFER_FRAME_TRAILER      //!< Indicates both the "Operational Control Field" and "Frame Error Control Field" are present
    };
}

#endif /* ITC_CCSDS_TYPES_HPP */
