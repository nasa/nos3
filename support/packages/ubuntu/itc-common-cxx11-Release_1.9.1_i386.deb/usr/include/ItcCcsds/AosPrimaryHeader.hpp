/* Copyright (C) 2009 - 2012 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.


   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,

   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef ITC_CCSDS_AOS_PRIMARY_HEADER_HPP
#define ITC_CCSDS_AOS_PRIMARY_HEADER_HPP

#include <stdint.h>

#include <itc_visibility.hpp>

#include <ItcCcsds/BadFrameSize.hpp>

#define AOS_PRI_HDR_MIN_SIZE  6

namespace ItcCcsds
{
    /**
        \brief Definition of an "AOS Transfer Frame Primary Header".

        Spacecraft telemetry is typically in AOS format, so
        every downlinked frame will start with this structure.

        Note that this structure contains the 'frame header
        error control' field, which is OPTIONAL according to
        the standard.  Therefore, one may not assume that
        sizeof(AosPrimaryHeader) is the actual size in use
        by any particular AOS channel.
    */
    class DLL_PUBLIC AosPrimaryHeader
    {
    public:

        /**
            \brief  Parses a AOS primary header from a buffer

            If \ref buf_len>=8, the optional \ref frameHeaderErrorControl field
            is parsed, regardless of whether or not that field is applicable
            for the AOS channel being parsed.

            \param buf      Buffer to parse
            \param buf_len  Buffer length, in bytes

            \return Parsed AOS primary header

            \throw BadFrameSize if buf_len<AOS_PRI_HDR_MIN_SIZE
        */
        static AosPrimaryHeader unpack(const unsigned char *buf, unsigned int buf_len) throw(BadFrameSize);

        /**
            \brief Same as \ref unpack, but updates an already-allocated header
            instead of creating a new one on the stack.

            \param buf      Buffer to parse
            \param buf_len  Buffer length, in bytes
            \param hdr      Existing AOS primary header to update

            \throw BadFrameSize if buf_len<AOS_PRI_HDR_MIN_SIZE
         */
        static void unpack(const unsigned char *buf,
                           unsigned int buf_len,
                           AosPrimaryHeader &hdr)
        throw(BadFrameSize);

        /**
            \brief Creates a new instance

            All values exception \ref versionNumber is initialized to 0.
            \ref versionNumber is initialized to 0b01, as prescribed by
            the AOS specification.
        */
        AosPrimaryHeader();

        /**
            \brief Default destructor
        */
        ~AosPrimaryHeader();

        /* AOS Master Channel ID */
        uint16_t versionNumber : 2;
        uint16_t spacecraftId  : 8;

        uint16_t virtualChannelId : 6;

        uint16_t virtualChannelFrameCountMSW;
        uint16_t virtualChannelFrameCountLSB : 8;

        /* AOS Signaling Field */
        uint16_t replayFlag                    : 1;
        uint16_t virtualChannelFrameCountUsage : 1;
        uint16_t reserved                      : 2;
        uint16_t virtualChannelFrameCountCycle : 4;

        uint16_t frameHeaderErrorControl;

        /**
            \brief Retrieves the virtual channel frame count.

            This method will combine the \ref virtualChannelFrameCountMSW,
            \ref virtualChannelFrameCountLSB, \ref virtualChannelFrameCountUsage,
            and \ref virtualChannelFrameCountCycle into a single integer as
            defined by the AOS standard.

            \return Frame count
        */
        unsigned int get_frame_count();

        /**
            \brief Sets the virtual channel frame count.

            This method will set the \ref virtualChannelFrameCountMSW,
            \ref virtualChannelFrameCountLSB, and \ref virtualChannelFrameCountCycle
            as appropriate.

            The new value will wrap around to 0 as appropriate.

            \param count  New frame count value
        */
        void set_frame_count(unsigned int count);
    };
}

#endif /* ITC_CCSDS_AOS_PRIMARY_HEADER_HPP */
