/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPI_DEVICE_HPP
#define NOS_ENGINE_SPI_DEVICE_HPP

#include <Spi/visibility.hpp>
#include <Spi/Types.hpp>
#include <Client/Bus.hpp>
#include <Client/DataNode.hpp>
#include <Transport/TransportHub.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Spi
    {
        /*
         * \brief Base SPI device
         *
         * This SPI device base class provides common NOS engine connection code and is not meant
         * to be used directly.
         */
        class NOS_ENGINE_SPI_API_PUBLIC SpiDevice
        {
        public:
            /*
             * \brief Create SPI device on the named bus
             *
             * \param mode SPI device mode
             * \param cs SPI device chip select value
             * \param connection NOS connection string
             * \param bus SPI bus name
             * \param num_service_threads The number of service threads that should be created
             */
            SpiDevice(
                Mode mode,
                int cs,
                const std::string& connection,
                const std::string& bus = "spi",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create SPI device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param mode SPI device mode
             * \param cs SPI device chip select value
             * \param connection NOS connection string
             * \param bus SPI bus name
             */
            SpiDevice(
                Transport::TransportHub &transport_hub,
                Mode mode,
                int cs,
                const std::string& connection,
                const std::string& bus = "spi");

            /*
             * \brief Destructor
             */
            virtual ~SpiDevice();

            /**
             * \brief Get the transport hub used by this instance.
             * 
             * If the instance owns the hub (ie hub was not provided to the constructor) then use
             * the hub returned with caution.  When this instance is destroyed the hub it owns
             * will be destroyed as well.
             * 
             * \return The tranport hub of this instance.
             */
            Transport::TransportHub &get_transport_hub() const;

            /*
             * \brief Get SPI device mode
             *
             * \return SPI device mode
             */
            Mode get_mode() const;

        protected:
            Client::Bus bus; //!< NOS engine SPI bus
            Client::DataNode *node; //!< NOS engine SPI data node
            Mode mode; //!< SPI device mode
            int cs; //!< SPI device chip select

        private:
            void init();
        };
    }
}

#endif

