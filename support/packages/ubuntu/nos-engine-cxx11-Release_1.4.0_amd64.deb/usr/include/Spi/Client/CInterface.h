/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SPI_C_INTERFACE
#define NOS_ENGINE_SPI_C_INTERFACE

#include <Spi/visibility.hpp>
#include <stdint.h>
#include <stddef.h>

#include <Client/CInterface.h>

/*
 * \brief Invalid SPI chip select
*/
#define SPI_CS_NONE -1

/*
 * \brief Opaque SPI device handle
 */
#ifdef __cplusplus
    #include <Spi/Client/SpiDevice.hpp>
    typedef NosEngine::Spi::SpiDevice NE_SpiHandle;
#else
    typedef struct NE_SpiHandle NE_SpiHandle;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * \brief SPI status codes
 */
typedef enum
{
    NE_SPI_SUCCESS = 0,
    NE_SPI_FAILURE
} NE_SpiStatus;

/*
 * \brief SPI transaction direction
 */
typedef enum
{
    NE_SPI_WRITE = 0,
    NE_SPI_READ
} NE_SpiDirection;

/*
 * \brief SPI device data callback function
 *
 * The SPI slave device is responsible for checking the transaction direction and
 * taking the appropriate action with the buffer and returning the number of bytes
 * read/written.
 */
typedef size_t(*NE_SpiDataCallback)(NE_SpiDirection dir, uint8_t *buf, size_t len);

/*
 * \brief Initialize SPI master device on the named bus
 *
 * \param connection NOS connection string
 * \param bus SPI bus name
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_master(const char *connection, const char *bus);

/*
 * \brief Initialize SPI master device on the named bus
 *
 * \param connection NOS connection string
 * \param bus SPI bus name
 * \param num_service_threads The number of service threads that should be created
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_master2(const char *connection, const char *bus, const size_t num_service_threads);

/*
 * \brief Initialize SPI master device on the named bus
 *
 * \param transport_hub Existing transport hub to use
 * \param connection NOS connection string
 * \param bus SPI bus name
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_master3(NE_TransportHub *transport_hub, const char *connection, const char *bus);

/*
 * \brief Initialize SPI slave device on the named bus
 *
 * \param cs SPI device chip select value
 * \param connection NOS connection string
 * \param bus SPI bus name
 * \param cb SPI transaction callback
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_slave(uint8_t cs, const char *connection, const char *bus, NE_SpiDataCallback cb);

/*
 * \brief Initialize SPI slave device on the named bus
 *
 * \param cs SPI device chip select value
 * \param connection NOS connection string
 * \param bus SPI bus name
 * \param cb SPI transaction callback
 * \param num_service_threads The number of service threads that should be created
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_slave2(uint8_t cs, const char *connection, const char *bus, NE_SpiDataCallback cb, const size_t num_service_threads);

/*
 * \brief Initialize SPI slave device on the named bus
 *
 * \param transport_hub Existing transport hub to use
 * \param cs SPI device chip select value
 * \param connection NOS connection string
 * \param bus SPI bus name
 * \param cb SPI transaction callback
 *
 * \return SPI device handle or NULL on error
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiHandle* NE_spi_init_slave3(NE_TransportHub *transport_hub, uint8_t cs, const char *connection, const char *bus, NE_SpiDataCallback cb);

/**
 * \brief Get the transport hub of the SPI device.
 * 
 * If the device owns the hub (ie hub was not provided to the init function) then use
 * the hub returned with caution.  When this device is closed the hub it owns
 * will be destroyed as well.
 * 
 * \return The tranport hub of the SPI device.
*/
extern NOS_ENGINE_SPI_API_PUBLIC
NE_TransportHub* NE_spi_get_transport_hub(NE_SpiHandle *spi);

/*
 * \brief Close SPI device handle
 *
 * \param spi SPI device handle
 */
extern NOS_ENGINE_SPI_API_PUBLIC
void NE_spi_close(NE_SpiHandle **spi);

/*
 * \brief Select SPI slave device for transaction
 *
 * \param spi SPI device handle
 * \param cs SPI device chip select value
 */
extern NOS_ENGINE_SPI_API_PUBLIC
void NE_spi_select_chip(NE_SpiHandle *spi, uint8_t cs);

/*
 * \brief Unselect SPI slave device to end transaction
 *
 * \param spi SPI device handle
 */
extern NOS_ENGINE_SPI_API_PUBLIC
void NE_spi_unselect_chip(NE_SpiHandle *spi);
 
/*
 * \brief SPI master read
 *
 * \param spi SPI device handle
 * \param rbuf Read data buffer
 * \param rlen Read data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiStatus NE_spi_read(NE_SpiHandle *spi, uint8_t *rbuf, size_t rlen);
 
/*
 * \brief SPI master write
 *
 * \param spi SPI device handle
 * \param wbuf Write data buffer
 * \param wlen Write data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiStatus NE_spi_write(NE_SpiHandle *spi, const uint8_t *wbuf, size_t wlen);
 
/*
 * \brief SPI master transaction (write/read operation)
 *
 * \param spi SPI device handle
 * \param wbuf Write data buffer
 * \param wlen Write data buffer length
 * \param rbuf Read data buffer
 * \param rlen Read data buffer length
 *
 * \return Status code
 */
extern NOS_ENGINE_SPI_API_PUBLIC
NE_SpiStatus NE_spi_transaction(NE_SpiHandle *spi, const uint8_t *wbuf, size_t wlen, uint8_t* rbuf, size_t rlen);

#ifdef __cplusplus
}
#endif

#endif

