/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_I2C_SLAVE_HPP
#define NOS_ENGINE_I2C_SLAVE_HPP

#include <I2C/visibility.hpp>
#include <I2C/Client/I2CDevice.hpp>
#include <I2C/Types.hpp>
#include <cstdint>
#include <string>

namespace NosEngine
{
    namespace Common
    {
        class Message;
    }

    namespace I2C
    {
        /*
         * \brief Abstract client side I2C slave device
         *
         * The NOS I2C implementation differs at the hardware protocol level for performance reasons.
         * The slave device does not ACK/NACK each individual byte, but receives the entire transaction
         * at once, returning the number of bytes read/written to indicate transaction success/failure.
         *
         * These implementation details should be transparent to the end user.
         */
        class NOS_ENGINE_I2C_API_PUBLIC I2CSlave : public I2CDevice
        {
        public:
            /*
             * \brief Create I2C slave device on the named bus
             *
             * \param address I2C slave device base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             * \param num_service_threads The number of service threads that should be created
             */
            I2CSlave(
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create I2C slave device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param address I2C slave device base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             */
            I2CSlave(
                Transport::TransportHub &transport_hub,
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c");

            /*
             * \brief Destructor
             */
            virtual ~I2CSlave();

            /*
             * \brief I2C master read
             *
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             *
             * \return Number of bytes read
             */
            virtual size_t i2c_read(uint8_t* rbuf, size_t rlen) = 0;

            /*
             * \brief I2C master write
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             *
             * \return Number of bytes written
             */
            virtual size_t i2c_write(const uint8_t *wbuf, size_t wlen) = 0;

        private:
            void init();

            /*
             * \brief On new message callback
             *
             * \param message New received message
             */
            void on_message(const Common::Message& message);
        };
    }
}

#endif

