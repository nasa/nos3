/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_I2C_DEVICE_HPP
#define NOS_ENGINE_I2C_DEVICE_HPP

#include <I2C/visibility.hpp>
#include <I2C/Types.hpp>
#include <Client/Bus.hpp>
#include <Client/DataNode.hpp>
#include <Transport/TransportHub.hpp>
#include <string>

namespace NosEngine
{
    namespace I2C
    {
        /*
         * \brief Base I2C device
         *
         * This I2C device base class provides common NOS engine connection code and is not meant
         * to be used directly.
         */
        class NOS_ENGINE_I2C_API_PUBLIC I2CDevice
        {
        public:
            /*
             * \brief Create I2C device on the named bus
             *
             * \param mode I2C device mode
             * \param address I2C base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             * \param num_service_threads The number of service threads that should be created
             */
            I2CDevice(
                Mode mode,
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Create I2C device on the named bus
             *
             * \param transport_hub Existing transport hub to use
             * \param mode I2C device mode
             * \param address I2C base address
             * \param connection NOS connection string
             * \param bus I2C bus name
             */
            I2CDevice(
                Transport::TransportHub &transport_hub,
                Mode mode,
                I2CAddress address,
                const std::string& connection,
                const std::string& bus = "i2c");

            /*
             * \brief Destructor
             */
            virtual ~I2CDevice();

            /**
             * \brief Get the transport hub used by this instance.
             * 
             * If the instance owns the hub (ie hub was not provided to the constructor) then use
             * the hub returned with caution.  When this instance is destroyed the hub it owns
             * will be destroyed as well.
             * 
             * \return The tranport hub of this instance.
             */
            Transport::TransportHub &get_transport_hub() const;

            /*
             * \brief Get I2C device mode
             *
             * \return I2C device mode
             */
            Mode get_mode() const;

            /*
             * \brief Get I2C device base address
             *
             * \return I2C device base address
             */
            I2CAddress get_address() const;

        protected:
            Client::Bus bus; //!< NOS engine I2C bus
            Client::DataNode *node; //!< NOS engine I2C data node
            Mode mode; //!< I2C device mode
            I2CAddress address; //!< I2C device base address

        private:
            void init();
        };
    }
}

#endif

