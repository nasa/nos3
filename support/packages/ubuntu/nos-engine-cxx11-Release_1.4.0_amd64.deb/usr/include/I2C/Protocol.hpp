/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_I2C_PROTOCOL_HPP
#define NOS_ENGINE_I2C_PROTOCOL_HPP

#include <I2C/visibility.hpp>
#include <Utility/Buffer.hpp>
#include <cstdint>

namespace NosEngine
{
    namespace I2C
    {
        /*
         * \brief I2C transaction data transmitted to slave device
         *
         * The I2C transaction direction is inferred from the read/write lengths. For example, a write
         * length of zero implies an I2C read, a read length of zero implies an I2C write, and a non-zero
         * length for both write and read implies an I2C transaction.
         *
         * The data is serialized in little endian format for performance since this common host format
         * will most likely result in a 'noop' conversion.
         */
        class NOS_ENGINE_I2C_API_PUBLIC ProtoTransaction
        {
        public:
            /*
             * \brief Constructor
             *
             * \param wbuf Write data buffer
             * \param wlen Write data buffer length
             * \param rlen Read data buffer length
             */
            ProtoTransaction(const uint8_t* wbuf, size_t wlen, size_t rlen);

            /*
             * \brief Deserialize buffer to I2C transaction data
             *
             * \param buffer Raw data buffer
             */
            ProtoTransaction(const Utility::Buffer& buffer);

            /*
             * \brief Serialize I2C transaction data into buffer
             *
             * \return Serialized buffer
             */
            Utility::Buffer serialize();
            
        public:
            const uint8_t* wbuf; //!< Write data buffer
            size_t wlen; //!< Write data buffer length
            size_t rlen; //!< Read data buffer length
        };

        /*
         * \brief I2C transaction response received from slave device
         *
         * The data is serialized in little endian format for performance since this common host format
         * will most likely result in a 'noop' conversion.
         */
        class NOS_ENGINE_I2C_API_PUBLIC ProtoResponse
        {
        public:
            /*
             * \brief Constructor
             *
             * \param wlen Number of bytes written
             * \param rbuf Read data buffer
             * \param rlen Read data buffer length
             */
            ProtoResponse(size_t wlen, const uint8_t* rbuf, size_t rlen);

            /*
             * \brief Deserialize buffer to I2C transaction response
             *
             * \param buffer Raw data buffer
             */
            ProtoResponse(const Utility::Buffer& buffer);

            /*
             * \brief Serialize I2C transaction response into buffer
             *
             * \return Serialized buffer
             */
            Utility::Buffer serialize();

        public:
            size_t wlen; //!< Number of bytes written
            const uint8_t* rbuf; //!< Read data buffer
            size_t rlen; //!< Read data buffer length
        };
    }
}

#endif

