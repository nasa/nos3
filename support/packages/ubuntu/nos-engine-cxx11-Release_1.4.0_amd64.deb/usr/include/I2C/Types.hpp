/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_I2C_TYPES_HPP
#define NOS_ENGINE_I2C_TYPES_HPP

#include <cstdint>

namespace NosEngine
{
    namespace I2C
    {
        typedef uint16_t I2CAddress; //!< I2C address type (support 10-bit addressing)

        const I2CAddress I2C_ADDRESS_MIN = 8;    //!< Minimum valid I2C address (0-7 reserved)
        const I2CAddress I2C_ADDRESS_MAX = 1023; //!< Maximum valid I2C address (support 10-bit addressing)

        /*
         * \brief I2C device mode
         */
        enum class Mode
        {
            I2C_MASTER = 0,
            I2C_SLAVE
        };

        /*
         * \brief I2C command result
         */
        enum class Result
        {
            I2C_SUCCESS = 0,
            I2C_ERROR,
            I2C_BUSY
        };
    }
}

#endif

