/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_BUFFER_OVERLAY_HPP
#define NOS_ENGINE_COMMON_BUFFER_OVERLAY_HPP

#include <Utility/Buffer.hpp>

#include <Common/visibility.hpp>
#include <Common/types.hpp>
#include <Common/IBufferOverlay.hpp>
#include <Common/ReadOnlyBufferOverlay.hpp>

namespace NosEngine
{
	namespace Common
    {
        ///
        /// \copydoc IBufferOverlay
        ///
		class NOS_ENGINE_COMMON_API_PUBLIC BufferOverlay :
            public IBufferOverlay
		{
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the BufferOverlay class.
            ///
            /// \param to_overlay The buffer which this is overlaying.
            /// 
			BufferOverlay(Utility::Buffer &to_overlay);

            /// 
            /// \brief Construct an instance of the BufferOverlay class.
            ///
            /// \param offset       Offset into the buffer which this overlays.
            /// \param to_overlay   The buffer which this is overlaying.
            /// 
            BufferOverlay(size_t offset, Utility::Buffer &to_overlay);

        private:
            BufferOverlay(const BufferOverlay &); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the BufferOverlay class.
            /// 
            virtual ~BufferOverlay();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BufferOverlay& operator=(const BufferOverlay &); //!< Disable the copy assignment operator.

        public:
            // ------------------------------------------------------------------------------------
            // IBufferOverlay implementation
            // ------------------------------------------------------------------------------------

            operator const Utility::Buffer*() const;

            operator ReadOnlyBufferOverlay() const;

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IBufferOverlay implementation
            // ------------------------------------------------------------------------------------

			void append(size_t append_len, const char *append_data, size_t grow_size = 0);

			void append(size_t offset, size_t append_len, const char *append_data, size_t grow_size = 0);

			const Utility::Buffer* get_const_buf() const;

            virtual size_t get_length() const;

            virtual size_t get_size() const;

            virtual char* get_data() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Update overlay attributes.
            /// 
			void update_attributes();

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- attributes ----
            size_t len;     //!< the length of the window into the buffer (overlay length)
            size_t size;    //!< the size of the window into the buffer (overlay size)
            char* data;     //!< the data window (overlay data)

        private:
            // ---- attributes ----
            size_t base_offset;         //!< offset into buffer which this overlays
            Utility::Buffer& buffer;    //!< reference to the buffer which this overlays
            Utility::Buffer conversion; //!< for conversion into a const Buffer pointer
		};
	}
}

#endif
