/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_IMESSAGE_ROUTER_HPP
#define NOS_ENGINE_COMMON_IMESSAGE_ROUTER_HPP

#include <Common/types.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief A class for routing NOS Engine messages for proper handling.
        ///
        /// In NOS Engine, Messages can have operations at different levels in the system (e.g, Server, Bus, Node).
        /// message routers can be chained together to provide an adaptable method to route a message
        /// to the particular entity that should handle its transaction. 
        ///
        class IMessageRouter :
            public virtual Utility::IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IMessageRouter class.
            /// 
            virtual ~IMessageRouter() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Validate and attempt to process the Message.
            ///
            /// First, the message is validated. Next, the Message is checked to see if it applies to 
            /// the TransactionManager and, if so, is processed. If not, the UnknownMessageFunc is called.
            ///
            /// \param to_route        Message to route
            /// \param send_interface  Where to send responses related to this Message
            ///
            /// \throw RoutingError if routing fails
            ///
			virtual void route_message(Message to_route, WeakSendOperator send_interface) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Validate that the Message is well-formed.
            ///
            /// Check to see if the Message is properly formatted.
            /// This is called first during the route_message() call-graph.
            ///
            /// \param to_validate  Message to validate
            ///
            virtual bool validate_message(const Message& to_validate) const = 0;

            ///
            /// \brief Check if the Message is intended for the TransactionManager.
            ///
            /// This is called second during the route_message() call-graph if the Message
            /// passed validation.
            ///
            /// \param to_check  Message to check
            ///
            virtual bool for_transaction_manager(const Message& to_check) const = 0;

            ///
            /// \brief Check if the Message is part of a new or existing Transaction.
            ///
            /// This is called third during the route_message() call-graph if the Message is
            /// for the TransactionManager.
            ///
            /// \param to_check  Message to check
            ///
            virtual bool message_is_new_transaction(const Message& to_check) const = 0;

            ///
            /// \brief Create a new Transaction for processing.
            ///
            /// \param message         Initial message of the Transaction
            /// \param send_interface  Where to send responses related to this Message
            ///
            virtual ITransaction* create_new_transaction(Message& message, WeakSendOperator send_interface) = 0;
        };           
    }
}


#endif
