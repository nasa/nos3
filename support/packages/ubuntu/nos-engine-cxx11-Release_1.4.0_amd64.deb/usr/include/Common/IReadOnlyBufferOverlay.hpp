/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_IREAD_ONLY_BUFFER_OVERLAY_HPP
#define NOS_ENGINE_COMMON_IREAD_ONLY_BUFFER_OVERLAY_HPP

#include <Utility/Buffer.hpp>

#include <Common/visibility.hpp>
#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Represents a read-only overlay (window) into an existing Buffer object.
        ///
        class IReadOnlyBufferOverlay :
            public virtual Utility::IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            virtual ~IReadOnlyBufferOverlay() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            virtual operator const Utility::Buffer*() const = 0;

            virtual size_t get_length() const = 0;

            virtual size_t get_size() const = 0;

            virtual const char* get_data() const = 0;
        };
    }
}

#endif