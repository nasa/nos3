/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_SYNCHRONOUS_TRANSACTION_WRAPPER_HPP
#define NOS_ENGINE_COMMON_SYNCHRONOUS_TRANSACTION_WRAPPER_HPP

#include <Common/types.hpp>
#include <Common/Globals.hpp>
#include <Common/ISynchronousTransactionWrapper.hpp>
#include <Common/Message.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \copydoc ISynchronousTransactionWrapper
        ///
        class NOS_ENGINE_COMMON_API_PUBLIC SynchronousTransactionWrapper :
            public ISynchronousTransactionWrapper
        {
        private:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            class SynchronousTransaction; //!< Internal synchronous transaction class.

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the SynchronousTransactionWrapper class.
            ///
            /// \note This wrapper will not add the internal transacation to a manager
            /// it is the responsibility of the user of this class to use the
            /// get_transaction method to directly or indirectly get the internal transaction
            /// added to the same manager that is provided to this constructor.
            ///
            /// \param manager the transaction manager that the internal transaction will be
            /// added to
            ///
            SynchronousTransactionWrapper(ITransactionManager &manager);

        private:
            SynchronousTransactionWrapper(const SynchronousTransactionWrapper &); //!< Disable the copy constructor.
            
        public:
            ///
            /// \brief Destructor for an instance of the SynchronousTransactionWrapper class.
            ///
            virtual ~SynchronousTransactionWrapper();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            SynchronousTransactionWrapper& operator=(const SynchronousTransactionWrapper &); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // ISynchronousTransactionWrapper implementation
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Wait for the response message from the transaction.
            ///
            /// This call blocks until the transaction has finished and returns the 
            /// response message.
            ///
            /// This method can't be called twice. The second call will cause an exception
            /// to be thrown.
            ///
            /// \param timeout timeout in milliseconds (SYNC_WAIT_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return the response message
            ///
            Message wait(size_t timeout = SYNC_WAIT_INFINITE_TIMEOUT);

            ///
            /// \brief Get the internal transaction.
            ///
            /// \note User should not delete the transaction using the returned pointer.
            /// The pointer should be passed to a transaction manager.
            /// The transaction manager or this wrapper will handling deleting
            /// the internal transaction.
            ///
            /// \return The internal transaction (null if called after a call to wait)
            ///
            ITransaction* get_transaction() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called when the internal transaction is aborted/canceled.
            ///
            /// \param transaction The internal transaction.
            /// \param lock A lock that has acquired a lock on the internal transactions
            /// mutex.
            ///
            void handle_aborted(SynchronousTransaction *transaction, std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Called when wait(size_t) hits the timeout.
            ///
            /// \param transaction The internal transaction.
            /// \param lock A lock that has acquired a lock on the internal transactions
            /// mutex.
            ///
            void handle_timeout(SynchronousTransaction *transaction, std::unique_lock<std::mutex> &lock);

            ///
            /// \brief Delete the internal transaction.
            ///
            /// \param transaction The internal transaction.
            /// \param lock A lock that has acquired a lock on the internal transactions
            /// mutex.
            ///
            void delete_transaction(SynchronousTransaction *transaction, std::unique_lock<std::mutex> &lock);

        protected:
            // ------------------------------------------------------------------------------------
            // ISynchronousTransactionWrapper (IEngineThreadSafeObject) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            SynchronousTransaction *transaction;
            ITransactionManager &manager;
            Message bounce_message;
		};
	}
}

#endif
