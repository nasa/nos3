/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_COMMON_ISEND_OPERATOR_HPP
#define NOS_ENGINE_COMMON_ISEND_OPERATOR_HPP

#include <Utility/States/IStoppable.hpp>

#include <Transport/Events/IOnDisconnected.hpp>

#include <Common/types.hpp>

namespace NosEngine
{
    namespace Common
    {
        ///
        /// \brief Provides message sending operations.
        ///
        /// This class provides two primary advantages compared to sending messages
        /// directly with the message connection:
        ///     1) Convenience method for assigning an appropriate Transaction ID
        ///     2) Non-blocking sends using a queue and background thread
        ///
        /// All send methods place the message on a queue for sending and return immediately.
        ///
        class ISendOperator :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Transport::Events::IOnDisconnected,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the SendOperator class.
            /// 
            virtual ~ISendOperator() {}

            ///
            /// \brief Get the ID of the transport which this send operator is using.
            ///
            /// \return The ID.
            ///
            virtual TransportID get_transport_id() const = 0;

            ///
            /// \brief Get the total number of send operations which have been initiated.
            ///
            /// \return The number of sends.
            ///
            virtual size_t get_send_count() const = 0;

            ///
            /// \brief Get the total number of send operations which have been completed.
            ///
            /// \return The number of sends completed.
            ///
            virtual size_t get_send_completed_count() const = 0;

            ///
            /// \brief Send a fully-formed Message.
            ///
            /// This method will not set a transaction ID, so it must already be set.
            ///
            /// \param message  message to send
            ///
            virtual void send_message(Message message) = 0;

            ///
            /// \brief Assign a transaction ID and send the message.
            ///
            /// A new transaction ID will be retrieved and set in the message before sending.
            ///
            /// \param message  message to send
            ///
            /// \return the transaction ID of the message
            ///
            virtual TransactionID send_message_with_id(Message message) = 0;

            ///
            /// \brief Add a new transaction and send the message.
            ///
            /// This method will get a new transaction ID and set it in the message.
            /// The transaction will be added to the manager with the same ID.
            ///
            /// \param message  message to send
            /// \param to_add   new transaction related to the message
            /// \param manager  the transaction manager
            ///
            /// \return the transaction ID of the message/transaction
            ///
            virtual TransactionID send_message(Message message, ITransaction* to_add, ITransactionManager& manager) = 0;

            ///
            /// \brief Process a transaction.
            ///
            /// This method will get a new transaction ID and set it in the message.
            /// The transaction will be added to the manager with the same ID.
            ///
            /// \param message      message to send
            /// \param to_process   transaction, related to the message, to process
            /// \param manager      the transaction manager
            ///
            /// \return the transaction ID of the message/transaction
            ///
            virtual TransactionID process_transaction(Message message, ITransaction* to_process, ITransactionManager& manager) = 0;
        };
    }
}

#endif