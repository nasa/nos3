/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_ITRANSPORT_REGISTRY_HPP
#define NOS_ENGINE_TRANSPORT_ITRANSPORT_REGISTRY_HPP

#include <Transport/Types.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a collection of transport registrations.
        ///
        class ITransportRegistry :
            public virtual Utility::IEngineThreadSafeObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ITransportRegistry class.
            /// 
            virtual ~ITransportRegistry() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Register a transport.
            ///
            /// \param scheme       The URI scheme of the transport registration.
            /// \param registration The transport registrations to add.
            ///
            /// \throw Utility::Error::AlreadyExists if the scheme is already registered.
            ///
            virtual void add(const std::string &scheme, ITransportRegistration &registration) = 0;

            ///
            /// \brief Unregister a transport.
            ///
            /// \param scheme The URI scheme of the transport registration to remove.
            ///
            /// \throw Utility::Error::NotFound if the registration is not found.
            ///
            virtual void remove(const std::string &scheme) = 0;

            ///
            /// \brief Get the transport registration for the specified URI scheme.
            ///
            /// \param scheme The URI scheme to use when searching for the registration.
            ///
            /// \return The transport registration which was found.
            ///
            /// \throw Utility::Error::NotFound if the registration is not found.
            ///
            virtual ITransportRegistration &get_registration(const std::string &scheme) const = 0;

            ///
            /// \brief Construct an Acceptor for the specified URI.
            ///
            /// \param uri      The local URI to create an Acceptor for.
            /// \param work_hub The work hub to pass to the Acceptor's constructor.
            ///
            /// \throw Utility::Error::NotFound if the registration is not found.
            ///
            virtual Acceptor *make_acceptor(const URI &uri, Utility::IWorkHub &work_hub) const = 0;

            ///
            /// \brief Construct an Connector for the specified URI.
            ///
            /// \param uri      The remote URI to create an Connector for.
            /// \param work_hub The work hub to pass to the Connector's constructor.
            ///
            /// \throw Utility::Error::NotFound if the registration is not found.
            ///
            virtual Connector *make_connector(const URI &uri, Utility::IWorkHub &work_hub) const = 0;
        };
    }
}

#endif