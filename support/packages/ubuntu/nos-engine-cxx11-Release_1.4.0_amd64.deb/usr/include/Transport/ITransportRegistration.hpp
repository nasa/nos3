/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
any warranty that the software will be error free.

In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
documentation or services provided hereunder.

ITC Team
NASA IV&V
ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_TRANSPORT_REGISTRATION_HPP
#define NOS_ENGINE_TRANSPORT_TRANSPORT_REGISTRATION_HPP

#include <Transport/Types.hpp>
#include <Transport/URI.hpp>
#include <Transport/URIPair.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \brief Represents a transport which is registered to a TransportRegistry.
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC ITransportRegistration :
            public virtual Utility::IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            virtual ~ITransportRegistration() {};

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Validate the URI.
            ///
            /// \param uri The URI to validate.
            ///
            virtual void validate_uri(const URI &uri) const = 0;

            ///
            /// \brief Validate the URI pair (local/remote URIs).
            ///
            /// \param uri The URI pair to validate.
            ///
            virtual void validate_uri_pair(const URIPair &uri_pair) const = 0;

            ///
            /// \brief Create an Acceptor instance for the specified URI.
            ///
            /// \param uri      The URI to create an Acceptor for (assumed to be valid for this
            ///                 registration).
            /// \param work_hub The Utility::IWorkHub to pass to the Acceptor when it is created.
            ///
            virtual Acceptor *create_acceptor(const URI &uri, Utility::IWorkHub &work_hub) const = 0;

            ///
            /// \brief Create a Connector instance for the specified URI.
            ///
            /// \param uri      The URI to create a Connector for (assumed to be valid for this
            ///                 registration).
            /// \param work_hub The Utility::IWorkHub to pass to the Connector when it is created.
            ///
            virtual Connector *create_connector(const URI &uri, Utility::IWorkHub &work_hub) const = 0;
        };
    }
}

#endif