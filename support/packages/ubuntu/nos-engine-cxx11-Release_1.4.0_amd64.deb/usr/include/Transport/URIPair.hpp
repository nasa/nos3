/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_URI_PAIR_HPP
#define NOS_ENGINE_TRANSPORT_URI_PAIR_HPP

#include <Transport/Types.hpp>
#include <Transport/IURIPair.hpp>

namespace NosEngine
{
    namespace Transport
    {
        ///
        /// \copydoc IURIPair
        ///
        class NOS_ENGINE_TRANSPORT_API_PUBLIC URIPair :
            public IURIPair
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Construct an instance of the URIPair class.
            /// 
            /// \param local Local URI.
            /// \param remote Remote URI.
            ///
            /// \throw Transport::Error::InvalidURIPair if URI pair validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// two URIs can't be found.
            /// 
            URIPair(const URI &local, const URI &remote);
            
            /// 
            /// \brief Construct an instance of the URIPair class.
            /// 
            /// \param local Local URI.
            /// \param remote Remote URI.
            /// \param registry Transporty registry to use for scheme lookup and URI validation.
            ///
            /// \throw Transport::Error::InvalidURIPair if URI pair validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// two URIs can't be found.
            /// 
            URIPair(const URI &local, const URI &remote, TransportRegistry &registry);
            
            /// 
            /// \brief Destructor for an instance of the URIPair class.
            /// 
            virtual ~URIPair();

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IURIPair implementation
            // ------------------------------------------------------------------------------------
            
            const URI &get_local_uri() const;

            const URI &get_remote_uri() const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Validate this URIPair using the provided transport registry.
            /// 
            /// \param registry Transporty registry to use for scheme lookup and URI validation.
            ///
            /// \throw Transport::Error::InvalidURIPair if URI pair validation fails.
            /// \throw Utility::Error::NotFound if a transport registration for the scheme of the
            /// two URIs can't be found.
            ///
            void validate(TransportRegistry &registry);

            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            URI local;  //!< Local URI.
            URI remote; //!< Remote URI.
        };
    }
}

#endif