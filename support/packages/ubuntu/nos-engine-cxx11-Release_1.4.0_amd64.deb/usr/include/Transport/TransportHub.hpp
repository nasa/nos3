/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_TRANSPORT_TRANSPORT_HUB_HPP
#define NOS_ENGINE_TRANSPORT_TRANSPORT_HUB_HPP

#include <string>

#include <vector>

#include <Utility/Queue.hpp>
#include <Utility/WorkHub.hpp>

#include <Transport/Types.hpp>
#include <Transport/Globals.hpp>
#include <Transport/Acceptor.hpp>
#include <Transport/Connector.hpp>
#include <Transport/Connection.hpp>
#include <Transport/TransportRegistry.hpp>
#include <Transport/ITransportHub.hpp>

namespace NosEngine {
namespace Transport {
    
///
/// \copydoc ITransportHub
///
class NOS_ENGINE_TRANSPORT_API_PUBLIC TransportHub :
    public ITransportHub,
    public Utility::States::Stoppable {
protected:
    // ============================================================================================
    // Types
    // --------------------------------------------------------------------------------------------

    typedef std::map<std::string, Acceptor *> UriToAcceptorMap;
    typedef std::map<std::string, Connector *> UriToConnectorMap;
    typedef std::map<std::string, ConnectionVector> UriToConnectionsMap;

public:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Construct and instance of the TransportHub class.
    /// 
    /// \param num_service_threads The number of service threads which the underlying
    /// Utility::IWorkHub should create.
    /// 
    TransportHub(const size_t num_service_threads = TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

    /// 
    /// \brief Construct and instance of the TransportHub class.
    /// 
    /// \param num_service_threads  The number of service threads which the underlying
    ///                             Utility::WorkHub should create.
    /// \param listen_uri_vec       A collection of URI to perform a listen opertion on.
    /// \param callback             Callback for async listen operations.
    ///
    TransportHub(const size_t num_service_threads, const std::vector<std::string> listen_uri_vec, ListenCallback callback);

    /// 
    /// \brief Construct and instance of the TransportHub class.
    ///
    /// The TransportHub does NOT take ownership of the provided work hub.
    /// 
    /// \param work_hub An existing Utility::IWorkHub to use.
    ///
    TransportHub(Utility::IWorkHub &work_hub);

    /// 
    /// \brief Construct and instance of the TransportHub class.
    ///
    /// The TransportHub does NOT take ownership of the provided work hub.
    /// 
    /// \param work_hub         An existing Utility::IWorkHub to use.
    /// \param listen_uri_vec   A collection of URI to perform a listen opertion on.
    /// \param callback         Callback for async listen operations.
    ///
    TransportHub(Utility::IWorkHub &work_hub, const std::vector<std::string> listen_uri_vec, ListenCallback callback);

private:
    TransportHub(const TransportHub &); //!< Disable the copy constructor.

public:
    virtual ~TransportHub();

private:
    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    TransportHub& operator=(const TransportHub&); //!< Disable the copy assignment operator.

public:
    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // ITransportHub implementation
    // --------------------------------------------------------------------------------------------

    virtual Connection *listen_blocking(const std::string &local_uri);

    virtual void listen_async(const std::string &local_uri, ListenCallback callback);

    virtual Connection *connect_blocking(
        const std::string &remote_uri,
        const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
        const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
        const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS);

    virtual void connect_async(
        const std::string &remote_uri,
        ConnectCallback callback,
        const size_t retries = DEFAULT_CONNECT_RETRY_COUNT,
        const size_t retry_delay = DEFAULT_CONNECT_RETRY_DELAY_MS,
        const size_t attempt_timeout = DEFAULT_CONNECT_ATTEMPT_TIMEOUT_MS);

    virtual Utility::IWorkHub &get_work_hub();
    
    virtual Acceptor *get_acceptor(const std::string &local_uri);

    virtual AcceptorVector get_acceptors();

    virtual Connector *get_connector(const std::string &remote_uri);

    virtual ConnectorVector get_connectors();

    virtual ConnectionVector get_server_connections();

    virtual ConnectionVector get_server_connections(const std::string &local_uri);

    virtual ConnectionVector get_client_connections();

    virtual ConnectionVector get_client_connections(const std::string &remote_uri);

private:
    // ============================================================================================
    // Internal API
    // --------------------------------------------------------------------------------------------

    /// 
    /// \brief Work hub init method called by constructors.
    ///
    void setup_work_hub(const size_t &num_service_threads = 0);

    /// 
    /// \brief Get the existing Acceptor that is used to listen on the specified URI.
    ///
    /// If the Acceptor doesn't currently exist it is created.
    ///
    /// \param local_uri The local URI of an existing Acceptor.
    ///
    /// \return The Acceptor for the URI.
    ///
    Acceptor *get_or_add_acceptor(const std::string &local_uri);

    ///
    /// \brief Get the existing Connector that is used to connect on the specified URI.
    ///
    /// If the Connector doesn't currently exist it is created.
    ///
    /// \param remote_uri The remove URI of an existing Connector.
    ///
    /// \return The Connector for the URI.
    ///
    Connector *get_or_add_connector(const std::string &remote_uri);

    /// 
    /// \brief Called when an Acceptor that was created via the TransportHub is destroyed.
    /// 
    /// \param acceptor The Acceptor being destroyed.
    ///
    void on_acceptor_destroyed(Acceptor *acceptor);

    /// 
    /// \brief Called when a Connector that was created via the TransportHub is destroyed.
    /// 
    /// \param acceptor The Connector being destroyed.
    ///
    void on_connector_destroyed(Connector *connector);

    /// 
    /// \brief Called when a Connection that was created via the TransportHub is destroyed.
    /// 
    /// \param acceptor The Connection being destroyed.
    ///
    void on_connection_destroyed(Connection *connection);

    /// 
    /// \brief Remove the Acceptor from the TransportHub's collection(s).
    /// 
    /// \param acceptor The Acceptor being destroyed.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void remove_acceptor(Acceptor *acceptor, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Remove the Connector from the TransportHub's collection(s).
    /// 
    /// \param acceptor The Connector being destroyed.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void remove_connector(Connector *connector, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Remove the Connection from the TransportHub's collection(s).
    /// 
    /// \param acceptor The Connection being destroyed.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void remove_connection(Connection *connection, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Stop the Acceptor if it was created by this TransportHub.
    /// 
    /// \param acceptor The Acceptor to stop.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void stop_acceptor(std::string &local_uri, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Stop the Connector if it was created by this TransportHub.
    /// 
    /// \param acceptor The Connector to stop.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void stop_connector(std::string &remote_uri, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Stop the Connection if it was created by this TransportHub.
    /// 
    /// \param acceptor The Connection to stop.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void stop_connection(Connection *connection, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Stop all server Connection(s) created by this TransportHub for the specified URI.
    /// 
    /// \param local_uri The local URI to filter server connections by.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void stop_server_connections(std::string &local_uri, std::unique_lock<std::mutex> &lock);

    /// 
    /// \brief Stop all client Connection(s) created by this TransportHub for the specified URI.
    /// 
    /// \param remote_uri The remote URI to filter client connections by.
    /// \param lock A lock that has acquired a lock of get_mutex().
    ///
    void stop_client_connections(std::string &remote_uri, std::unique_lock<std::mutex> &lock);

protected:
    // --------------------------------------------------------------------------------------------
    // ITransportHub (IEngineThreadSafeObjectWithCV) implementation
    // --------------------------------------------------------------------------------------------

    virtual std::mutex &get_mutex() const;

    virtual std::condition_variable &get_cv() const;

    // --------------------------------------------------------------------------------------------
    // Stoppable implementation
    // --------------------------------------------------------------------------------------------

    virtual bool is_stopping_no_lock() const;

    virtual void set_stopping_no_lock(const bool &stopping);

    virtual bool is_stopped_no_lock() const;

    virtual void set_stopped_no_lock(const bool &stopped);

    virtual void process_stop(std::unique_lock<std::mutex> &lock);

private:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    // ---- configuration ----
    bool owns_hub;

    // ---- threading ----
    Utility::IWorkHub *work_hub;

    // ---- thread syncronization ----
    mutable std::mutex mutex;
    mutable std::condition_variable cond;

    // ---- collections ----
    UriToAcceptorMap acceptor_map;              //!< Maps local URIs to Acceptor(s)
    UriToConnectorMap connector_map;            //!< Maps remote URIs to Connector(s)
    UriToConnectionsMap server_connection_map;  //!< Maps local URIs to Connection(s) (ie server connections created via listen)
    UriToConnectionsMap client_connection_map;  //!< Maps remote URIs to Connection(s) (ie client connections created via connect)

    // ---- status ----
    bool stopping;                              //!< Indicates if the TransportHub is stopping.
    bool stopped;                               //!< Indicates if the TransportHub is stopped.
};

}}

#endif

