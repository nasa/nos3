/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UART_UART
#define NOS_ENGINE_UART_UART

#include <Uart/visibility.hpp>

#include <Client/Bus.hpp>
#include <Transport/TransportHub.hpp>

#include <functional>
#include <string>
#include <vector>
#include <cstdint>
#include <mutex>

namespace NosEngine
{
    namespace Common
    {
        class Message;
    }

    namespace Client
    {
        class DataNode;
    }

    namespace Uart
    {
        /*
         * \brief Default data queue size in bytes
         */
        const unsigned int DEFAULT_DATA_QUEUE_SIZE = 1024;

        /*
         * \brief UART data callback
         */
        typedef std::function<void(const uint8_t *buf, size_t len, void *user)> DataCallback;

        /*
         * \brief Client side UART
         */
        class NOS_ENGINE_UART_API_PUBLIC Uart
        {
        public:
            /*
             * \brief Attempt to create a UART on the named bus
             *
             * \note Device names must be unique on the same UART bus
             *
             * \param name Device name
             * \param connection NOS connection string
             * \param bus UART bus name
             * \param num_service_threads The number of service threads that should be created
             */
            Uart(
                const std::string& name,
                const std::string& connection,
                const std::string& bus = "uart",
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);
            
            /*
             * \brief Attempt to create a UART on the named bus
             *
             * \note Device names must be unique on the same UART bus
             *
             * \param transport_hub Existing transport hub to use
             * \param name Device name
             * \param connection NOS connection string
             * \param bus UART bus name
             */
            Uart(
                Transport::TransportHub &transport_hub,
                const std::string& name,
                const std::string& connection,
                const std::string& bus = "uart");

            /*
             * \brief Destructor
             */
            ~Uart();

            /**
             * \brief Get the transport hub used by this instance.
             * 
             * If the instance owns the hub (ie hub was not provided to the constructor) then use
             * the hub returned with caution.  When this instance is destroyed the hub it owns
             * will be destroyed as well.
             * 
             * \return The tranport hub of this instance.
             */
            Transport::TransportHub &get_transport_hub() const;

            /*
             * \brief Open UART port
             *
             * \param port UART port
             *
             * \return True on success
             */
            bool open(uint8_t port);

            /*
             * \brief Close UART port
             *
             * \return True on success
             */
            bool close();

            /*
             * \brief Set new message received callback
             *
             * \param cb Callback function
             * \param user User data
             */
            void set_read_callback(DataCallback cb, void *user = nullptr);

            /*
             * \brief Read data from the UART port
             *
             * Read is non-blocking. The number of bytes returned will be less than requested if the data queue
             * does not contain enough data.
             *
             * \param buf Buffer to read data into
             * \param len Number of bytes to read
             *
             * \return Number of bytes read
             */
            size_t read(uint8_t *buf, size_t len);

            /*
             * \brief Read character from the UART port
             *
             * Read is blocking. If data is not available in the data queue, this function will return false.
             *
             * \param c Character to store read data
             *
             * \return True on success, false otherwise
             */
            bool getc(uint8_t *c);

            /*
             * \brief Write data to the UART port
             *
             * \param buf Data buffer to write
             * \param len Number of bytes to write
             *
             * \return Number of bytes written
             */
            size_t write(const uint8_t *const buf, size_t len);

            /*
             * \brief Write character to the UART port
             *
             * \param c Character to transmit
             */
            void putc(uint8_t c);

            /*
             * \brief Get number of bytes available in data queue
             *
             * \return Number of bytes available in data queue
             */
            size_t available() const;

            /*
             * \brief Flush data queue
             */
            void flush();

            /*
             * \brief Set maximum data queue size
             *
             * \param queue_size Maximim data queue size in bytes
             */
            void set_queue_size(unsigned int queue_size);

        private:
            void init(const std::string &name);

            /*
             * \brief On new message callback
             *
             * \param message New received message
             */
            void on_message(const Common::Message& message);

        private:
            Client::Bus bus; //!< NOS engine UART bus
            Client::DataNode *node; //!< UART data node

            int port; //!< Open UART port (negative value indicates no open port)
            DataCallback callback; //!< New message received callback
            void *user_data; //!< Callback user data

            typedef std::vector<uint8_t> DataQueue;
            unsigned int qsize; //!< Data queue size in bytes
            DataQueue dataq; //!< Data queue
            mutable std::mutex dataq_mutex; //!< Data queue mutex
        };
    }
}

#endif

