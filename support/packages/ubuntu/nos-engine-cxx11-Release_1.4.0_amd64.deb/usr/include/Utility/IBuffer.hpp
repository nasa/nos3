/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IBUFFER_HPP
#define NOS_ENGINE_UTILITY_IBUFFER_HPP

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief A generic buffer implementation.
        ///
        /// A buffer class that can dynamically grow as needed.
        /// This class is NOT thread-safe.
        ///
        class IBuffer : public virtual IEngineObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IBuffer class.
            /// 
            virtual ~IBuffer() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Compare to another buffer to see if data is the same.
            /// 
            /// Compares the data of another buffer to see if they match.
            /// The size (i.e. capacity) may be different but the filled data must be the same.
            /// 
            /// \param other Reference to Buffer to compare
            /// 
            /// \return false if the data is not equal (different sizes or different values)
            /// \return true if the data is of the same length and values
            /// 
            virtual bool operator==(const IBuffer &other) const = 0;

            ///
            /// \brief The not-equals version of the comparison operator; see operator==(const Buffer &other) const
            /// 
            virtual bool operator!=(const IBuffer &other) const = 0;

            ///
            /// \brief Reset the contents of the buffer.
            /// 
            /// This resets the contents of the buffer - the capacity remains the same.
            /// 
            virtual void reset() = 0;

            ///
            /// \brief Clear the buffer.
            /// 
            /// \param free If true will free the memory in the buffer, otherwise the buffer pointer is set to null.
            /// 
            virtual void clear(const bool &free = true) = 0;

            ///
            /// \brief Get the current capacity of the buffer.
            /// 
            /// \return The current capcity of the buffer.
            /// 
            virtual size_t get_size() const = 0;

            ///
            /// \brief Get the number of characters currently filled in the buffer.
            /// 
            /// \return The number of characters currently filled in the buffer.
            /// 
            virtual size_t get_length() const = 0;

            ///
            /// \brief Get the pointer to the raw data.
            /// 
            /// \note USE WITH CAUTION !!
            /// 
            /// \return The pointer to the raw data.
            /// 
            virtual char *get_data() const = 0;

            ///
            /// \brief Add data to the end of the buffer.
            /// 
            /// \param add_len  length of new data
            /// \param add_data pointer to new data
            /// 
            /// \throw Error::BufferOverflow    data is too large for capacity
            /// \throw Error::InvalidArgument   add_data is null
            /// 
            virtual void add(size_t add_len, const char *add_data) = 0;

            ///
            /// \brief Resize the buffer while retaining the existing data.
            /// 
            /// \param new_size new size desired for buffer.
            /// 
            /// \throw Error::InvalidArgument   new_size is less than length of existing data
            /// \throw std::bad_alloc           new failed
            /// 
            virtual void set_size(size_t new_size) = 0;

            ///
            /// \brief Increase the capacity of the buffer while retaining existing data.
            /// 
            /// \param grow_size size additional capacity desired
            /// 
            /// \throw std::bad_alloc new failed
            /// 
            virtual void grow(size_t grow_size) = 0;

            ///
            /// \brief Append data to the end of the buffer and increase buffer as needed.
            /// 
            /// \param append_len   length of new data
            /// \param append_data  pointer to new data
            /// \param grow_size    If buffer is too small, specifies size to increase buffer. Pass 0 to grow by minimum needed.
            /// 
            /// \throw Error::InvalidArgument   append_data is null
            /// \throw Error::BufferOverflow    grow_size is less than required to append new data
            /// \throw std::bad_alloc           new failed
            /// 
            virtual void append(size_t append_len, const char *append_data, size_t grow_size = 0) = 0;

            ///
            /// \brief Append data at a specific offset and increase buffer as needed.
            /// 
            /// \param offset       offset to write new data
            /// \param append_len   length of new data
            /// \param append_data  pointer to new data
            /// \param grow_size    If buffer is too small, specifies size to increase buffer. Pass 0 to grow by minimum needed.
            /// 
            /// \throw Error::InvalidArgument   append_data is null
            /// \throw Error::BufferOverflow    grow_size is less than required to append new data
            /// \throw std::bad_alloc           new failed
            /// 
            virtual void append(size_t offset, size_t append_len, const char *append_data, size_t grow_size = 0) = 0;

            ///
            /// \brief Get the buffer contents as a string.
            ///
            /// \param offset Offset into the buffer at which to begin the string
            ///
            virtual const std::string to_string(size_t offset = 0) const = 0;

            ///
            /// \brief Writes formatted data to the buffer.
            /// 
            /// Writes formatted data using a printf-style format string to the BEGINNING of the buffer.
            /// 
            /// \param fmt  printf-style format string
            /// \param ap   Additional arguments for format specifiers (if present in format string)
            /// 
            /// \throw Error::BufferOverflow formatted data is too large for capacity
            /// 
            NE_FORMAT_GUARD(2, 0)
            virtual void vprintf(const char *fmt, va_list ap) = 0;

            ///
            /// \brief Writes formatted data to the buffer.
            /// 
            /// Writes formatted data using a printf-style format string to the BEGINNING of the buffer.
            /// 
            /// \param fmt  printf-style format string
            /// \param ...  Additional arguments for format specifiers (if present in format string)
            /// 
            /// \throw Error::BufferOverflow formatted data is too large for capacity
            /// 
            NE_FORMAT_GUARD(2,3)
            virtual void printf(const char *fmt, ...) = 0;

            // TODO
            //NE_FORMAT_GUARD(2, 3)
            //virtual void printf_append(const char *fmt, ...) = 0;
        };
    }
}

#endif