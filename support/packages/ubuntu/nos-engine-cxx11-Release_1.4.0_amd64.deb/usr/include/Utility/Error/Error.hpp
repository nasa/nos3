/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_ERROR_HPP
#define NOS_ENGINE_UTILITY_ERROR_ERROR_HPP

#include <cstdarg>
#include <stdexcept>
#include <cstdint>
#include <string>

#include <Utility/Types.hpp>
#include <Utility/Error/Base/ErrorBase.hpp>

#ifdef WIN32
#define __NE_ERR_FUNCTION__ __FUNCSIG__
#else
#ifdef __GNUC__
#define __NE_ERR_FUNCTION__ __PRETTY_FUNCTION__
#else
#define __NE_ERR_FUNCTION__ __FUNCTION__
#endif
#endif

// Macros for appending to an error's backtrace when creating/declaring/throwing/rethrowing the error
#define NE_ERROR_CREATE(TYPE, ...) TYPE(__VA_ARGS__).trace_append(__FILE__, __NE_ERR_FUNCTION__, __LINE__)
#define NE_ERROR_CREATE0(TYPE) TYPE().trace_append(__FILE__, __NE_ERR_FUNCTION__, __LINE__)
#define NE_ERROR_DECLARE(NAME, TYPE, ...) TYPE NAME(__VA_ARGS__); NAME.trace_append(__FILE__, __NE_ERR_FUNCTION__, __LINE__)
#define NE_ERROR_DECLARE0(NAME, TYPE) TYPE NAME; NAME.trace_append(__FILE__, __NE_ERR_FUNCTION__, __LINE__)
#define NE_ERROR_THROW(TYPE, ...) throw NE_ERROR_CREATE(TYPE, __VA_ARGS__).throw_error()
#define NE_ERROR_THROW0(TYPE) throw NE_ERROR_CREATE0(TYPE).throw_error()
#define NE_ERROR_RETHROW(ERROR) throw NE_ERROR_TRACE_APPEND(ERROR).throw_error()

// Macro for appending to an error's backtrace
#define NE_ERROR_TRACE_APPEND(ERROR) ERROR.trace_append(__FILE__, __NE_ERR_FUNCTION__, __LINE__)

// Macros for appending to an error's backtrace and then logging the error when
// the error is thrown by a line or block of code
#define NE_ERROR_LOG_ON_CATCH(LOGGER)\
    catch (::NosEngine::Utility::Error::Error &e) { LOGGER << NE_ERROR_TRACE_APPEND(e) << std::endl; }\
    catch (std::exception &e) { LOGGER << NE_ERROR_CREATE(::NosEngine::Utility::Error::Error, e) << std::endl; }\
    catch (...) { LOGGER << NE_ERROR_CREATE(::NosEngine::Utility::Error::Error, "unknown exception") << std::endl; }
#define NE_ERROR_LOG_ON_THROW(STATEMENT, LOGGER) try { STATEMENT; } NE_ERROR_LOG_ON_CATCH(LOGGER)

// Macros for appending to an error's backtrace and then rethrowing the error when
// the error is thrown by a line or block of code
#define NE_ERROR_RETHROW_ON_CATCH()\
    catch (::NosEngine::Utility::Error::Error &e) { NE_ERROR_RETHROW(e); }\
    catch (std::exception &e) { NE_ERROR_THROW(::NosEngine::Utility::Error::Error, e); }\
    catch (...) { NE_ERROR_THROW(::NosEngine::Utility::Error::Error, "unknown exception"); }
#define NE_ERROR_RETHROW_ON_THROW(STATEMENT) try { STATEMENT; } NE_ERROR_RETHROW_ON_CATCH()

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            ///
            /// \brief Global equality operator for comparing to Error objects.
            ///
            NOS_ENGINE_UTILITY_API_PUBLIC bool operator==(const Error &lhs, const Error &rhs);

            ///
            /// \brief Global in-equality operator for comparing to Error objects.
            ///
            NOS_ENGINE_UTILITY_API_PUBLIC bool operator!=(const Error &lhs, const Error &rhs);

            ///
            /// \brief Global insertion operator for Error objects.
            ///
            NOS_ENGINE_UTILITY_API_PUBLIC std::ostream &operator<<(std::ostream &os, const Error &error);

            /// 
            /// \brief NOS Engine general error.
            /// 
            class NOS_ENGINE_UTILITY_API_PUBLIC Error : public Base::ErrorBase<Error, Base::IErrorBase>, public std::exception
            {
            public:
                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                Error();

                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param message An error message describing the error.
                /// 
                Error(const std::string &message);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param fmt A printf style format string.
                /// 
                NE_FORMAT_GUARD(2,3)
                Error(const char *fmt, ...);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param fmt A printf style format string.
                /// \param ap va_list for printf style format string.
                /// 
                Error(const char *fmt, std::va_list &ap);

                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param error_code An error code associated with the this error.
                /// 
                Error(const ErrorCode &error_code);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param error_code An error code associated with the this error.
                /// \param message An error message describing the error.
                /// 
                Error(const ErrorCode &error_code, const std::string &message);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param error_code An error code associated with the this error.
                /// \param fmt A printf style format string.
                /// 
                NE_FORMAT_GUARD(3,4)
                Error(const ErrorCode &error_code, const char *fmt, ...);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param error_code An error code associated with the this error.
                /// \param fmt A printf style format string.
                /// \param ap va_list for printf style format string.
                /// 
                Error(const ErrorCode &error_code, const char *fmt, std::va_list &ap);
                
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param exception Exception to convert to an error.
                /// 
                Error(const std::exception &exception);

            protected:
                /// 
                /// \brief Construct an instance of the Error class.
                /// 
                /// \param impl Underlying error implementation to use.
                /// 
                Error(Implementation::IErrorImpl *impl);
                
            public:
                /// 
                /// \brief Copy constructor.
                /// 
                Error(const Error &other);
                
                /// 
                /// \brief Move constructor.
                /// 
                Error(Error &&other);
                
                /// 
                /// \brief Destructor for an instance of the Error class.
                /// 
                virtual ~Error();

                // ============================================================================
                // Operators
                // ----------------------------------------------------------------------------
                
                /// 
                /// \brief Copy operator.
                /// 
                Error &operator=(const Error &other);
                
                /// 
                /// \brief Move operator.
                /// 
                Error &operator=(Error &&other);

                /// 
                /// \brief Boolean operator overload.
                /// 
                /// \return A value indicating if the error object represents an error or not.
                /// 
                operator bool() const;

                // ============================================================================
                // Public API
                // ----------------------------------------------------------------------------
                
                /// 
                /// \brief Compare two error objects to determine if they are equal.
                /// 
                /// \return True if the error objects are equal.
                /// 
                static bool is_equal(const Error &error1, const Error &error2);
                
                /// 
                /// \brief Get error code which is associated with this error.
                /// 
                /// \return The error code.
                /// 
                ErrorCode get_error_code() const;
                
                /// 
                /// \brief Get the error message describing the error.
                /// 
                /// \return The error message describing the error.
                /// 
                std::string get_message() const;
                
                /// 
                /// \brief Get the error message combine with the backtrace.
                /// 
                /// \param multiline True to generate a multiline backtrace (defaults to single line).
                /// 
                /// \return The error message and backtrace.
                /// 
                std::string get_message_and_trace(const bool &multiline = false) const;
                
                /// 
                /// \brief Get NOS generated partial backtrace string.
                /// 
                /// \param multiline True to generate a multiline backtrace (defaults to single line).
                /// 
                /// \return The partial backtrace.
                /// 
                const std::string get_trace(const bool &multiline = false) const;
                
                /// 
                /// \brief Append an entry into the backtrace for this error.
                /// 
                /// \param file Source file name.
                /// \param function Name of function or class method in the source file.
                /// \param line Source file line number.
                /// 
                /// \return A reference to this error.
                /// 
                Error &trace_append(const std::string &file, const std::string &function, const uint32_t &line);

                /// 
                /// \brief Implementation of std::exception what method.
                /// 
                /// \return The error message describing the exception.
                /// 
                const char *what() const throw();
                
                /// 
                /// \brief Throw an error that correctly represents the underlying error implementation.
                /// 
                /// Using this should be favored over throwing the error directly.
                /// 
                const Error &throw_error() const;
            };

            ///
            /// \brief Global equality operator for comparing an Error to a Base::ErrorType.
            ///
            /// \return true if the underlying error type of the Error object IS equal to
            /// to error type to the RIGHT of the operator.
            ///
            template<typename TYPE_ENUM_T>
            typename std::enable_if<std::is_enum<TYPE_ENUM_T>::value, bool>::type
            operator==(const Error &lhs, const TYPE_ENUM_T &rhs)
            {
                return lhs.get_type() == rhs;
            }

            ///
            /// \brief Global in-equality operator for comparing an Error to a Base::ErrorType.
            ///
            /// \return true if the underlying error type of the Error object IS NOT equal to
            /// to error type to the RIGHT of the operator.
            ///
            template<typename TYPE_ENUM_T>
            typename std::enable_if<std::is_enum<TYPE_ENUM_T>::value, bool>::type
            operator!=(const Error &lhs, const TYPE_ENUM_T &rhs)
            {
                return lhs.get_type() != rhs;
            }

            ///
            /// \brief Global equality operator for comparing an Error to a Base::ErrorType.
            ///
            /// \return true if the underlying error type of the Error object IS equal to
            /// to error type to the LEFT of the operator.
            ///
            template<typename TYPE_ENUM_T>
            typename std::enable_if<std::is_enum<TYPE_ENUM_T>::value, bool>::type
            operator==(const TYPE_ENUM_T &lhs, const Error &rhs)
            {
                return lhs == rhs.get_type();
            }

            ///
            /// \brief Global in-equality operator for comparing an Error to a Base::ErrorType.
            ///
            /// \return true if the underlying error type of the Error object IS NOT equal to
            /// to error type to the LEFT of the operator.
            ///
            template<typename TYPE_ENUM_T>
            typename std::enable_if<std::is_enum<TYPE_ENUM_T>::value, bool>::type
            operator!=(const TYPE_ENUM_T &lhs, const Error &rhs)
            {
                return lhs != rhs.get_type();
            }
        }
    }
}

#endif