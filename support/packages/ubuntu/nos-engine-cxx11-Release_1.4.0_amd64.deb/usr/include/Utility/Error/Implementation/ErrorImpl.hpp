/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_ERROR_IMPL_HPP
#define NOS_ENGINE_UTILITY_ERROR_ERROR_IMPL_HPP

#include <sstream>
#include <string>

#include <Utility/Types.hpp>
#include <Utility/Error/Implementation/IErrorImpl.hpp>
#include <Utility/Error/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Error
        {
            namespace Implementation
            {
                /// 
                /// \brief Represents the underlying error implementation of an error object.
                /// 
                /// All error implementation classes need to derive directly from this class.
                /// This class uses the curiously recurring template pattern (CRTP).
                /// 
                /// \param IMPL_C CRTP class.
                /// \param DETAILS_C Error details class.
                /// \param ERROR_C Error class which the error implementation is for.
                /// \param TYPE_ENUM_T Error type enum type.
                /// \param IMPL_IFACE_C Error implementation interface class.
                /// 
                template<class IMPL_C, class DETAILS_C = Detail::ErrorDetails, class ERROR_C = Error, typename TYPE_ENUM_T = Type, class IMPL_IFACE_C = IErrorImpl>
                class ErrorImpl : public IMPL_IFACE_C
                {
                private:
                    // ============================================================================
                    // Types
                    // ----------------------------------------------------------------------------

                    class ThisErrorType : public Base::ErrorType<TYPE_ENUM_T>
                    {
                    public:
                        // ========================================================================
                        // Life cycle
                        // ------------------------------------------------------------------------

                        /// 
                        /// \brief Construct an instance of the ThisErrorType class.
                        /// 
                        /// \param type Error type enum value.
                        /// 
                        ThisErrorType(const TYPE_ENUM_T &type);
                    };

                public:
                    // ============================================================================
                    // Life cycle
                    // ----------------------------------------------------------------------------

                    /// 
                    /// \brief Construct an instance of the ErrorImpl class.
                    /// 
                    /// \param details Error details.
                    /// 
                    ErrorImpl(DETAILS_C &&details);

                    /// 
                    /// \brief Construct an instance of the ErrorImpl class.
                    /// 
                    /// \param details Error details.
                    /// \param type Error type.
                    /// 
                    ErrorImpl(DETAILS_C &&details, const TYPE_ENUM_T &type);

                    /// 
                    /// \brief Destructor for an instance of the ErrorImpl class.
                    /// 
                    virtual ~ErrorImpl();

                    // ============================================================================
                    // Operators
                    // ----------------------------------------------------------------------------

                    // ----------------------------------------------------------------------------
                    // IErrorImpl implementation
                    // ----------------------------------------------------------------------------

                    virtual bool operator==(const IErrorImpl &other) const;

                    virtual bool operator!=(const IErrorImpl &other) const;

                    virtual operator bool() const;

                    // ============================================================================
                    // Public API
                    // ----------------------------------------------------------------------------

                    // ----------------------------------------------------------------------------
                    // IErrorImpl implementation
                    // ----------------------------------------------------------------------------

                    virtual const Base::IErrorType &get_type() const;

                    virtual const Detail::IErrorDetails &get_details() const;

                    virtual const ErrorCode &get_error_code() const;

                    virtual const std::string &get_message() const;

                    virtual const std::string get_trace(const bool &multiline = false) const;

                    virtual std::string get_message_and_trace(const bool &multiline = false) const;

                    virtual void trace_append(const std::string &file, const std::string &function, const uint32_t &line);

                    virtual void throw_error() const;

                    virtual IErrorImpl *clone() const;

                protected:
                    // ============================================================================
                    // Data members
                    // ----------------------------------------------------------------------------

                    DETAILS_C details;  //!< Details about the error
                    ThisErrorType type; //!< The type of error
                };
            }
        }
    }
}

#include <Utility/Error/Implementation/ErrorImpl.ipp>

#endif