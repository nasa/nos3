/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_EVENTS_ON_STOPPED_HPP
#define NOS_ENGINE_UTILITY_EVENTS_ON_STOPPED_HPP

#include <Utility/Events/IOnStopped.hpp>
#include <Utility/CallbackList.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Events
        {
            /// 
            /// \copydoc IOnStopped
            /// 
            template<class C>
            class OnStopped : public virtual IOnStopped
            {
            public:
                // ================================================================================
                // Types
                // --------------------------------------------------------------------------------

                typedef CallbackList<C> OnStoppedCallbackList;

                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the OnStopped class.
                /// 
                virtual ~OnStopped() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                // --------------------------------------------------------------------------------
                // IOnStopped implementation
                // --------------------------------------------------------------------------------

                virtual CallbackId add_on_stopped_callback(OnStoppedCallback callback, const bool &removable = true);

                virtual void remove_on_stopped_callback(const CallbackId &id);

                // ================================================================================
                // Data members
                // --------------------------------------------------------------------------------

                OnStoppedCallbackList on_stopped; //!< List of on stopped callbacks.
            };
        }
    }
}

#include <Utility/Events/OnStopped.ipp>

#endif // NOS_ENGINE_UTILITY_EVENTS_ON_STOPPED_HPP