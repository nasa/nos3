/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_EVENTS_ION_CANCELED_HPP
#define NOS_ENGINE_UTILITY_EVENTS_ION_CANCELED_HPP

#include <functional>
#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        namespace Events
        {
            ///
            /// \brief Represents a class that has a list of on canceled callbacks which are
            /// executed when the class finishes a cancel operation.
            ///
            class IOnCanceled
            {
            public:
                // ================================================================================
                // Types
                // --------------------------------------------------------------------------------

                typedef std::function<void()> OnCanceledCallback;

                // ================================================================================
                // Life cycle
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Destructor for an instance of the IOnCanceled class.
                /// 
                virtual ~IOnCanceled() {}

                // ================================================================================
                // Public API
                // --------------------------------------------------------------------------------

                /// 
                /// \brief Add an on canceled callback.
                /// 
                /// \param callback The callback to add.
                /// \param removeable A value indicating if the callback can be removed from the list
                /// by calls to remove_on_canceled_callback(CallbackId).
                /// 
                /// \return The id of the callback.
                /// 
                virtual CallbackId add_on_canceled_callback(OnCanceledCallback callback, const bool &removable = true) = 0;

                /// 
                /// \brief Remove an on canceled callback.
                /// 
                /// \param id The id of the callback to remove.
                ///
                virtual void remove_on_canceled_callback(const CallbackId &id) = 0;
            };
        }
    }
}

#endif // NOS_ENGINE_UTILITY_EVENTS_ION_CANCELED_HPP