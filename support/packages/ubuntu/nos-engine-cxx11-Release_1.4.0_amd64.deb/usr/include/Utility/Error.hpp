/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_ERROR_HPP
#define NOS_ENGINE_UTILITY_ERROR_HPP

#include <Utility/Error/Types.hpp>
#include <Utility/Error/AlreadyCompleted.hpp>
#include <Utility/Error/AlreadyExists.hpp>
#include <Utility/Error/BufferOverflow.hpp>
#include <Utility/Error/BufferUnderflow.hpp>
#include <Utility/Error/BusyError.hpp>
#include <Utility/Error/CallbackRemovalFailed.hpp>
#include <Utility/Error/CollectionEmpty.hpp>
#include <Utility/Error/ConversionFailed.hpp>
#include <Utility/Error/Error.hpp>
#include <Utility/Error/FileNotFound.hpp>
#include <Utility/Error/FinalizationFailed.hpp>
#include <Utility/Error/FormatStringFailed.hpp>
#include <Utility/Error/InitializationFailed.hpp>
#include <Utility/Error/InvalidArgument.hpp>
#include <Utility/Error/InvalidOrder.hpp>
#include <Utility/Error/InvalidServiceThread.hpp>
#include <Utility/Error/InvalidValue.hpp>
#include <Utility/Error/NotEnabled.hpp>
#include <Utility/Error/NotFound.hpp>
#include <Utility/Error/NotImplemented.hpp>
#include <Utility/Error/NullArgumentError.hpp>
#include <Utility/Error/NullPointerError.hpp>
#include <Utility/Error/OperationAborted.hpp>
#include <Utility/Error/OperationTimedout.hpp>
#include <Utility/Error/Shutdown.hpp>
#include <Utility/Error/SystemError.hpp>

#endif