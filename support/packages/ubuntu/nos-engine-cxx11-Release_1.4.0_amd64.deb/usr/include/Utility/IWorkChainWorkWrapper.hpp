/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IWORK_CHAIN_WORK_WRAPPER_HPP
#define NOS_ENGINE_UTILITY_IWORK_CHAIN_WORK_WRAPPER_HPP

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Represents work chain work with an associated callback.
        ///
        /// When an instance of WorkChainWorkWrapper is posted to a work chain
        /// the work chain will be prevented from executing more work until the
        /// callback is called.
        ///
        class NOS_ENGINE_UTILITY_API_PUBLIC IWorkChainWorkWrapper
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IWorkChainWorkWrapper class.
            /// 
            virtual ~IWorkChainWorkWrapper() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Post this work item to the work chain.
            /// 
            virtual void post() = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Post the work wrapper to the work chain.
            ///
            /// \note This is a friend function of IWorkChain.
            /// 
            /// \param work_chain The work chain to post the wrapper to.
            /// \param work_wrapper The wrapped work to post to the chain.
            ///
            static void post(IWorkChain &work_chain, CancelableWork &work_wrapper);

            /// 
            /// \brief Called by work wrapper before executing the wrapped work.
            ///
            /// \note This is a friend function of IWorkChain.
            ///
            /// \param work_chain The work chain which this work was posted to.
            /// 
            /// \return The id for the callback associated with the work item.
            /// 
            static CallbackId pre_execute_work_with_callback(IWorkChain &work_chain);

            /// 
            /// \brief Called by callback wrapper before executing the wrapped callback.
            ///
            /// \note This is a friend function of IWorkChain.
            ///
            /// \param work_chain The work chain which this work was posted to.
            /// \param callback_id The id of the callback that is being executed.
            ///
            /// \throw Error::AlreadyCompleted if called is already true.
            /// 
            static void pre_execute_work_callback(IWorkChain &work_chain, const CallbackId &callback_id);

            /// 
            /// \brief Called by callback wrapper after executing the wrapped callback.
            ///
            /// \note This is a friend function of IWorkChain.
            ///
            /// \param work_chain The work chain which this work was posted to.
            /// 
            static void post_execute_work_callback(IWorkChain &work_chain);

            // friend the IWorkChain class so that it can friend protected/private methods
            // of IWorkChainWorkWrapper
            friend class IWorkChain;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_IWORK_CHAIN_WORK_WRAPPER_HPP