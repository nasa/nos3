/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_BUFFER_HPP
#define NOS_ENGINE_UTILITY_BUFFER_HPP

#include <cstdarg>
#include <string>

#include <Utility/Types.hpp>
#include <Utility/IBuffer.hpp>

namespace NosEngine {
namespace Utility {

///
/// \copydoc IBuffer
///
class NOS_ENGINE_UTILITY_API_PUBLIC Buffer :
    public IBuffer {
private:
    // ============================================================================================
    // Life cycle
    // --------------------------------------------------------------------------------------------

    Buffer(); //!< Disable the default constructor.

public:
    ///
    /// \brief Creates a new buffer with a specified initial capacity
    ///
    /// \param new_size Size of buffer to allocate
    ///
    /// \throw std::bad_alloc new failed
    ///
    Buffer(size_t new_size);

    ///
    /// \brief Creates a new buffer and initializes with data
    ///
    /// \param new_size Size of buffer to allocate
    /// \param new_len  Size of new_data
    /// \param new_data Pointer to data
    /// 
    /// \throw std::bad_alloc           new failed
    /// \throw Error::BufferOverflow    data too large (new_len > new_size)
    /// \throw Error::InvalidArgument   new_data is null
    ///
    Buffer(size_t new_size, size_t new_len, const char *new_data);

    ///
    /// \brief Copy constructor
    ///
    /// This is a deep copy constructor - the new buffer allocates new memory and copies the data.
    ///
    /// \param other Reference to Buffer to copy.
    /// 
    /// \throw std::bad_alloc new failed
    ///
    Buffer(const Buffer &other);

    ///
    /// \brief Move constructor
    ///
    /// Constructs a new Buffer using move semantics.
    /// When the call is complete, the 'other' Buffer is valid but empty.
    ///
    Buffer(Buffer&& other);

    ///
    /// \brief Class Destructor. Releases any allocated memory.
    ///
    virtual ~Buffer();

    // ============================================================================================
    // Operators
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Assignment operator
    ///
    /// This is a deep copy - the buffer releases any old memory, then allocates new memory and
    /// copies the data from the other buffer.
    ///
    /// \param other Reference to Buffer to copy.
    /// 
    /// \throw std::bad_alloc new failed
    ///
    Buffer& operator=(const Buffer &other);

    ///
    /// \brief Move assignment operator
    ///
    /// The buffer steals its data with the other buffer.
    /// When the call is complete, The 'other' Buffer is valid but empty.
    ///
    /// \param other R-value reference to Buffer to steal from.
    ///
    Buffer& operator=(Buffer &&other);

    // --------------------------------------------------------------------------------------------
    // IBuffer implementation
    // --------------------------------------------------------------------------------------------

    virtual bool operator==(const IBuffer &other) const;

    virtual bool operator!=(const IBuffer &other) const;

    // ============================================================================================
    // Public API
    // --------------------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------
    // IBuffer implementation
    // --------------------------------------------------------------------------------------------

    virtual void reset();

    virtual void clear(const bool &free = true);

    virtual size_t get_size() const;

    virtual size_t get_length() const;

    virtual char *get_data() const;

    virtual void add(size_t add_len, const char *add_data);

    virtual void set_size(size_t new_size);

    virtual void grow(size_t grow_size);

    virtual void append(size_t append_len, const char *append_data, size_t grow_size = 0);

    virtual void append(size_t offset, size_t append_len, const char *append_data, size_t grow_size = 0);

    virtual const std::string to_string(size_t offset = 0) const;

    NE_FORMAT_GUARD(2,0)
    virtual void vprintf(const char *fmt, va_list ap);

    NE_FORMAT_GUARD(2,3)
    virtual void printf(const char *fmt, ...);

    // TODO
    //NE_FORMAT_GUARD(2, 3)
    //virtual void printf_append(const char *fmt, ...);

    // --------------------------------------------------------------------------------------------
    // Print-based factory functions
    // --------------------------------------------------------------------------------------------

    ///
    /// \brief Creates a new buffer and fills it with the formatted data
    ///
    /// Creates a buffer and writes the printf-type formatted string to the buffer.
    ///
    /// \param new_size Size of buffer to allocate
    /// \param fmt      printf-style format string
    /// \param ap       Additional arguments for format specifiers (if present in format string)
    /// 
    /// \throw Error::BufferOverflow    formatted data is too large for capacity
    /// \throw std::bad_alloc           new failed
    ///
    /// \return Pointer to the new Buffer. Must be explicitly deleted.
    ///
    NE_FORMAT_GUARD(2, 0)
        static Buffer *new_vprintf(size_t new_size, const char *fmt, va_list ap);

    ///
    /// \brief Creates a new buffer and fills it with the formatted data
    ///
    /// Creates a buffer and writes the printf-type formatted string to the buffer.
    ///
    /// \param new_size Size of buffer to allocate
    /// \param fmt      printf-style format string
    /// \param ...      Additional arguments for format specifiers (if present in format string)
    /// 
    /// \throw Error::BufferOverflow    formatted data is too large for capacity
    /// \throw std::bad_alloc           new failed
    ///
    /// \return Pointer to the new Buffer. Must be explicitly deleted.
    ///
    NE_FORMAT_GUARD(2, 3)
        static Buffer *new_printf(size_t new_size, const char *fmt, ...);

public:
    // ============================================================================================
    // Data members
    // --------------------------------------------------------------------------------------------

    size_t size;    //!< Current capacity of the buffer.
    size_t len;     //!< Number of characters currently filled in the buffer.
    char *data;     //!< Pointer to the raw data. USE WITH CAUTION !!
};

}}

#endif

