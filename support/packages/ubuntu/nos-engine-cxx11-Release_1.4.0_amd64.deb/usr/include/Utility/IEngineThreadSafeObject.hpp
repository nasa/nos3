/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_IENGINE_THREAD_SAFE_OBJECT_HPP
#define NOS_ENGINE_UTILITY_IENGINE_THREAD_SAFE_OBJECT_HPP

#include <mutex>
#include <condition_variable>

#include <Utility/IEngineObject.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Represents a thread safe NOS Engine object.
        ///
        class IEngineThreadSafeObject :
            public virtual IEngineObject
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------
        
            /// 
            /// \brief Destructor for an instance of the IEngineThreadSafeObject class.
            /// 
            virtual ~IEngineThreadSafeObject() {}
            
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------
            
            ///
            /// \brief Get general purpose mutex to use for thread syncronization.
            /// 
            /// \return The mutex.
            ///
            virtual std::mutex &get_mutex() const = 0;
        };

        ///
        /// \brief Represents a thread safe NOS Engine object that has a condition variable.
        ///
        class IEngineThreadSafeObjectWithCV :
            public virtual IEngineThreadSafeObject
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IEngineThreadSafeObjectWithCV class.
            /// 
            virtual ~IEngineThreadSafeObjectWithCV() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get general purpose condition variable to use for thread syncronization.
            /// 
            /// \return The condition variable.
            ///
            /// \throw Error::NotImplemented if a condition variable is not used/needed.
            ///
            virtual std::condition_variable &get_cv() const = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_IENGINE_THREAD_SAFE_OBJECT_HPP