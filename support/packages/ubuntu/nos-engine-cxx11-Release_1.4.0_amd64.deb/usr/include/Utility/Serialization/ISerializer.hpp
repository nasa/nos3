/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP
#define NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP

#include <Utility/Types.hpp>

namespace NosEngine
{
    namespace Utility
    {
        ///
        /// \brief Provides serialization capabilities for a buffer.
        ///
        class ISerializer
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the ISerializer class.
            /// 
            virtual ~ISerializer() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief serialize a character
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_char(char val) = 0;

            ///
            /// \brief serialize an 8-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int8(int8_t val) = 0;

            ///
            /// \brief serialize a 16-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int16(int16_t val) = 0;

            ///
            /// \brief serialize a 32-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int32(int32_t val) = 0;

            ///
            /// \brief serialize a 64-bit integer
            ///
            /// \param val value to serialize
            ///
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_int64(int64_t val) = 0;

            ///
            /// \brief serialize a float
            ///
            /// \param val value to serialize
            /// 
            /// \throw FormatStringFailed   failed to format the float into a string
            /// \throw BufferOverflow       there is not enough space left in the buffer
            ///
            virtual void serialize_float(float val) = 0;

            ///
            /// \brief serialize a double
            ///
            /// \param val value to serialize
            /// 
            /// \throw FormatStringFailed   failed to format the double into a string
            /// \throw BufferOverflow       there is not enough space left in the buffer
            ///
            virtual void serialize_double(double val) = 0;

            ///
            /// \brief serialize a string
            ///
            /// \param val value to serialize
            /// 
            /// \throw InvalidArgument  string length exceeds the maximum permitted or val is null
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_string(const char * const val) = 0;

            ///
            /// \brief serialize a string
            ///
            /// \param val value to serialize
            /// 
            /// \throw InvalidArgument  string length exceeds the maximum permitted
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_string(const std::string &val) = 0;

            ///
            /// \brief serialize raw data
            ///
            /// \param val       pointer to raw data to serialize
            /// \param val_size  length of data to serialize
            /// 
            /// \throw InvalidArgument  data length exceeds the maximum permitted or val is null
            /// \throw BufferOverflow   there is not enough space left in the buffer
            ///
            virtual void serialize_binary(const void * const val, size_t val_size) = 0;

            ///
            /// \brief return a pointer to the buffer
            ///
            /// \return pointer to buffer
            ///
            virtual Buffer *get_buffer() = 0;

            ///
            /// \brief Reset the internal buffer.
            ///
            /// This will reset the length of the buffer to zero. It does not overwrite or free any data (capacity remains the same).
            ///
            virtual void reset() = 0;
        };
    }
}

#endif // NOS_ENGINE_UTILITY_SERIALIZATION_ISERIALIZER_HPP