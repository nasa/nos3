/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_SERVER_BUS_HPP
#define NOS_ENGINE_MS1553_SERVER_BUS_HPP

#include <MS1553/visibility.hpp>
#include <Server/Bus.hpp>
#include <MS1553/types.hpp>
#include <vector>

namespace NosEngine
{
    namespace MS1553
    {
		class MS1553BusRouter;

        /*
         * \brief Server side bus object for 1553 Buses
         */
        class NOS_ENGINE_MS1553_API_PUBLIC MS1553Bus : public NosEngine::Server::Bus
        {
            public:
                /*
                 * \brief Creates the 1553 Bus
                 * 
                 * \param name Name of the bus
                 */
                MS1553Bus(NosEngine::Utility::IWorkHub &work_hub, const std::string& name);
                
                /*
                 * \brief Class destructor
                 */
                virtual ~MS1553Bus();

                /*
                 * \brief Retrieves a specialized bus router for the bus
                 */
				virtual Common::IMessageRouter* get_router() const;
				
                /*
                 * \brief Gets the protocol identifier string
                 *
                 * \return Protocol identifier string
                 */
                virtual std::string get_protocol() const;
				
                /*
                 * \brief Associateds a RT address with a data node
                 *
                 * \param address Address to associate
                 * \param node Data node to be associated
                 *
                 * \return Success or Failure 
                 */
                bool add_rt(const RTAddress& address, Server::DataNode* node);
				//TODO: This does not do any verification if a node can be removed by the caller.
				
                /*
                 * \brief Removes any DataNode associated address
                 *
                 * \param address Address to remove DataNodes from
                 */
                void remove_rt(const RTAddress&);
				
                /*
                 * \brief Get the associated DataNode for the address
                 *
                 * \param address RT address to retrieve
                 *
                 * \return Either the associated DataNode or nullptr
                 */
                Server::DataNode* get_node_for_rt(const MS1553::RTAddress& address) const;

                /*
                 * \brief Adds an interceptor to an RT address
                 *
                 * \param address Address to associate with
                 * \param node Interceptor node to be associated with the address
                 */
				void add_interceptor(RTAddress& address, Server::InterceptorNode* node);
				
                /*
                 * \brief Removes an interceptor from an address
                 *
                 * \param address Address to remove from
                 * \param node Interceptor to remove from the address
                 */
                void remove_interceptor(RTAddress& address, Server::InterceptorNode* node);
			private:
				Server::DataNode* rts[RT_ADDRESS_MAX];
				std::vector<Server::InterceptorNode*> interceptors[RT_ADDRESS_MAX];
				MS1553BusRouter* router;
        };
    }
}

#endif
