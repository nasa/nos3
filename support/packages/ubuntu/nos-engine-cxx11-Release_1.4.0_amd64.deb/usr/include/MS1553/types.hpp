/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_TYPES_HPP
#define NOS_ENGINE_MS1553_TYPES_HPP

#include <stdint.h>

#include <string>

/*  BC -> RT  STATUS Response
 *  RT -> BC  STATUS + Data?
 *
 *  Missing RT? Throw RT Missing?
 *
 *  RT.send_status(STATUS_TYPE)
 *  RT.send_Status(STATUS_TYPE, DATA)
 *
 *  RT Callback (RT*, CommandWord) 
 *
 *  Utility Functions:
 *
 *  Get_RT(CommandWord)
 *  Get_SUB(CommandWord)
 *  Get_mode(CommandWord) Maybe
 *
 *  BC.request_data(RT, SA, Length)
 *
 *  RequestResult { Statusword, Data } ???
 *  StatusWord BC.transmit(RT, SA, len, data)
 *  void BC.transmit(RT, SA, len, data, CB)
 *
 *  BC.send_mode_Code(RT, ModeCode)
 *  BC>send_mode_code(RT, ModeCode, CB)i
 *  How to report an RT Misisng?
 *
 * */

namespace NosEngine
{
    namespace MS1553
    {
        const std::string MS1553_PROTOCOL_NAME = "ms1553";
        typedef uint8_t RTAddress;
        typedef uint8_t Subaddress;
        typedef uint16_t MS1553Word; //Ignoring Sync and Parity a MS1553 Word is 16 bits
        typedef uint8_t WordCount;
        const RTAddress RT_ADDRESS_MIN = 0;
        const RTAddress RT_ADDRESS_MAX = 31;
		const RTAddress RT_BROADCAST_ADDRESS = 31;
        const Subaddress MODE_CODE_SA_LOW = 0;
        const Subaddress MODE_CODE_SA_HIGH = 31;
        const uint8_t MAX_DATA_WORDS = 32;
        const MS1553Word RTMask = 0xF800;
        const MS1553Word RTShift = 11;
        const MS1553Word SAMask = 0x03E0;
        const MS1553Word SAShift = 5;
        const MS1553Word TransmitMask = 0x0400;
        const MS1553Word TransmitShift = 10;
        const MS1553Word WordCountMask = 0x001F;
        const MS1553Word WordCountShift = 0;

        /*
         * \brief Convience struct to read/write data to for a StatusWord
         */
        struct StatusWord
        {
            StatusWord(){ data = 0;};
			StatusWord(const MS1553Word& data) : data(data) {}
            ~StatusWord(){};

            MS1553Word data;
            RTAddress getRT() const { return static_cast<RTAddress>((data & RTMask) >> RTShift); }
            void setRT(const RTAddress rt) { data = (rt << RTShift) | (data && !RTMask); }; 

            bool get_message_error() const { return data & (1 << 10) ? true : false; }
            void set_message_error(bool error) { set_flag(error, 10); }

            bool get_busy() const { return data & (1 << 3) ? true : false; }
            void set_busy(bool busy) { set_flag(busy, 3); }

            private:
            void set_flag(bool flag, uint16_t offset) {
                if (flag) { data = data | (1 << offset); }
                else { data = data & ~(1<<offset); }
            }

        };

        /*
         * \brief Convience struct to read/write data for a CommandWord
         */
        struct CommandWord
        {
            CommandWord(){ data = 0;};
			CommandWord(const MS1553Word& data) : data(data) {}
            ~CommandWord(){};

            RTAddress getRT() const { return static_cast<RTAddress>((data & RTMask) >> RTShift); }
            void setRT(const RTAddress rt) { data = (rt << RTShift) | (data & ~RTMask); }
            
            bool isTransmit() const { return (data &  TransmitMask) ? true : false; }
            void setTransmit(const bool transmit) { data = ((transmit ? 1 : 0) << TransmitShift) | ( data & ~TransmitMask); }
            Subaddress getSA() const { return static_cast<Subaddress>((data & SAMask) >> SAShift); }
            void setSA(const Subaddress sa) { data = (sa << SAShift) | ( data & ~SAMask); }
            WordCount get_word_count() const { 
                WordCount count = ( data & WordCountMask) >> WordCountShift; 
                return (count == 0 ) ? 32 : count; 
            }
            void set_word_count(WordCount count) { data = (count << WordCountShift) | (data & ~WordCountMask); }

            bool isModeCode() const { return getSA() == 0 || getSA() == 31;}

            MS1553Word data;
        };
        
        enum class ErrorCodes : uint8_t
        {
            NO_RESPONSE,
            NONE
        };
        
        struct RequestResult
        {
            RequestResult() {}
            ~RequestResult() {}

            ErrorCodes error;
            WordCount data_length;
            MS1553Word data[MAX_DATA_WORDS];
            StatusWord status;
        };

        struct TransmitResult
        {
            ErrorCodes error;
            CommandWord commandWord;
            StatusWord status;
        };
    }
}
#endif
