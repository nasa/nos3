/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_CLIENT_BUSCONTROLLER
#define NOS_ENGINE_MS1553_CLIENT_BUSCONTROLLER

#include <Transport/TransportHub.hpp>
#include <MS1553/types.hpp>
#include <MS1553/visibility.hpp>
#include <memory>
#include <string.h>
#include <functional>

namespace NosEngine
{
    //Placehold Forward declarations
    namespace Client
    {
        class Bus;
    }

    namespace MS1553
    {
        namespace Client
        {
            typedef std::function<void(const TransmitResult) > BCTransmitCallback;
            typedef std::function<void(const RequestResult) > BCRequestCallback;

            /*
             * \brief Creates a Bus Controller on the 1553 Bus
             */
            class NOS_ENGINE_MS1553_API_PUBLIC BusController
            {
            public:
                /*
                 * \brief Attempts to create a Bus Controller on the named bus
                 *
                 * \note If the creation is successful a DataNode named "bc" will be created
                 * 
                 * \param busName Name of the bus
                 * \param server_uri Server URI
                 * \param num_service_threads The number of service threads that should be created
                 */
                BusController(const std::string& busName, const std::string& server_uri, const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS);

                /*
                 * \brief Attempts to create a Bus Controller on the named bus
                 *
                 * \note If the creation is successful a DataNode named "bc" will be created
                 * 
                 * \param transport_hub Existing transport hub to use
                 * \param busName Name of the bus
                 * \param server_uri Server URI
                 */
                BusController(NosEngine::Transport::TransportHub &transport_hub, const std::string& busName, const std::string& server_uri);
                
                /*
                 * \brief Class destructor
                 */
                ~BusController();

                /**
                 * \brief Get the transport hub used by this instance.
                 * 
                 * If the instance owns the hub (ie hub was not provided to the constructor) then use
                 * the hub returned with caution.  When this instance is destroyed the hub it owns
                 * will be destroyed as well.
                 * 
                 * \return The tranport hub of this instance.
                 */
                Transport::TransportHub &get_transport_hub() const;

                /*
                 * \brief Begins a receive transaction on the 1553 Bus
                 *
                 * \param address RT address to send data to
                 * \param sa Subaddress to be targeted
                 * \param count Size of the data being sent
                 * \param data Data to be sent
                 *
                 * \return Result of the transaction
                 */
                TransmitResult transmit_data(const RTAddress& address, const Subaddress& sa, const WordCount& count, const MS1553Word* const data) const ;
               
                /*
                 * \brief Begins a receive transaction on the 1553 Bus
                 *
                 * \param command CommandWord detailing the transaction
                 * \param data Data to be sent
                 *
                 * \return Result of the transaction
                 */ 
                TransmitResult transmit_data(const CommandWord& command, const MS1553Word* const data) const;
                
                /*
                 * \brief Begins an asynchronous receive transaction on the 1553 Bus
                 *
                 * \param address RT address to send data to
                 * \param sa Subaddress to be targeted
                 * \param count Size of the data being sent
                 * \param data Data to be sent
                 * \param callback Callback to called when the transaction is complete
                 */
                void transmit_data(const RTAddress& address, const Subaddress& sa, const WordCount& count, const MS1553Word* const data, BCTransmitCallback callback) const;
                
                /*
                 * \brief Begins an asynchronous receive transaction on the 1553 Bus
                 *
                 * \param command CommandWord detailing the transaction
                 * \param data Data to be sent
                 * \param callback Callback to be called when the transaction is complete
                 *
                 * \return Result of the transaction
                 */
                void transmit_data(const CommandWord& command, const MS1553Word* const data, BCTransmitCallback callback) const;
                
                /*
                 * \brief Begins a transmit transaction on the 1553 Bus
                 *
                 * \param address RT address to send data to
                 * \param sa Subaddress to be targeted
                 * \param length Size of the data being requested
                 *
                 * \return Result of the transaction
                 */
                RequestResult request_data(const RTAddress& address, const Subaddress& sa, const WordCount& length) const;
                
                /*
                 * \brief Begins a transmit transaction on the 1553 Bus
                 *
                 * \param command CommandWord detailing the transaction
                 *
                 * \return Result of the transaction
                 */
                RequestResult request_data(const CommandWord& command) const;
                
                /*
                 * \brief Begins an asynchronous transmit transaction on the 1553 Bus
                 *
                 * \param address RT address to send data to
                 * \param sa Subaddress to be targeted
                 * \param length Size of the data being requested
                 * \param callback Callback to be called when transaction is complete
                 */
                void request_data(const RTAddress& address, const Subaddress& sa, const WordCount& length, BCRequestCallback callback) const;
                
                /*
                 * \brief Begins a transmit transaction on the 1553 Bus
                 *
                 * \param command CommandWord detailing the transaction
                 * \param callback Callback to be called on transaction completion
                 */
                void request_data(const CommandWord& command, BCRequestCallback) const;
            private:
                struct BusControllerPimpl;
                std::unique_ptr<BusControllerPimpl> impl;
            };
        }
    }
}

#endif
