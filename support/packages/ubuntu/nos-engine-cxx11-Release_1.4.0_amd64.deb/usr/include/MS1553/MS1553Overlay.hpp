/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/
#ifndef NOS_ENGINE_MS1553_OVERLAY_HPP
#define NOS_ENGINE_MS1553_OVERLAY_HPP

#include <Common/BufferOverlay.hpp>
#include <Common/ReadOnlyBufferOverlay.hpp>
#include <Common/Message.hpp>
#include <MS1553/visibility.hpp>

namespace NosEngine
{
	namespace MS1553
	{
        /*
         * \brief A specialized buffer overlay
         *
         * A specialized buffer overlay designed to be used for the MS 1553
         * protocol
         */
		class NOS_ENGINE_MS1553_API_PUBLIC MS1553Overlay : public Common::BufferOverlay
		{
		public:
            /* \brief Creates a new overlay based on a message object
             *
             * Creates a new overlway based on a raw Message object. the overlay
             * will be based on Message::buffer at the Protocol::USER_DATA_START offset.
             * 
             * \param msg Message to base the overlay on
             */
			MS1553Overlay(Common::Message& msg);

            /* \brief Creates a new overlay around a buffer object
             *
             * The created overlay will assume the default 0 offset location.
             *
             * \param buffer Buffer to be used as the base object
             */
			MS1553Overlay(Utility::Buffer& buffer);
			
            /*
             * \brief Class destructor
             */
            virtual ~MS1553Overlay();
		};
        
        /*
         * \brief A specialized read only buffer overlay
         *
         * A specialized read only buffer overlay designed to be used for the MS 1553
         * protocol
         */
		class NOS_ENGINE_MS1553_API_PUBLIC ReadOnlyMS1553Overlay : public Common::ReadOnlyBufferOverlay
		{
		public:
			/* \brief Creates a new overlay based on a message object
             *
             * Creates a new overlway based on a raw Message object. the overlay
             * will be based on Message::buffer at the Protocol::USER_DATA_START offset.
             * 
             * \param msg Message to base the overlay on
             */
            ReadOnlyMS1553Overlay(const Common::Message& msg);
			
            /* \brief Creates a new overlay around a buffer object
             *
             * The created overlay will assume the default 0 offset location.
             *
             * \param buffer Buffer to be used as the base object
             */
            ReadOnlyMS1553Overlay(const Utility::Buffer& buffer);
			
            /*
             * \brief Class destructor
             */
            virtual ~ReadOnlyMS1553Overlay();
		};
	}
}

#endif
