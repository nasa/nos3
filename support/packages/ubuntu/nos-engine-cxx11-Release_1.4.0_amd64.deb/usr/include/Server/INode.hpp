/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_INODE_HPP
#define NOS_ENGINE_SERVER_INODE_HPP

#include <Utility/States/Stoppable.hpp>

#include <Common/INode.hpp>

#include <Server/Types.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief Server-side representation of a node.
        ///
        class INode :
            public virtual Common::INode,
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the INode class.
            /// 
            virtual ~INode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the id of the transport for the connection to the client side node.
            ///
            /// \return The id of the transport.
            ///
            virtual Common::TransportID get_transport_id() const = 0;

            ///
            /// \brief Send a message to the client-side node
            ///
            /// \param to_send  message to send
            ///
            /// \return MessageOK if successfully sent
            /// \return MessageError if error occurred
            ///
            virtual Common::ErrorCode send_message(Common::Message to_send) const = 0;
                
            ///
            /// \brief Assign a transaction ID and send the message to the client-side node
            ///
            /// A new transaction ID will be retrieved and set in the message before sending.
            ///
            /// \param to_send  message to send
            ///
            /// \return MessageOK if successfully sent
            /// \return MessageError if error occurred
            ///
            virtual Common::ErrorCode send_message_with_id(Common::Message to_send) const = 0;

            ///
            /// \brief Add a new transaction and send the message.
            ///
            /// This method will send the message and add the matching transaction to the transaction manager.
            /// A new transaction ID will be retrieved and set in the message before sending.
            ///
            /// \param to_send      message to send
            /// \param transaction  transaction to add
            /// \param manager      the transaction manager
            ///
            /// \return MessageOK if successfully sent
            /// \return MessageError if error occurred
            ///
            virtual Common::ErrorCode send_message(Common::Message to_send, Common::ITransaction* transaction, Common::ITransactionManager &manager) const = 0;

            ///
            /// \brief Process a transaction that is for this node.
            ///
            /// This method will get a new transaction ID and set it in the message.
            /// The transaction will be added to the manager with the same ID.
            ///
            /// \param message      message for the transaction to process
            /// \param to_process   transaction, related to the message, to process
            /// \param manager      the transaction manager
            ///
            /// \return MessageOK if successfully queued for processing
            /// \return MessageError if error occurred
            ///
            virtual Common::ErrorCode process_transaction(Common::Message message, Common::ITransaction* to_process, Common::ITransactionManager& manager) const = 0;
            
            ///
            /// \brief Check the message to see if it is filtered out by the node.
            ///
            /// \param message message to check
            ///
            /// \return true if the message is filtered out (ie will be ignored if sent to the node).
            ///
            virtual bool is_filtered(const Common::Message &message) const = 0;
        };           
    }
}

#endif