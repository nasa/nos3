/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_BUS_HPP
#define NOS_ENGINE_SERVER_BUS_HPP

#include <string>
#include <vector>
#include <atomic>
#include <mutex>

#include <Utility/IWorkHub.hpp>
#include <Utility/States/Stoppable.hpp>

#include <Common/ITransactionManager.hpp>
#include <Common/Bus/BusProtocol.hpp>

#include <Server/Types.hpp>
#include <Server/IBus.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc IBus
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC Bus :
            public IBus,
            public Utility::States::Stoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the Bus class.
            ///
            /// \param work_hub WorkHub to use for async work.
            /// \param name     Name of the bus.
            ///
            Bus(Utility::IWorkHub &work_hub, std::string name);

        private:
            Bus(const Bus &other);  //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the Bus class.
            /// 
            virtual ~Bus();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Bus operator=(const Bus&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IBus implementation
            // ------------------------------------------------------------------------------------

            virtual std::string get_name() const;

            virtual Common::BusRegistrationFlags register_client(const Common::Message& message, Common::WeakSendOperator transport_to_add);
            
            virtual Common::NodeID add_data_node(const std::string& name, Common::WeakSendOperator sender);
            
            virtual void remove_data_node(const std::string& name);

            virtual void remove_data_node(const Common::NodeID& id);

            virtual DataNode* find_data_node(const std::string& name) const;

            virtual DataNodes get_all_data_nodes() const;
            
            virtual Common::NodeID add_interceptor_node(const std::string& to_add, const std::string& target, Common::BusProtocol::InterceptorDirection direction, Common::WeakSendOperator sender);
            
            virtual void remove_interceptor_node(const std::string& name);

            virtual InterceptorNode* find_interceptor_node(const std::string& name) const;
            
            virtual Common::NodeID add_time_node(const std::string& to_add, Common::BusProtocol::TimeNodeType time_type, Common::WeakSendOperator sender);

            virtual void remove_time_node(const std::string& name, Common::BusProtocol::TimeNodeType time_type);

            virtual void remove_time_client(const std::string& name);

            virtual void remove_time_sender(const std::string& name);

            virtual TimeClientNodes get_all_time_clients() const;

            virtual TimeSender* get_time_sender() const;

            virtual Common::IMessageRouter* get_router() const;

            virtual std::string get_protocol() const;

            virtual void process_query(const Common::Message& query, Common::Message& response) const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Called when a client side representation of the bus disconnects.
            ///
            /// \param id The id of the transport which disconnected.
            ///
            void on_transport_disconnected(Common::TransportID id);

            ///
            /// \copydoc find_data_node()
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            DataNode* get_data_node(const std::string& name) const;

            ///
            /// \copydoc find_interceptor()
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            InterceptorNode* get_interceptor(const std::string& name) const;

            ///
            /// \brief Get the time client by name
            ///
            /// \param name  name of the time client
            ///
            /// \return pointer to the time client.
            ///
            TimeClient* get_time_client(const std::string& name) const;

            ///
            /// \brief Remove the data node from the collection.
            ///
            /// \param data_node_iter Iterator for the data node to remove.
            ///
            /// \return The iterator for the next data node in the collection.
            ///
            DataNode* remove_data_node(DataNodes::iterator& data_node_iter);

            ///
            /// \brief Remove the interceptor from the collection.
            ///
            /// \param interceptor_node_iter Iterator for the interceptor to remove.
            ///
            /// \return The iterator for the next interceptor in the collection.
            ///
            InterceptorNode* remove_interceptor_node(InterceptorNodes::iterator& interceptor_node_iter);

            ///
            /// \brief Remove the time client from the collection.
            ///
            /// \param time_node_iter Iterator for the time client to remove.
            ///
            /// \return The iterator for the next time client in the collection.
            ///
			TimeClient* remove_time_client(TimeClientNodes::iterator& time_node_iter);

            ///
            /// \brief Remove/clear the time sender for the bus.
            ///
            TimeSender* remove_time_sender();

            ///
            /// \brief Notify transactions about the removed node and then delete it.
            ///
            void delete_node(INode *node);

        protected:
            // ------------------------------------------------------------------------------------
            // IBus (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        public:
            const std::string name; //!< name of the bus

        protected:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- transactions ----
            Common::ITransactionManager* manager;

            // ---- transport ----
            std::map<Common::TransportID, Common::WeakSendOperator> transports;

            // ---- time ----
			TimeClientNodes time_clients;
            TimeSender* time_sender;
            //Common::SimTime time;
            
            // ---- nodes ----
            DataNodes data_nodes;
            InterceptorNodes interceptor_nodes;
            std::atomic<Common::NodeID> next_node_id;

            // ---- message routing ----
            Common::IMessageRouter* const router;

            // ---- status ----
            bool stopping;
            bool stopped;

            // TODO: Refactoring is needed so that this friend can be avoided
            friend class Server; // for on_transport_dissconnect
        };           
    }
}

#endif