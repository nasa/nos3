/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_ISERVER_HPP
#define NOS_ENGINE_SERVER_ISERVER_HPP

#include <string>

#include <Utility/States/IStoppable.hpp>

#include <Transport/TransportHub.hpp>

#include <Server/Types.hpp>
#include <Server/PluginTypes.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief The big show. Everything runs through the server!
        ///
        class IServer :
            public virtual Utility::IEngineThreadSafeObjectWithCV,
            public virtual Utility::States::IStoppable
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            /// 
            /// \brief Destructor for an instance of the IServer class.
            /// 
            virtual ~IServer() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the transport hub used by this instance.
            ///
            /// If the instance owns the hub (ie hub was not provided to the constructor) then use
            /// the hub returned with caution.  When this instance is destroyed the hub it owns
            /// will be destroyed as well.
            ///
            /// \return The tranport hub of this instance.
            ///
            virtual Transport::TransportHub &get_transport_hub() const = 0;

            // TODO: Replace this with add_data_logger_target method.
            ///
            /// \brief Enable the data logger.
            ///
            /// \note This is a temporary method and will be replaced with a method to add
            /// targets to the data logger in the future.
            ///
            virtual void enable_logger() = 0;

            ///
            /// \brief Add a new transport to the server.
            ///
            /// This will add a new transport to the server. For each transport added,
            /// the server will listen for an incoming connection. Once a connection is made,
            /// a background thread will pull messages and run routing/processing.
            ///
            /// \param name name of the transport
            /// \param local_uri  the URI to connect or listen on
            /// \param connected_callback     callback to call when a connection is received
            /// \param disconnected_callback  callback to call when the connection is disconnected
            ///
            /// Pass nullptr to disable a callback.
            ///
            virtual void add_transport(std::string local_uri, ClientConnectedCallback connected_callback = nullptr, ClientDisconnectedCallback disconnected_callback = nullptr) = 0;

            ///
            /// \brief Remove a transport from the server.
            ///
            /// \warning not implemented
            ///
            virtual void remove_transport(Common::IMessageConnection *message_connection) = 0;

            ///
            /// \brief Add a new bus to the server
            ///
            /// \param to_add new bus to add to server
            ///
            /// \throw runtime_error Bus with name already exists
            ///
            virtual void add_bus(Bus* bus_to_add) = 0;

            ///
            /// \brief Get a bus from the server by name.
            ///
            /// \param name  name of the bus
            ///
            /// \return pointer to the bus; null if not found
            ///
            virtual Bus* get_bus(const std::string& name) const = 0;

            ///
            /// \brief Get a bus from the server by name; create it if it doesn't already exist.
            ///
            /// \param name  name of the bus
            /// \param protocol protocol of the requested bus
            ///
            /// \throw std::runtime_error runtime error if the protocols do not match an existing bus
            ///
            virtual Bus* get_or_create_bus(std::string name, std::string protocol = Common::DEFAULT_PROTOCOL_NAME) = 0;

            ///
            /// \brief Perform an action for each bus existing in the server
            ///
            /// Thread safe. Callback should not block.
            ///
            /// \param callback Action to execute for each bus
            ///
            virtual void for_each_bus(BusActionCallback callback) = 0;

            ///
            /// \brief Register a function with the server that should be called to construct
            /// a Bus instance for the specified protocol.
            ///
            /// \param protocol The string identifier for the protocol.
            /// \param creator  The function which constructs a Bus for the protocol.
            ///
            virtual void register_protocol_bus(const std::string& protocol, BusCreationFunction creator) = 0;

            ///
            /// \brief Load the server plugin.
            ///
            /// This method attempts to load a shared library with the specified name.
            /// Example:
            /// If the plugin name is "foobar", then on linux a shared library named "foobar"
            /// or "nos_engine_foobar_cxx11" will be searched for.
            ///
            /// \param The name of the server plugin to load.
            ///
            virtual void load_plugin(const std::string& plugin) = 0;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Get the message router that is to be used by the server to route message
            /// received from clients.
            ///
            /// \return The message router.
            ///
            virtual Common::IMessageRouter &get_server_router() const = 0;
        };
    }
}

#endif