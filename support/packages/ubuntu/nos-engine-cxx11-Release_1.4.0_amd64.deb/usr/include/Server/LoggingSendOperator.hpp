/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_LOGGING_SEND_OPERATOR_HPP
#define NOS_ENGINE_SERVER_LOGGING_SEND_OPERATOR_HPP

#include <Common/SendOperator.hpp>
#include <Server/DataLogger.hpp>
#include <Common/Message.hpp>
#include <Common/IMessageConnection.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \brief A send operator that adds a hook to perform data logging.
        ///
        /// This class is used to add a hook to log all messages that are sent out of the server.
        /// The pre-send hook clones the message since the transport will steal the message.
        /// The post-send hook will log the cloned message if the transport successfully transmitted the message.
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC LoggingSendOperator :
            public Common::SendOperator
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a logging send operator.
            ///
            /// \param transport   the transport for sending messages
            /// \param logger_ref  reference to the data logger
            ///
            LoggingSendOperator(std::shared_ptr<Common::IMessageConnection> transport, DataLogger& logger_ref);

        private:
            LoggingSendOperator(const LoggingSendOperator&);

        public:
            /// 
            /// \brief Destructor for an instance of the LoggingSendOperator class.
            /// 
            virtual ~LoggingSendOperator();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            LoggingSendOperator& operator=(const LoggingSendOperator&);

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // SendOperator implementation
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Overloaded to clone the message before it is sent.
            ///
            /// \param msg  The outgoing message
            ///
            virtual void pre_send_message_hook(const Common::Message& msg);

            ///
            /// \brief Overloaded to log the message, but only if the transport successfully sent the message.
            ///
            /// \param send_succeeded true of the transport successfully sent the message; false if an error occurred
            ///
            virtual void post_send_message_hook(bool send_succeeded);

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            DataLogger& logger;
            bool log_message_ready;
            Common::Message log_message;
        };

    }
}

#endif // NOS_ENGINE_SERVER_LOGGING_SEND_OPERATOR_HPP