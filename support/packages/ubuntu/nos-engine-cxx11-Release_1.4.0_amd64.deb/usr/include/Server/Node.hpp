/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_SERVER_NODE_HPP
#define NOS_ENGINE_SERVER_NODE_HPP

#include <functional>
#include <vector>
#include <mutex>

#include <Utility/States/Stoppable.hpp>

#include <Server/Types.hpp>
#include <Server/INode.hpp>

namespace NosEngine
{
    namespace Server
    {
        ///
        /// \copydoc INode
        ///
        class NOS_ENGINE_SERVER_API_PUBLIC Node :
            public virtual INode,
            public Utility::States::Stoppable
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a node object.
            ///
            /// \param name    name of the node
            /// \param id      unique ID of the node
            /// \param sender  send operator to send messages to the client-side node
            ///
            Node(const std::string& name, const Common::NodeID id, Common::WeakSendOperator sender);

        private:
            Node(const Node&); //!< Disable the copy constructor.

        public:
            /// 
            /// \brief Destructor for an instance of the Node class.
            /// 
            virtual ~Node();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Node& operator=(const Node&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // INode implementation
            // ------------------------------------------------------------------------------------

            virtual std::string get_name() const;

            virtual Common::NodeID get_id() const;

            virtual Common::TransportID get_transport_id() const;

            virtual Common::ErrorCode send_message(Common::Message to_send) const;
            
            virtual Common::ErrorCode send_message_with_id(Common::Message to_send) const;

            virtual Common::ErrorCode send_message(Common::Message to_send, Common::ITransaction* transaction, Common::ITransactionManager &manager) const;

            virtual Common::ErrorCode process_transaction(Common::Message message, Common::ITransaction* to_process, Common::ITransactionManager& manager) const;
            
            virtual bool is_filtered(const Common::Message &message) const;

        protected:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // INode (IEngineThreadSafeObjectWithCV) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

            virtual std::condition_variable &get_cv() const;

            // ------------------------------------------------------------------------------------
            // Stoppable implementation
            // ------------------------------------------------------------------------------------

            virtual bool is_stopping_no_lock() const;

            virtual void set_stopping_no_lock(const bool &stopping);

            virtual bool is_stopped_no_lock() const;

            virtual void set_stopped_no_lock(const bool &stopped);

            virtual void process_stop(std::unique_lock<std::mutex> &lock);

        public:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            const std::string name;
            const Common::NodeID id;

        protected:
			std::vector<MessageFilterFunc> filters;
            mutable std::mutex mutex;
            mutable std::condition_variable cond;
            bool stopping;
            bool stopped;

        private:
            Common::WeakSendOperator transport;
            Common::TransportID transport_id;
        };           
    }
}

#endif