/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IBUS_GROUP_HPP
#define NOS_ENGINE_CLIENT_IBUS_GROUP_HPP

#include <Client/types.hpp>
#include <Client/Globals.hpp>

namespace NosEngine
{
    namespace Client
    {
        class IBusGroup :
            public virtual Utility::IEngineThreadSafeObject
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the IBusGroup class.
            ///
            virtual ~IBusGroup() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Add a bus to the bus group.
            ///
            /// \param bus      The bus to add. It must not have a time sender.
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void add(IBus *bus, const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;

            ///
            /// \brief Remove a bus from the bus group.
            ///
            /// \param bus The bus to remove.
            ///
            virtual void remove(IBus *bus) = 0;

            ///
            /// \brief Set time on all buses residing on this server.
            ///
            /// This method blocks until all the buses have had their time set.
            ///
            /// \param time     New simulation time
            /// \param timeout  timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void set_time(NosEngine::Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT) = 0;
        };
    }
}

#endif