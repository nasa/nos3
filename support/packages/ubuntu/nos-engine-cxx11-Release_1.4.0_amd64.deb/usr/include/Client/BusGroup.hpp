/* Copyright (C) 2009 - 2016 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_BUS_GROUP_HPP
#define NOS_ENGINE_CLIENT_BUS_GROUP_HPP

#include <vector>

#include <Client/types.hpp>
#include <Client/IBusGroup.hpp>
#include <Client/IBus.hpp>

namespace NosEngine
{
    namespace Client
    {
        class NOS_ENGINE_CLIENT_API_PUBLIC BusGroup :
            public IBusGroup
        {
        protected:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            typedef std::vector<IBus *> BusVector;
            typedef std::map<IBus *, NosEngine::Utility::CallbackId> BusToCallbackIdMap;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the BusGroup class.
            ///
            BusGroup();

        private:
            BusGroup(const BusGroup&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the BusGroup class.
            ///
            virtual ~BusGroup();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            BusGroup& operator=(const BusGroup&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IBusGroup implementation
            // ------------------------------------------------------------------------------------

            virtual void add(IBus *bus, const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual void remove(IBus *bus);

            virtual void set_time(NosEngine::Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT);

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \copydoc remove(IBus *)
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            void remove_nolock(IBus *bus);

            ///
            /// \brief Get a value indicating if the specified Bus is in the BusGroup.
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            bool bus_is_present_nolock(IBus *bus);

            ///
            /// \brief Get a value indicating if a Bus, with the specified name, is in the BusGroup.
            ///
            /// \note No lock on a mutex is acquired by this method (call with appropriate lock held).
            ///
            /// \param bus_name The name of the bus to check for.
            ///
            bool bus_name_is_present_nolock(std::string bus_name);

        protected:
            // ------------------------------------------------------------------------------------
            // IBusGroup (IEngineThreadSafeObject) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;
            mutable std::condition_variable cond;

            // ---- collections ----
            BusVector bus_vec;
            BusToCallbackIdMap bus_callback_id_map;

            // ---- status ----
            bool calling_callbacks;
        };
    }
}

#endif