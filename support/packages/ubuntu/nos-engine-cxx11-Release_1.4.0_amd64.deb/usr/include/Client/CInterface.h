/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_C_INTERFACE_H
#define NOS_ENGINE_CLIENT_C_INTERFACE_H

#include <Client/visibility.hpp>

#ifdef __cplusplus
    #include <cstddef>
    #include <cstdint>

    #include <Utility/Serializer.hpp>
    #include <Utility/Buffer.hpp>

    #include <Client/IBus.hpp>
    #include <Client/BusGroup.hpp>
    #include <Client/DataNode.hpp>

    typedef NosEngine::Transport::TransportHub NE_TransportHub;
    typedef NosEngine::Client::IBus NE_Bus;
    typedef NosEngine::Client::BusGroup NE_BusGroup;
    typedef NosEngine::Client::DataNode NE_DataNode;
    typedef NosEngine::Common::Message NE_Message;
    typedef NosEngine::Utility::Buffer NE_Buffer;
    typedef NosEngine::Utility::Serializer NE_Serializer;
    typedef NosEngine::Utility::Deserializer NE_Deserializer;

    typedef NosEngine::Common::SimTime NE_SimTime;
    typedef NosEngine::Client::TimeTickCallbackId NE_TimeTickCallbackId;
#else
    #include <stddef.h>
    #include <stdint.h>

    typedef struct NE_TransportHub NE_TransportHub;
    typedef struct NE_Bus NE_Bus;
    typedef struct NE_Bus NE_BusGroup;
    typedef struct NE_DataNode NE_DataNode;
    typedef struct NE_Message NE_Message;
    typedef struct NE_Buffer NE_Buffer;
    typedef struct NE_Serializer NE_Serializer;
    typedef struct NE_Deserializer NE_Deserializer;

    typedef int64_t NE_SimTime;
    typedef size_t NE_TimeTickCallbackId;
#endif

#ifdef __cplusplus
extern "C" {
#endif

    /* -----------------------------------------------------------------------------------------
     * Error handling
     * ----------------------------------------------------------------------------------------- */

    /* XXX Must keep status string vector in CInterface.cpp in sync with changes here */
    typedef enum {
        NE_ERROR_OK,                /* 0  - No error  */
        NE_ERROR_INVALID_ARG,       /* 1  - Invalid argument */
        NE_ERROR_INVALID_DEST,      /* 2  - Invalid destination node */
        NE_ERROR_REJECTED,          /* 3  - Server rejected message */
        NE_ERROR_ROUTING_FAILED,    /* 4  - Server failed to route message */
        NE_ERROR_INVALID_RESP_CODE, /* 5  - Server response code is invalid */
        NE_ERROR_TIMEOUT,           /* 6  - Server response code is invalid */
        NE_ERROR_EXCEPTION,         /* 7  - Caught exception */
        NE_ERROR_NON_EXCEPTION,     /* 8  - Caught unspecified non-exception (i.e. ellipsis) */
        NE_ERROR_UNIMPLEMENTED,     /* 9  - API function not implemented */
        NE_ERROR_UNKNOWN,           /* 10 - Unknown failure; something went wrong, don't know what */
        NE_ERROR_COUNT              /* Must be last */
    }  NE_ErrorCode;

    /* Error status for all C interface functions (thread safe) */
    extern NOS_ENGINE_CLIENT_API_PUBLIC int NE_error();
    extern NOS_ENGINE_CLIENT_API_PUBLIC const char *NE_error_string();
    extern NOS_ENGINE_CLIENT_API_PUBLIC const char *NE_exception_string();
    extern NOS_ENGINE_CLIENT_API_PUBLIC int NE_ok();
    extern NOS_ENGINE_CLIENT_API_PUBLIC int NE_failed();

    /* -----------------------------------------------------------------------------------------
    * Timeouts
    * ----------------------------------------------------------------------------------------- */

    /* Types of syncronous operations which can timeout */
    typedef enum {
        NE_TIMEOUT_BUS_CREATE,
        NE_TIMEOUT_ENABLE_SET_TIME,
        NE_TIMEOUT_SET_TIME,
        NE_TIMEOUT_NODE_CREATE,
        NE_TIMEOUT_NODE_DESTROY,
        NE_TIMEOUT_QUERY,
        NE_TIMEOUT_SEND,
        NE_TIMEOUT_RECEIVE,
        NE_TIMEOUT_COUNT
    } NE_SyncOperationTimeoutType;

    extern const NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_INFINITE_RETRIES;
    extern const NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_INFINITE_TIMEOUT;

    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_set_default_connect_timeout(const size_t retries, const size_t retry_delay);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_get_default_connect_timeout(size_t *retries, size_t *retry_delay);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_set_default_timeout(const NE_SyncOperationTimeoutType type, size_t timeout);
    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_get_default_timeout(const NE_SyncOperationTimeoutType type);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_reset_default_timeouts();

    /* -----------------------------------------------------------------------------------------
     * Transport hubs
     * ----------------------------------------------------------------------------------------- */

    /* Pass 0 to use default number of threads */
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_TransportHub *NE_create_transport_hub(size_t num_service_threads);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_transport_hub(NE_TransportHub **transport_hub);

    /* -----------------------------------------------------------------------------------------
     * Buses
     * ----------------------------------------------------------------------------------------- */

    typedef void (*NE_TimeTickCallbackFunction)(NE_SimTime time);
    typedef void (*NE_TimerCallbackFunction)(NE_SimTime time, NE_SimTime requested_time);

    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Bus *NE_create_bus(NE_TransportHub *transport_hub, const char * const name, const char * const server_uri);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Bus *NE_create_bus2(const char * const name, const char * const server_uri);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Bus *NE_create_bus3(const char * const name, const char * const server_uri, const size_t num_service_threads);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_bus(NE_Bus **bus);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_TransportHub *NE_bus_get_transport_hub(NE_Bus *bus);
    extern NOS_ENGINE_CLIENT_API_PUBLIC int NE_bus_is_connected(NE_Bus *bus);

    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_enable_set_time(NE_Bus *bus);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_set_time(NE_Bus *bus, NE_SimTime time);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_SimTime NE_bus_get_time(NE_Bus *bus);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_TimeTickCallbackId NE_bus_add_time_tick_callback(NE_Bus *bus, NE_TimeTickCallbackFunction callback);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_remove_time_tick_callback(NE_Bus *bus, NE_TimeTickCallbackId callback_id);
    /* Timer time must be in the future; otherwise, the call will fail with an error */
    /* Timer time should be on a time tick; otherwise, the callback will not be called until the
       following time tick. */
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_set_timer_absolute(NE_Bus *bus, NE_SimTime time, NE_TimerCallbackFunction callback);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_set_timer_relative(NE_Bus *bus, NE_SimTime time, NE_TimerCallbackFunction callback);

    /* -----------------------------------------------------------------------------------------
     * Bus groups
     * ----------------------------------------------------------------------------------------- */

    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_BusGroup *NE_create_bus_group();
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_bus_group(NE_BusGroup **bus_group);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_group_add(NE_BusGroup *bus_group, NE_Bus *bus);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_bus_group_set_time(NE_BusGroup *bus_group, NE_SimTime time);

    /* -----------------------------------------------------------------------------------------
     * Data nodes
     * ----------------------------------------------------------------------------------------- */

    typedef void (*NE_MessageReceivedFunction)(NE_DataNode *receive_data_node, NE_Message *message);

    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_DataNode *NE_create_data_node(NE_Bus *bus, const char * const name);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_data_node(NE_Bus *bus, NE_DataNode **data_node);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Bus *NE_data_node_get_bus(NE_DataNode *data_node);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_SimTime NE_data_node_get_time(NE_DataNode *data_node);

    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_data_node_send_message_sync(NE_DataNode *data_node, const char * const destination, size_t length, const uint8_t *data);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_data_node_send_confirmed_message_sync(NE_DataNode *data_node, const char * const destination, size_t length, const uint8_t *data);
    /* User MUST destroy response message returned by this function! */
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_data_node_send_request_message_sync(NE_DataNode *data_node, const char * const destination, size_t length, const uint8_t *data, NE_Message **response);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_data_node_send_reply_message_sync(NE_DataNode *data_node, const NE_Message * const original_message, size_t length, const uint8_t *data);
    /* Pass NULL callback to clear */
    /* User MUST NOT destroy response message returned by this callback! */
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_data_node_set_message_received_callback(NE_DataNode *data_node, NE_MessageReceivedFunction callback);
    /* User MUST destroy message returned by this function! */
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Message *NE_data_node_receive_message_sync(NE_DataNode *data_node);

    /* -----------------------------------------------------------------------------------------
     * Messages
     * ----------------------------------------------------------------------------------------- */

    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_message(NE_Message **message);
    /* User MUST NOT destroy buffer returned by this function! */
    extern NOS_ENGINE_CLIENT_API_PUBLIC const NE_Buffer *NE_message_get_buffer(const NE_Message * const message);
    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_message_get_user_data_offset(const NE_Message * const message);
    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_message_get_user_data_length(const NE_Message * const message);
    extern NOS_ENGINE_CLIENT_API_PUBLIC const uint8_t *NE_message_get_user_data(const NE_Message * const message);

    /* -----------------------------------------------------------------------------------------
     * Buffers
     * ----------------------------------------------------------------------------------------- */

    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Buffer *NE_create_buffer(size_t size);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_buffer(NE_Buffer **buffer);

    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_buffer_get_size(const NE_Buffer * const buffer);
    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_buffer_get_length(const NE_Buffer * const buffer);
    /* Return value intentionally not const */
    /* TODO: Add const-returning variant */
    extern NOS_ENGINE_CLIENT_API_PUBLIC uint8_t *NE_buffer_get_data(const NE_Buffer * const buffer);

    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_buffer_reset(NE_Buffer *buffer);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_buffer_add(NE_Buffer *buffer, size_t add_len, const uint8_t * const add_data);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_buffer_set_size(NE_Buffer *buffer, size_t new_size);

    /* -----------------------------------------------------------------------------------------
     * Serialization
     * - When sending, create a buffer to serialize into.
     * - When receiving, deserialize out of the received message's buffer.
     * - The serializer does not own the buffer. User MUST destroy it after freeing the serializer.
     * ----------------------------------------------------------------------------------------- */

    typedef enum {
        NE_ENDIAN_INVALID, /* 0 */
        NE_ENDIAN_BIG,     /* 1 */
        NE_ENDIAN_LITTLE,  /* 2 */
        NE_ENDIAN_COUNT
    }  NE_Endian;

    /* Endianness */
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Endian NE_get_native_endian();

    /* Serializer */
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Serializer *NE_create_serializer(NE_Buffer *buffer, NE_Endian src_endian, NE_Endian dest_endian);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_serializer(NE_Serializer **serializer);
    /**/
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_char(NE_Serializer *serializer, char val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_int8(NE_Serializer *serializer, int8_t val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_int16(NE_Serializer *serializer, int16_t val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_int32(NE_Serializer *serializer, int32_t val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_int64(NE_Serializer *serializer, int64_t val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_float(NE_Serializer *serializer, float val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_double(NE_Serializer *serializer, double val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_string(NE_Serializer *serializer, const char * const val);
    extern void NOS_ENGINE_CLIENT_API_PUBLIC NE_serialize_binary(NE_Serializer *serializer, const void * const val, size_t val_size);

    /* Deserializer */
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Deserializer *NE_create_deserializer(NE_Buffer *buffer, NE_Endian src_endian, NE_Endian dest_endian);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_destroy_deserializer(NE_Deserializer **deserializer);
    /**/
    extern NOS_ENGINE_CLIENT_API_PUBLIC size_t NE_deserializer_get_offset(NE_Deserializer *deserializer);
    extern NOS_ENGINE_CLIENT_API_PUBLIC void NE_deserializer_set_offset(NE_Deserializer *deserializer, size_t new_offset);
    /**/
    extern char NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_char(NE_Deserializer *deserializer);
    extern int8_t NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_int8(NE_Deserializer *deserializer);
    extern int16_t NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_int16(NE_Deserializer *deserializer);
    extern int32_t NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_int32(NE_Deserializer *deserializer);
    extern int64_t NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_int64(NE_Deserializer *deserializer);
    extern float NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_float(NE_Deserializer *deserializer);
    extern double NOS_ENGINE_CLIENT_API_PUBLIC NE_deserialize_double(NE_Deserializer *deserializer);
    extern NOS_ENGINE_CLIENT_API_PUBLIC char *NE_deserialize_string(NE_Deserializer *deserializer, char *buffer, size_t buffer_size);
    extern NOS_ENGINE_CLIENT_API_PUBLIC NE_Buffer *NE_deserialize_binary(NE_Deserializer *deserializer);

#ifdef __cplusplus
}
#endif

#endif

