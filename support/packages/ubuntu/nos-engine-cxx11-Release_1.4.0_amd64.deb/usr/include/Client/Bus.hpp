/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_BUS_HPP
#define NOS_ENGINE_CLIENT_BUS_HPP

#include <cstdint>
#include <utility>
#include <queue>
#include <string>
#include <unordered_map>
#include <mutex>
#include <memory>

#include <Utility/CallbackList.hpp>
#include <Utility/Events/OnDestroy.hpp>

#include <Transport/TransportHub.hpp>

#include <Common/types.hpp>
#include <Common/Bus/BusProtocol.hpp>
#include <Common/IMessageConnection.hpp>

#include <Client/types.hpp>
#include <Client/Globals.hpp>
#include <Client/IBus.hpp>
#include <Client/TimeClient.hpp>
#include <Client/TimeSender.hpp>

namespace NosEngine
{
    namespace Client
    {
        ///
        /// \copydoc IBus
        ///
        class NOS_ENGINE_CLIENT_API_PUBLIC Bus :
            public IBus,
            public Utility::Events::OnDestroy
        {
        protected:
            // ====================================================================================
            // Types
            // ------------------------------------------------------------------------------------

            struct BusTimerEvent
            {
                NosEngine::Common::SimTime time;
                BusTimerCallback callback;
            };

            struct BusTimerEventLess : public std::less<BusTimerEvent>
            {
                bool operator()(const BusTimerEvent &a, const BusTimerEvent &b) const;
            };

            typedef std::unordered_map<std::string, Node*> NodeNameMap;
            typedef std::unordered_map<int, Node*> NodeIdMap;
            typedef std::priority_queue<BusTimerEvent, std::vector<BusTimerEvent>, BusTimerEventLess> BusTimerPriorityQueue;

        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Instantiate a client-side bus object.
            ///
            /// A bus represents a logical group of nodes in NOS Engine.
            /// A node is capable of sending and receiving messages to other nodes
            /// on the same bus.
            ///
            /// \param server_uri           The server URI
            /// \param name                 Unique name for the bus
            /// \param num_service_threads  The number of service threads that should be created
            /// \param protocol             protocol of the bus
            ///
            Bus(std::string server_uri,
                std::string name,
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS,
                std::string protocol = Common::DEFAULT_PROTOCOL_NAME);

            ///
            /// \brief Instantiate a client-side bus object.
            ///
            /// A bus represents a logical group of nodes in NOS Engine.
            /// A node is capable of sending and receiving messages to other nodes
            /// on the same bus.
            ///
            /// \param retries              maximum number of connect retries
            /// \param retry_delay          delay, in milliseconds, between connect retry attempts
            /// \param registration_timeout timeout in milliseconds to wait for confirmation of registration
            /// \param server_uri           The server URI
            /// \param name                 Unique name for the bus
            /// \param num_service_threads  The number of service threads that should be created
            /// \param protocol             protocol of the bus
            ///
            Bus(const size_t &retries,
                const size_t &retry_delay,
                const size_t &registration_timeout,
                std::string server_uri,
                std::string name,
                const size_t &num_service_threads = Transport::TRANSPORT_HUB_DEFAULT_SERVICE_THREADS,
                std::string protocol = Common::DEFAULT_PROTOCOL_NAME);

            ///
            /// \brief Instantiate a client-side bus object.
            ///
            /// A bus represents a logical group of nodes in NOS Engine.
            /// A node is capable of sending and receiving messages to other nodes
            /// on the same bus.
            ///
            /// \param transport_hub    Existing transport hub to use
            /// \param server_uri       The server URI
            /// \param name             unique name for the bus
            /// \param protocol         protocol of the bus
            ///
            Bus(Transport::TransportHub &transport_hub,
                std::string server_uri,
                std::string name,
                std::string protocol = Common::DEFAULT_PROTOCOL_NAME);

            ///
            /// \brief Instantiate a client-side bus object.
            ///
            /// A bus represents a logical group of nodes in NOS Engine.
            /// A node is capable of sending and receiving messages to other nodes
            /// on the same bus.
            ///
            /// \param retries              maximum number of connect retries
            /// \param retry_delay          delay, in milliseconds, between connect retry attempts
            /// \param registration_timeout timeout in milliseconds to wait for confirmation of registration
            /// \param transport_hub        Existing transport hub to use
            /// \param server_uri           The server URI
            /// \param name                 unique name for the bus
            /// \param protocol             protocol of the bus
            ///
            Bus(const size_t &retries,
                const size_t &retry_delay,
                const size_t &registration_timeout,
                Transport::TransportHub &transport_hub,
                std::string server_uri,
                std::string name,
                std::string protocol = Common::DEFAULT_PROTOCOL_NAME);

        private:
            Bus(const Bus&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the Bus class.
            ///
            virtual ~Bus();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            Bus& operator=(const Bus&); //!< Disable the copy assignment operator.

        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IBus implementation
            // ------------------------------------------------------------------------------------

            virtual Transport::TransportHub &get_transport_hub() const;

            virtual std::string get_name() const;

            virtual bool is_connected() const;

            virtual Common::BusRegistrationFlags get_registration_flags() const;

            virtual DataNode* get_data_node(std::string name);

            virtual DataNode* get_or_create_data_node(std::string name,
                                                      const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual void remove_data_node(const std::string& name,
                                          const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual InterceptorNode* get_interceptor(const std::string& name) const;

            virtual InterceptorNode* get_or_create_interceptor(const std::string& name,
                                                               const std::string& target,
                                                               Common::BusProtocol::InterceptorDirection direction,
                                                               const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual void remove_interceptor(const std::string& name,
                                            const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual void enable_set_time(const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual void set_time(NosEngine::Common::SimTime time, const size_t &timeout = SEND_INFINITE_TIMEOUT);

            virtual TimeTickCallbackId add_time_tick_callback(TimeTickCallbackFunc callback);

            virtual void remove_time_tick_callback(TimeTickCallbackId callback_id);

            virtual NosEngine::Common::SimTime get_time() const;

            virtual void set_timer_absolute(NosEngine::Common::SimTime time, BusTimerCallback callback);

            virtual void set_timer_relative(NosEngine::Common::SimTime time, BusTimerCallback callback);

            // TODO: Implement inject_message
            //virtual void inject_message(InjectedMessage to_inject);

            virtual Common::Message send_protocol_control_message(const Utility::Buffer& data) const;

        private:
            // ====================================================================================
            // Internal API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Call by constructors to perform common initialization.
            /// 
            /// \param retries              maximum number of connect retries
            /// \param retry_delay          delay, in milliseconds, between connect retry attempts
            /// \param registration_timeout timeout in milliseconds to wait for confirmation of registration
            ///
            void init(const size_t &retries = Transport::CONNECT_INFINITE_RETRIES,
                      const size_t &retry_delay = Transport::DEFAULT_CONNECT_RETRY_DELAY_MS,
                      const size_t &registration_timeout = SEND_INFINITE_TIMEOUT);

        protected:
            ///
            /// \brief Create a TimeClient.
            ///
            /// \param name     The name for the time client node.
            /// \param timeout  Duration to wait for a response from the server.
            ///
            virtual void create_time_client(const std::string& name, const size_t &timeout);

            ///
            /// \brief Create a TimeSender.
            ///
            /// \param name     The name for the time sender node.
            /// \param timeout  Duration to wait for a response from the server.
            ///
            virtual void create_time_sender(const std::string& name, const size_t &timeout);

            ///
            /// \brief Called when a time tick is received.
            ///
            /// \param time The time associated with the tick.
            ///
            virtual void bus_time_tick_callback(NosEngine::Common::SimTime time);

            ///
            /// \brief Build a Bus control message.
            ///
            /// \param command The type of the Bus command.
            ///
            virtual Common::Message build_message(Common::BusProtocol::CommandType command) const;

            ///
            /// \brief Get the node, with the specified name, which is attached to this bus.
            ///
            /// \note dynamic_cast should be used to determine if the node is the expected type.
            ///
            /// \param name The name of the node to find.
            ///
            /// \return The Node pointer (nullptr if not found).
            ///
            virtual Node* get_node(const std::string& name) const;

            ///
            /// \brief Remove the node, with the specified name, from this bus.
            ///
            /// \param name     The name of the node to remove.
            /// \param timeout  Duration to wait for a response from the server.
            ///
            virtual void remove_node(const std::string& name, const size_t &timeout);

            ///
            /// \brief Remove the node from this bus.
            ///
            /// \param to_remove    The node to remove.
            /// \param timeout      Duration to wait for a response from the server.
            ///
            virtual void remove_node(Node* to_remove, const size_t &timeout);

            ///
            /// \brief Remove the TimeSender/TimeClient node from the Bus.
            ///
            /// \param to_remove    The node to remove.
            /// \param timeout      Duration to wait for a response from the server.
            ///
            virtual void remove_time_node(Node* to_remove, const size_t &timeout);

            // ------------------------------------------------------------------------------------
            // IBus implementation
            // ------------------------------------------------------------------------------------

            virtual TimeClient *get_time_client();

            // ------------------------------------------------------------------------------------
            // IBus (IEngineThreadSafeObject) implementation
            // ------------------------------------------------------------------------------------

            virtual std::mutex &get_mutex() const;

        private:
            // ====================================================================================
            // Data members
            // ------------------------------------------------------------------------------------

            // ---- thread syncronization ----
            mutable std::mutex mutex;

            // ---- configuration ----
            const size_t num_service_threads;
            Transport::TransportHub *transport_hub;
            bool owns_transport_hub;
            const std::string server_uri;
            const std::string name;
            const std::string protocol;

            // ---- registration ----
            Common::BusRegistrationFlags registrationFlags;

            // ---- node collections ----
            //TODO: Consider breaking node_name_map up into data nodes, interceptor nodes, time nodes
            NodeNameMap node_name_map;
            NodeIdMap node_id_map;

            // ---- transactions ----
            NosEngine::Common::ITransactionManager* manager;

            // ---- transport ----
            std::shared_ptr<NosEngine::Common::IMessageConnection> message_connection;
            std::shared_ptr<NosEngine::Common::ISendOperator> sender;
            Common::ReceiveOperator* receiver;

            // ---- message routing ----
            NosEngine::Common::IMessageRouter* router;

            // ---- time ----
            NosEngine::Common::SimTime time;
            bool set_time_enabled;
            NosEngine::Client::TimeSender *time_sender;
            NosEngine::Client::TimeClient *time_client;
            NosEngine::Utility::CallbackList<NosEngine::Client::Bus, NosEngine::Common::SimTime> time_tick_callback_list;
            BusTimerPriorityQueue timer_event_q;
        };
    }
}

#endif