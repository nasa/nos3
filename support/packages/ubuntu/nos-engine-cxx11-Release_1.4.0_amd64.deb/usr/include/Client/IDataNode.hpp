/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_IDATA_NODE_HPP
#define NOS_ENGINE_CLIENT_IDATA_NODE_HPP

#include <Client/types.hpp>
#include <Client/INode.hpp>

namespace NosEngine
{
    namespace Client
    {
        class IDataNode :
            public virtual INode
        {
        public:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Destructor for an instance of the IDataNode class.
            ///
            virtual ~IDataNode() {}

            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Send data to another node.
            ///
            /// This will make a best-effort attempt to deliver the data to the destination; no confirmation of receipt.
            ///
            /// \param destination  name of destination node
            /// \param length       length of data
            /// \param data         pointer to data
            ///
            virtual void send_message(const std::string& destination, size_t length, const char* data) const = 0;

            ///
            /// \brief Send data to another node with confirmation.
            ///
            /// This will send a message to the destination and wait for confirmation. The method will block
            /// until confirmation has been received.
            ///
            /// \param destination  name of destination node
            /// \param length       length of data
            /// \param data         pointer to data
            /// \param timeout      timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void send_confirmed_message(const std::string& destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Asynchronous version of send_confirmed_message(const std::string& destination, size_t length, const char* data) const
            ///     
            /// The method will return immediately and call the confirmation callback when confirmation is received.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param confirmation  confirmation callback
            ///
            /// \return the transaction ID for the operation (useful if re-using callback for multiple operations)
            ///
            virtual Common::TransactionID send_confirmed_message(const std::string& destination, size_t length, const char* data, ConfirmationFunction confirmation) const = 0;

            using INode::send_confirmed_message;

            ///
            /// \brief Send a message to multiple nodes.
            ///
            /// This will make a best-effort attempt to deliver data to multiple nodes.
            ///
            /// \warning Currently only supports broadcast. Use "*" as the destination name.
            ///
            /// \param destinations  destination nodes
            /// \param length        length of data
            /// \param data          pointer to data
            ///
            virtual void send_multicast_message(const std::string& destinations, size_t length, const char* data) const = 0;

            ///
            /// \brief Send data to multiple nodes with confirmation.
            ///
            /// This will deliver the data to multiple nodes and wait for confirmation of receipt for each.
            ///
            /// \warning Currently only supports broadcast. Use "*" as the destination name.
            ///
            /// \param destinations  destination nodes
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param timeout       timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            virtual void send_multicast_confirmed_message(const std::string& destinations, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Send a request to another node and wait for a response.
            ///
            /// This send operation will deliver a message to another node and wait for a response.
            /// This method will block until the response has been received.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param timeout       timeout in milliseconds (SEND_INFINITE_TIMEOUT = no timeout)
            ///
            /// \return response from other node
            ///
            virtual Common::Message send_request_message(const std::string& destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const = 0;

            ///
            /// \brief Asynchronous version of send_request_message(const std::string& destination, size_t length, const char* data) const
            ///
            /// This method will return immediately and call the callback when a response is received.
            ///
            /// \param destination   name of destination node
            /// \param length        length of data
            /// \param data          pointer to data
            /// \param reply         callback for when reply is received
            ///
            virtual Common::TransactionID send_request_message(const std::string& destination, size_t length, const char* data, ReplyReceivedFunction reply) const = 0;
            
            ///
            /// \brief Send a reply back to a node that made a request.
            ///
            /// \param original  The original message (request from other node)
            /// \param length    length of reply
            /// \param data      pointer to reply data
            ///
            virtual void send_reply_message(const Common::Message& original, size_t length, const char* data) const = 0;
        };
    }
}


#endif