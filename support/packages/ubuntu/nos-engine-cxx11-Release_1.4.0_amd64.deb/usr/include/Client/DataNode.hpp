/* Copyright (C) 2009 - 2015 National Aeronautics and Space Administration. All Foreign Rights are Reserved to the U.S. Government.

   This software is provided "as is" without any warranty of any, kind either express, implied, or statutory, including, but not
   limited to, any warranty that the software will conform to, specifications any implied warranties of merchantability, fitness
   for a particular purpose, and freedom from infringement, and any warranty that the documentation will conform to the program, or
   any warranty that the software will be error free.

   In no event shall NASA be liable for any damages, including, but not limited to direct, indirect, special or consequential damages,
   arising out of, resulting from, or in any way connected with the software or its documentation.  Whether or not based upon warranty,
   contract, tort or otherwise, and whether or not loss was sustained from, or arose out of the results of, or use of, the software,
   documentation or services provided hereunder.

   ITC Team
   NASA IV&V
   ivv-itc@lists.nasa.gov
*/

#ifndef NOS_ENGINE_CLIENT_DATA_NODE_HPP
#define NOS_ENGINE_CLIENT_DATA_NODE_HPP

#include <string>

#include <Client/types.hpp>
#include <Client/IDataNode.hpp>
#include <Client/Node.hpp>

namespace NosEngine
{
    namespace Client
    {
        class NOS_ENGINE_CLIENT_API_PUBLIC DataNode :
            public IDataNode,
            public Node
        {
        protected:
            // ====================================================================================
            // Life cycle
            // ------------------------------------------------------------------------------------

            ///
            /// \brief Construct an instance of the DataNode class.
            ///
            /// \copydetails Node::Node()
            ///
            DataNode(const std::string &name,
                     IBus &bus,
                     const Common::NodeID &id,
                     Common::ITransactionManager *manager,
                     const Common::WeakSendOperator &transport);

        private:
            DataNode(const DataNode&); //!< Disable the copy constructor.

        public:
            ///
            /// \brief Destructor for an instance of the DataNode class.
            ///
            virtual ~DataNode();

        private:
            // ====================================================================================
            // Operators
            // ------------------------------------------------------------------------------------

            DataNode& operator=(const DataNode&); //!< Disable the copy assignment operator.
            
        public:
            // ====================================================================================
            // Public API
            // ------------------------------------------------------------------------------------

            // ------------------------------------------------------------------------------------
            // IDataNode implementation
            // ------------------------------------------------------------------------------------

            virtual Common::BusProtocol::NodeType get_type() const;

            virtual void send_message(const std::string& destination, size_t length, const char* data) const;

            virtual void send_confirmed_message(const std::string& destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const;

            virtual Common::TransactionID send_confirmed_message(const std::string& destination, size_t length, const char* data, ConfirmationFunction confirmation) const;

            using Node::send_confirmed_message;

            virtual void send_multicast_message(const std::string& destinations, size_t length, const char* data) const;

            virtual void send_multicast_confirmed_message(const std::string& destinations, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const;

            virtual Common::Message send_request_message(const std::string& destination, size_t length, const char* data, const size_t &timeout = SEND_INFINITE_TIMEOUT) const;

            virtual Common::TransactionID send_request_message(const std::string& destination, size_t length, const char* data, ReplyReceivedFunction reply) const;
            
            virtual void send_reply_message(const Common::Message& original, size_t length, const char* data) const;

        private:
            friend class Bus; //TODO: Re-evaluate this design
        };           
    }
}


#endif
